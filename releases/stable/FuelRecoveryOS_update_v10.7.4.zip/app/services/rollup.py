"""共通集計サービス（第1波 Phase 0 基盤）。

第1波の表示系機能（安全運転ランキング・項目別ランキング・燃費金額の内訳表示・
注意セル/430抽出）が共通利用する、TripReport 都度集計のユーティリティ。

設計原則:
- **生値を改変しない**（読み取り集計のみ）。サマリテーブル（MonthlySummary）は使わない。
- **損失内訳は総額不変**: dashboard._loss_for_trip と同じ係数（0.15 / 1.5）で按分するため、
  内訳合計は既存ダッシュボードの損失総額と厳密に一致する（回帰ゼロ）。
- 補正（管理者補正・AT/MT補正）は表示時 overlay として後フェーズで適用する想定で、
  本サービスは生集計のみを返す。
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date

from sqlalchemy.orm import Session

from app.models.csv_import import TripReport
from app.routers.month_utils import month_last_day

# ── 損失係数（dashboard._loss_for_trip と必ず一致させること）──
# driving 系イベント1件あたりの損失(L)。dashboard.py L74 と同値。
EVENT_LOSS_L = 0.15
# アイドリング/待機の時間あたり損失(L/h)。dashboard.py L78,L81 と同値。
TIME_LOSS_L_PER_H = 1.5
IDLE_FREE_SEC = 300  # アイドリング控除（dashboard.py L77 と同値）


# ── 月 × 営業所 でのトリップ取得 ───────────────────────────────
def month_range(base: date) -> tuple[date, date]:
    """基軸月（月初日 base）の (初日, 末日) を返す。"""
    return base.replace(day=1), month_last_day(base)


def month_trips(db: Session, base: date, office_code: str | None = None) -> list[TripReport]:
    """基軸月（＋任意で営業所）の TripReport を返す。

    営業所は driver_office_code で絞り込む（既存インデックス ix_trip_reports_office_date）。
    office_code が None / "" / "all" の場合は全営業所。
    """
    start, end = month_range(base)
    q = db.query(TripReport).filter(
        TripReport.operation_date >= start,
        TripReport.operation_date <= end,
    )
    if office_code and office_code not in ("all", "ALL"):
        q = q.filter(TripReport.driver_office_code == office_code)
    return q.all()


def list_offices(db: Session) -> list[dict]:
    """営業所セレクタ用の {code, name} 一覧（運行データに出現する営業所）。"""
    rows = (
        db.query(TripReport.driver_office_code, TripReport.driver_office_name)
        .filter(TripReport.driver_office_code.isnot(None))
        .distinct()
        .all()
    )
    offices = {}
    for code, name in rows:
        if code:
            offices[code] = name or code
    return [{"code": c, "name": n} for c, n in sorted(offices.items())]


# ── 損失内訳（総額不変・按分）────────────────────────────────
def _safe(v) -> int:
    return v or 0


def loss_breakdown(trips: list[TripReport]) -> dict[str, float]:
    """トリップ群の損失を「指導項目別の内訳(L)」に按分して返す。

    重要: driving 系（急加速/急減速/急発進/速度超過/回転数オーバー）は
    各イベント数 × EVENT_LOSS_L で計算する。これらの合計は
    dashboard._loss_for_trip の driving_l（= 全イベント数 × 0.15）と厳密に一致するため、
    内訳合計 = 既存ダッシュボードの損失総額（driving+dispatch+shipper）になる（回帰ゼロ）。

    Returns: {項目名: 損失L}。total は sum(values())。
    """
    accel = decel = start = speed_over = rpm_over = 0
    idle_excess_sec = 0
    wait_sec = 0
    for t in trips:
        accel += _safe(t.sudden_accel_count)
        decel += _safe(t.sudden_decel_count)
        start += _safe(t.sudden_start_count)
        speed_over += _safe(t.speed_over_general_count) + _safe(t.speed_over_highway_count)
        rpm_over += _safe(t.rpm_over_general_count) + _safe(t.rpm_over_highway_count)
        idle_excess_sec += max(_safe(t.idle_time_sec) - IDLE_FREE_SEC, 0)
        wait_sec += _safe(t.waiting_time_sec)

    return {
        "急加速": accel * EVENT_LOSS_L,
        "急減速": decel * EVENT_LOSS_L,
        "急発進": start * EVENT_LOSS_L,
        "速度超過": speed_over * EVENT_LOSS_L,
        "回転数オーバー": rpm_over * EVENT_LOSS_L,
        "アイドリング": (idle_excess_sec / 3600) * TIME_LOSS_L_PER_H,
        "待機": (wait_sec / 3600) * TIME_LOSS_L_PER_H,
    }


def loss_total_l(breakdown: dict[str, float]) -> float:
    """内訳の合計損失(L)。"""
    return sum(breakdown.values())


# 指導項目 → 推奨アクション（「何をすべきか」）
CATEGORY_ACTION = {
    "急加速": "発進・加速をゆるやかに。上位者へ重点的に声かけ",
    "急減速": "車間を広めにとり、早めの減速を促す",
    "急発進": "発進時のアクセルの踏み込みを抑える",
    "速度超過": "制限速度の遵守を徹底（該当区間を確認）",
    "回転数オーバー": "早めのシフトアップ（AT車は加速後にアクセルを戻す）",
    "アイドリング": "停車時のエンジン停止（アイドリングストップ）を徹底",
    "待機": "荷主待機の削減交渉・配車の見直し",
    "その他(車両)": "該当車両の点検・整備状況を確認",
}

# 指導項目 → aggregate_by_driver のフィールド（上位対象者の算出用）
CATEGORY_FIELD = {
    "急加速": "sudden_accel",
    "急減速": "sudden_decel",
    "急発進": "sudden_start",
    "速度超過": "speed_over",
    "回転数オーバー": "rpm_over",
    "アイドリング": "idle_excess_sec",
    "待機": "wait_sec",
}


def loss_items_detailed(breakdown: dict[str, float], agg: dict | None = None,
                        fuel_price: int = 0, total_l: float | None = None,
                        top_n: int = 3) -> list[dict]:
    """損失内訳を「金額・割合・バー比率・推奨アクション・上位対象者」付きのリストに。

    breakdown: rollup.loss_breakdown の結果（総額不変）。
    agg: aggregate_by_driver の結果（上位対象者用、省略時は top=[]）。
    """
    total = total_l if total_l else (loss_total_l(breakdown) or 0.1)
    max_l = max(breakdown.values()) if breakdown else 0
    items: list[dict] = []
    for cat, loss_l in sorted(breakdown.items(), key=lambda kv: kv[1], reverse=True):
        if loss_l <= 0:
            continue
        top: list[str] = []
        field = CATEGORY_FIELD.get(cat)
        if agg and field:
            rows = [d for d in agg.values() if d.get(field)]
            rows.sort(key=lambda d: d[field], reverse=True)
            top = [d["driver_name"] for d in rows[:top_n]]
        items.append({
            "category": cat,
            "loss_l": round(loss_l, 1),
            "yen": int(loss_l * fuel_price),
            "pct": round(loss_l / total * 100, 1) if total else 0,
            "bar_pct": round(loss_l / max_l * 100, 1) if max_l else 0,
            "action": CATEGORY_ACTION.get(cat, ""),
            "top": top,
        })
    return items


def vehicle_layer_loss(trips: list[TripReport]) -> float:
    """車両層（車両起因）損失。dashboard._loss_for_trip とは別枠の第4層。

    走行 5km 超の運行を車両別に集計し、イベント発生率が全体平均の 1.15 倍を超える
    車両分だけを按分加算する（dashboard の車両層と同一ロジック＝単一ソース）。
    """
    vstats: dict[str, dict] = {}
    for t in trips:
        if t.distance_m and t.distance_m > 5000:
            s = vstats.setdefault(t.vehicle_code, {"dist": 0, "events": 0})
            s["dist"] += t.distance_m or 0
            s["events"] += (_safe(t.sudden_accel_count) + _safe(t.sudden_decel_count)
                            + _safe(t.speed_over_general_count) + _safe(t.speed_over_highway_count))
    tv = 0.0
    if vstats:
        avg_rate = sum(v["events"] / max(v["dist"] / 1000, 1) for v in vstats.values()) / len(vstats)
        for v in vstats.values():
            rate = v["events"] / max(v["dist"] / 1000, 1)
            if rate > avg_rate * 1.15:
                tv += (rate - avg_rate) * v["dist"] / 1000 * 0.05
    return tv


def build_full_loss_items(trips: list[TripReport], vehicle_trips: list[TripReport],
                          agg: dict | None, fuel_price: int) -> tuple[list[dict], float]:
    """指導項目別の内訳＋「その他(車両)」を合わせた完全な loss_items と総損失Lを返す。

    総額 = 指導項目按分(loss_breakdown) + 車両層(vehicle_layer_loss)。
    pct 分母・bar_pct は車両層込みの総額で統一する（ダッシュボードと /loss/breakdown で不変）。
    """
    bd = loss_breakdown(trips)
    veh = vehicle_layer_loss(vehicle_trips)
    total = loss_total_l(bd) + veh
    layer_total = max(total, 0.1)
    items = loss_items_detailed(bd, agg, fuel_price, layer_total)
    if veh > 0:
        items.append({
            "category": "その他(車両)",
            "loss_l": round(veh, 1),
            "yen": int(veh * fuel_price),
            "pct": round(veh / layer_total * 100, 1),
            "bar_pct": 0,
            "action": CATEGORY_ACTION.get("その他(車両)", ""),
            "top": [],
        })
        items.sort(key=lambda x: x["yen"], reverse=True)
        max_y = max((x["yen"] for x in items), default=0)
        for x in items:
            x["bar_pct"] = round(x["yen"] / max_y * 100, 1) if max_y else 0
    return items, total


# ── ドライバー別集計（ランキング用）──────────────────────────
def aggregate_by_driver(trips: list[TripReport]) -> dict[str, dict]:
    """ドライバー別に安全運転指標を集計して {driver_code: 指標dict} を返す。

    安全運転ランキング(②)・項目別ランキング(③)・注意セル/430抽出(⑤)が共用。
    生値のみ（補正は表示時 overlay で別途）。
    """
    agg: dict[str, dict] = defaultdict(lambda: {
        "driver_code": "",
        "driver_name": "",
        "office_code": None,
        "office_name": None,
        "trip_count": 0,
        "sudden_start": 0,
        "sudden_accel": 0,
        "sudden_decel": 0,
        "sudden_brake": 0,
        "sudden_turn": 0,
        "speed_over": 0,      # 一般+高速+専用道
        "rpm_over": 0,        # 一般+高速
        "idle_excess_sec": 0, # アイドリング控除後の超過秒（内訳上位用）
        "wait_sec": 0,        # 待機秒（内訳上位用）
        "max_continuous_sec": 0,
        "_score_sum": 0.0,    # overall_score 合計（平均算出用）
        "_score_cnt": 0,
        "_eco_sum": 0.0,
        "_eco_cnt": 0,
        "_safety_sum": 0.0,
        "_safety_cnt": 0,
    })
    for t in trips:
        dc = t.driver_code
        if not dc:
            continue
        d = agg[dc]
        d["driver_code"] = dc
        d["driver_name"] = t.driver_name or d["driver_name"] or dc
        if t.driver_office_code:
            d["office_code"] = t.driver_office_code
            d["office_name"] = t.driver_office_name or t.driver_office_code
        d["trip_count"] += 1
        d["sudden_start"] += _safe(t.sudden_start_count)
        d["sudden_accel"] += _safe(t.sudden_accel_count)
        d["sudden_decel"] += _safe(t.sudden_decel_count)
        d["sudden_brake"] += _safe(t.sudden_brake_count)
        d["sudden_turn"] += _safe(t.sudden_turn_count)
        d["speed_over"] += (
            _safe(t.speed_over_general_count) + _safe(t.speed_over_highway_count)
            + _safe(t.speed_over_dedicated_count)
        )
        d["rpm_over"] += _safe(t.rpm_over_general_count) + _safe(t.rpm_over_highway_count)
        d["idle_excess_sec"] += max(_safe(t.idle_time_sec) - IDLE_FREE_SEC, 0)
        d["wait_sec"] += _safe(t.waiting_time_sec)
        d["max_continuous_sec"] = max(d["max_continuous_sec"], _safe(t.max_continuous_sec))
        if t.overall_score is not None:
            d["_score_sum"] += t.overall_score
            d["_score_cnt"] += 1
        if t.economy_score is not None:
            d["_eco_sum"] += t.economy_score
            d["_eco_cnt"] += 1
        if t.safety_score is not None:
            d["_safety_sum"] += t.safety_score
            d["_safety_cnt"] += 1

    # 平均スコアを確定
    for d in agg.values():
        d["avg_overall_score"] = round(d["_score_sum"] / d["_score_cnt"], 1) if d["_score_cnt"] else None
        d["avg_economy_score"] = round(d["_eco_sum"] / d["_eco_cnt"], 1) if d["_eco_cnt"] else None
        d["avg_safety_score"] = round(d["_safety_sum"] / d["_safety_cnt"], 1) if d["_safety_cnt"] else None
        for k in ("_score_sum", "_score_cnt", "_eco_sum", "_eco_cnt", "_safety_sum", "_safety_cnt"):
            d.pop(k, None)
    return dict(agg)


# ランキング用ソートキー（None は最下位に回す）
RANK_KEYS: dict[str, tuple] = {
    # key: (集計フィールド, 降順か, ラベル)
    "safety": ("avg_overall_score", True, "総合評価"),
    "accel": ("sudden_accel", True, "急加速"),
    "decel": ("sudden_decel", True, "急減速"),
    "start": ("sudden_start", True, "急発進"),
    "speed_over": ("speed_over", True, "速度超過"),
    "rpm_over": ("rpm_over", True, "回転数オーバー"),
    "continuous": ("max_continuous_sec", True, "連続走行"),
}

# 430（連続運転）注意の閾値（秒）: 4時間
CONTINUOUS_WARN_SEC = 4 * 3600


def rank_drivers(agg: dict[str, dict], key: str = "safety") -> list[dict]:
    """集計結果を指定キーで並べ替えてランキング配列（rank付き）を返す。"""
    field, desc, _label = RANK_KEYS.get(key, RANK_KEYS["safety"])
    rows = list(agg.values())

    def sort_val(d):
        v = d.get(field)
        if v is None:
            # None は最下位（降順なら -inf、昇順なら +inf 相当）
            return float("-inf") if desc else float("inf")
        return v

    rows.sort(key=sort_val, reverse=desc)
    for i, d in enumerate(rows, start=1):
        d["rank"] = i
        d["is_430_warn"] = d.get("max_continuous_sec", 0) >= CONTINUOUS_WARN_SEC
    return rows
