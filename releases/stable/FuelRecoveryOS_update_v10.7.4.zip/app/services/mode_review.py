"""モード設定の確認推奨運行 検知サービス。

ドライバーが運行中にデジタコの「高速道モード」を一般道走行中に意図的に
セットすると、本来一般道閾値で計上されるべき違反が高速モード閾値の緩い
基準で計上され、見かけ上スコアが良くなる。本サービスは TripReport の
集計値から「高速モード計上時間に一般道らしい走行パターンが含まれる」
運行を抽出し、確認推奨運行として返す。

完璧な不正検知ではなく、見直しのきっかけとして位置づけ、ドライバーを
責める表現は避ける(notes はすべて中立的な事実描写)。
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.csv_import import TripReport, TripTimeseries, TollRecord
from app.routers.month_utils import month_last_day

# ── 検出閾値(将来 system_settings 化を想定) ──
MIN_HWY_SEC = 600                # 評価対象の最小高速計上時間: 10分
LOW_AVG_SPEED_HARD = 45.0        # 平均速度の重い閾値 (km/h)
LOW_AVG_SPEED_SOFT = 60.0        # 平均速度の軽い閾値 (km/h)
LOW_MAX_HWY_SPEED = 55.0         # 高速区分の最高速度がこれ以下は強い兆候 (km/h)
HWY_PACE_KMH = 60.0             # この速度以上を「高速ペース」とみなす (map 色分けと一致)
CRAWL_SHARE_THRESHOLD = 0.30     # 停止+微速比率の閾値
ETC_LOOKBACK_DAYS = 30           # ETC連動車両自動判定の参照期間
SCORE_THRESHOLD = 50             # 確認推奨フラグの閾値

# シグナルごとの加点
SCORE_AVG_SPEED_HARD = 40
SCORE_AVG_SPEED_SOFT = 20
SCORE_MAX_HWY_SPEED = 40          # 高速区分の最高速度が低い(最も強い兆候の一つ)
SCORE_CRAWL_SHARE = 25
SCORE_ETC_MISMATCH = 35


def _collect_etc_linked_vehicles(db: Session, ref_date: date) -> set[str]:
    """ref_date から直近 ETC_LOOKBACK_DAYS 日に etc_count > 0 の運行が
    1件でもある車両コードの集合を返す。これら車両は ETC 連動済みと推定。"""
    since = ref_date - timedelta(days=ETC_LOOKBACK_DAYS)
    rows = db.query(TripReport.vehicle_code).filter(
        TripReport.operation_date >= since,
        TripReport.operation_date <= ref_date,
        TripReport.etc_count.isnot(None),
        TripReport.etc_count > 0,
    ).distinct().all()
    return {r[0] for r in rows if r[0]}


def evaluate_trip(trip: TripReport, is_etc_linked: bool) -> dict[str, Any] | None:
    """単一 TripReport を評価。対象外なら None、対象なら評価結果 dict。

    返り値の dict:
        {
            "score": int,
            "notes": list[str],
            "avg_hwy_kmh": float,
            "hwy_sec": int,
            "is_etc_linked": bool,
            "etc_count": int,
            "is_review_recommended": bool,
        }
    """
    hwy_sec = trip.highway_driving_sec or 0
    if hwy_sec < MIN_HWY_SEC:
        return None  # 短時間は判定保留

    hwy_loaded = trip.highway_loaded_m or 0
    hwy_empty = trip.highway_empty_m or 0
    hwy_dist = hwy_loaded + hwy_empty
    avg_hwy_kmh = (hwy_dist / hwy_sec) * 3.6 if hwy_sec > 0 else 0.0
    # 高速区分の最高速度(デジタコ集計値)。平均より強い証拠になり得る。
    max_hwy_speed = max(trip.max_speed_loaded_highway or 0,
                        trip.max_speed_empty_highway or 0)

    score = 0
    notes: list[str] = []

    # シグナル 1: 平均速度
    if avg_hwy_kmh < LOW_AVG_SPEED_HARD:
        score += SCORE_AVG_SPEED_HARD
        notes.append(f"高速計上時間の平均速度が {avg_hwy_kmh:.0f} km/h と低く、一般道ペースです")
    elif avg_hwy_kmh < LOW_AVG_SPEED_SOFT:
        score += SCORE_AVG_SPEED_SOFT
        notes.append(f"高速計上時間の平均速度が {avg_hwy_kmh:.0f} km/h とやや低めです")

    # シグナル 2: 高速区分の最高速度が低い(46分計上でも最高55km/h止まり等)
    if 0 < max_hwy_speed <= LOW_MAX_HWY_SPEED:
        score += SCORE_MAX_HWY_SPEED
        notes.append(f"高速計上中の最高速度が {max_hwy_speed} km/h 止まりで、高速道路走行と考えにくい状態です")

    # シグナル 3: 停止/微速時間の比率(運行全体の集計を間接シグナルとして利用)
    gen_sec = trip.general_driving_sec or 0
    ded_sec = trip.dedicated_driving_sec or 0
    total_drive_sec = gen_sec + hwy_sec + ded_sec
    if total_drive_sec > 0:
        crawl_share = ((trip.stop_time_sec or 0) + (trip.crawl_sec or 0)) / total_drive_sec
        if crawl_share > CRAWL_SHARE_THRESHOLD and avg_hwy_kmh < LOW_AVG_SPEED_SOFT:
            score += SCORE_CRAWL_SHARE
            notes.append(f"運行全体の停止・微速時間比率が {crawl_share*100:.0f}% と高めです")

    # シグナル 4: ETC通行記録(連動車両のみ)
    etc_count = trip.etc_count or 0
    if is_etc_linked and etc_count == 0:
        score += SCORE_ETC_MISMATCH
        notes.append("ETC連動車両ですが、この運行のETC通行記録がありません(高速道路を使った形跡なし)")

    return {
        "score": score,
        "notes": notes,
        "avg_hwy_kmh": avg_hwy_kmh,
        "max_hwy_speed": max_hwy_speed,
        "estra_avg_hwy_kmh": trip.avg_speed_highway or 0,
        "hwy_sec": hwy_sec,
        "is_etc_linked": is_etc_linked,
        "etc_count": etc_count,
        "etc_cost_yen": trip.etc_cost_yen or trip.toll_total_yen or 0,
        "is_review_recommended": score >= SCORE_THRESHOLD,
    }


def get_review_results(db: Session, base_month: date) -> dict[str, Any]:
    """基軸月の評価結果をまとめて返す。

    返り値:
        {
            "trips": list[dict],          # 確認推奨運行(運行単位)
            "driver_ranking": list[dict], # ドライバー別ランキング
            "summary": {
                "trip_count": int,        # 確認推奨運行件数
                "driver_count": int,      # 対象ドライバー数
                "total_trips": int,       # 月内全運行件数
                "ratio_pct": float,       # 全運行に対する比率(%)
                "strong_count": int,      # スコア80以上(強い兆候)
                "medium_count": int,      # スコア50-79(中程度の兆候)
            },
        }
    """
    last_day = month_last_day(base_month)
    etc_linked = _collect_etc_linked_vehicles(db, last_day)

    all_trips_q = db.query(TripReport).filter(
        TripReport.operation_date >= base_month,
        TripReport.operation_date <= last_day,
    ).order_by(TripReport.operation_date.desc())
    all_trips = all_trips_q.all()
    total_trips = len(all_trips)

    review_trips: list[dict[str, Any]] = []
    strong_count = 0
    medium_count = 0
    for t in all_trips:
        result = evaluate_trip(t, is_etc_linked=(t.vehicle_code in etc_linked))
        if not result or not result["is_review_recommended"]:
            continue
        score = result["score"]
        if score >= 80:
            level = "strong"
            strong_count += 1
        else:
            level = "medium"
            medium_count += 1
        review_trips.append({
            "report_number": t.report_number,
            "operation_date": t.operation_date,
            "driver_code": t.driver_code,
            "driver_name": t.driver_name or t.driver_code,
            "driver_office_name": t.driver_office_name or "",
            "vehicle_code": t.vehicle_code,
            "vehicle_name": t.vehicle_name or t.vehicle_code,
            "hwy_sec": result["hwy_sec"],
            "avg_hwy_kmh": result["avg_hwy_kmh"],
            "is_etc_linked": result["is_etc_linked"],
            "etc_count": result["etc_count"],
            "score": score,
            "level": level,
            "notes": result["notes"],
        })

    # ドライバー別ランキング
    by_driver: dict[str, dict[str, Any]] = defaultdict(lambda: {
        "driver_code": "",
        "driver_name": "",
        "driver_office_name": "",
        "trip_count": 0,
        "total_hwy_sec": 0,
        "avg_hwy_kmh_sum": 0.0,
        "avg_hwy_kmh_cnt": 0,
    })
    for tr in review_trips:
        d = by_driver[tr["driver_code"]]
        d["driver_code"] = tr["driver_code"]
        d["driver_name"] = tr["driver_name"]
        d["driver_office_name"] = tr["driver_office_name"]
        d["trip_count"] += 1
        d["total_hwy_sec"] += tr["hwy_sec"]
        d["avg_hwy_kmh_sum"] += tr["avg_hwy_kmh"]
        d["avg_hwy_kmh_cnt"] += 1

    driver_ranking = []
    for d in by_driver.values():
        avg = d["avg_hwy_kmh_sum"] / d["avg_hwy_kmh_cnt"] if d["avg_hwy_kmh_cnt"] else 0.0
        driver_ranking.append({
            "driver_code": d["driver_code"],
            "driver_name": d["driver_name"],
            "driver_office_name": d["driver_office_name"],
            "trip_count": d["trip_count"],
            "total_hwy_sec": d["total_hwy_sec"],
            "avg_hwy_kmh": avg,
        })
    driver_ranking.sort(key=lambda x: (-x["trip_count"], -x["total_hwy_sec"]))

    return {
        "trips": review_trips,
        "driver_ranking": driver_ranking,
        "summary": {
            "trip_count": len(review_trips),
            "driver_count": len(driver_ranking),
            "total_trips": total_trips,
            "ratio_pct": round(len(review_trips) / total_trips * 100, 1) if total_trips else 0.0,
            "strong_count": strong_count,
            "medium_count": medium_count,
        },
    }


def get_review_summary(db: Session, base_month: date) -> dict[str, int]:
    """ダッシュボード用の軽量集計。"""
    return get_review_results(db, base_month)["summary"]


def get_trip_trajectory(db: Session, report_number: str) -> dict[str, Any] | None:
    """運行単一の軌跡データを返す。地図描画用。

    返り値(該当運行が無ければ None):
        {
            "trip": {report_number, operation_date, driver_name, vehicle_name, ...},
            "evaluation": {... evaluate_trip の戻り値, または None},
            "points": [{"lat", "lon", "speed", "rpm", "ts"}],  # GPS時系列(分)
            "toll_records": [{"entry_ic", "exit_ic", "toll_type", "cost_yen"}],
        }
    """
    trip = db.query(TripReport).filter_by(report_number=report_number).first()
    if not trip:
        return None

    # 評価(対象外でも詳細は表示する)
    is_etc_linked = bool(
        db.query(TripReport).filter(
            TripReport.vehicle_code == trip.vehicle_code,
            TripReport.operation_date >= trip.operation_date - timedelta(days=ETC_LOOKBACK_DAYS),
            TripReport.operation_date <= trip.operation_date,
            TripReport.etc_count.isnot(None),
            TripReport.etc_count > 0,
        ).first()
    )
    evaluation = evaluate_trip(trip, is_etc_linked=is_etc_linked)

    # 時系列の取込有無(GPSの有無と区別する: GPS未記録でも「取込済み」は取込済み)
    ts_all_count = db.query(func.count(TripTimeseries.id)).filter(
        TripTimeseries.report_number == report_number).scalar() or 0

    # 分単位ペース内訳(運行全体のスピード分布)。60km/h+ を「高速ペース」とみなす。
    # ⚠ 分ごとの道路種別はデータに無いため、これは運行全体の比較であって
    #   「高速計上分のうち何分が速い」という区間帰属ではない(過大に出さない=分の最高速度で判定)。
    fast_min = db.query(func.count(TripTimeseries.id)).filter(
        TripTimeseries.report_number == report_number,
        TripTimeseries.speed_kmh >= HWY_PACE_KMH).scalar() or 0
    hwy_claimed_min = round((evaluation["hwy_sec"] if evaluation else 0) / 60)
    pace_breakdown = {
        "fast_min": fast_min,                 # 全行程で60km/h+に達した分
        "hwy_claimed_min": hwy_claimed_min,   # 高速計上時間[分]
        # 高速計上が多いのに高速ペースの分が極端に少ない = 論理的矛盾(強い兆候)
        "contradiction": bool(evaluation and hwy_claimed_min >= 10 and fast_min * 2 < hwy_claimed_min),
    }

    # GPS時系列(緯度経度ともに格納されているレコードのみ)
    ts_rows = db.query(TripTimeseries).filter(
        TripTimeseries.report_number == report_number,
        TripTimeseries.gps_lat.isnot(None),
        TripTimeseries.gps_lon.isnot(None),
        TripTimeseries.gps_lat != 0,
        TripTimeseries.gps_lon != 0,
    ).order_by(TripTimeseries.recorded_at.asc()).all()

    points = []
    skipped = 0
    for r in ts_rows:
        lat = r.gps_lat / 100000.0
        lon = r.gps_lon / 100000.0
        # 世界範囲外、または (0,0) 近傍(GPS未捕捉) は除外
        if not (-90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0):
            skipped += 1
            continue
        if abs(lat) < 0.01 and abs(lon) < 0.01:
            skipped += 1
            continue
        points.append({
            "lat": lat,
            "lon": lon,
            "speed": r.speed_kmh,
            "rpm": r.engine_rpm,
            "ts": r.recorded_at.strftime("%H:%M") if r.recorded_at else "",
        })

    # ETC通行記録
    tolls = db.query(TollRecord).filter_by(report_number=report_number).all()
    toll_records = [
        {
            "entry_ic": t.entry_ic or "",
            "exit_ic": t.exit_ic or "",
            "toll_type": t.toll_type or "",
            "cost_yen": t.cost_yen or 0,
        }
        for t in tolls
    ]

    return {
        "trip": {
            "report_number": trip.report_number,
            "operation_date": trip.operation_date,
            "driver_code": trip.driver_code,
            "driver_name": trip.driver_name or trip.driver_code,
            "driver_office_name": trip.driver_office_name or "",
            "vehicle_code": trip.vehicle_code,
            "vehicle_name": trip.vehicle_name or trip.vehicle_code,
            "departure_datetime": trip.departure_datetime,
            "arrival_datetime": trip.arrival_datetime,
            "highway_driving_sec": trip.highway_driving_sec or 0,
            "general_driving_sec": trip.general_driving_sec or 0,
            "dedicated_driving_sec": trip.dedicated_driving_sec or 0,
            "highway_loaded_m": trip.highway_loaded_m or 0,
            "highway_empty_m": trip.highway_empty_m or 0,
            "general_loaded_m": trip.general_loaded_m or 0,
            "general_empty_m": trip.general_empty_m or 0,
            "etc_count": trip.etc_count or 0,
        },
        "evaluation": evaluation,
        "pace_breakdown": pace_breakdown,
        "thresholds": {
            "avg_soft": LOW_AVG_SPEED_SOFT,   # 50km/h前後の目安表示用
            "avg_hard": LOW_AVG_SPEED_HARD,
            "hwy_pace": HWY_PACE_KMH,
        },
        "is_etc_linked": is_etc_linked,
        "points": points,
        "points_skipped": skipped,
        "ts_rows_total": len(ts_rows),
        "ts_imported": ts_all_count > 0,
        "ts_all_count": ts_all_count,
        "ts_gps_rows": len(ts_rows),   # GPS(緯度経度)が非NULL・非0で記録された行数
        "toll_records": toll_records,
    }
