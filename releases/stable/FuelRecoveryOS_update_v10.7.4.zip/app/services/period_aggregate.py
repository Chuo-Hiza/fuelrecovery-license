"""期間集計(旧 FR-31/32 の移設)— 期間(from–to月)×乗務員/車両の精算用一覧。

役割: 期間横断の**運行数・運行日数・走行km・ETC回数・ETC料金**を一目で一覧化し
CSV/印刷で出力する(精算・提出用)。すべて Estra 日報 CSV が出典。
給油量・燃費は「給油入力」画面、拘束時間は「法令・労務」画面に集約しており、
機能重複を避けるため本画面では扱わない(2026-07-20 ユーザー決定)。
"""
import calendar
import re
from datetime import date

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.importers.nippo_trip import normalize_driver_code
from app.models.csv_import import TripReport
from app.models.system import ImportLog

_YM_RE = re.compile(r"^\d{4}-\d{2}$")
MAX_MONTHS = 36  # 期間の上限(誤指定での全期間走査を防ぐ)


def parse_ym(ym: str | None) -> str | None:
    if ym and _YM_RE.match(ym):
        y, m = int(ym[:4]), int(ym[5:7])
        if 2000 <= y <= 2100 and 1 <= m <= 12:
            return ym
    return None


def month_seq(ym_from: str, ym_to: str) -> list[str]:
    """from〜to(両端含む)の YYYY-MM 列。逆転時は from 単月。上限 MAX_MONTHS。"""
    if ym_to < ym_from:
        ym_to = ym_from
    out = []
    y, m = int(ym_from[:4]), int(ym_from[5:7])
    while len(out) < MAX_MONTHS:
        cur = f"{y:04d}-{m:02d}"
        out.append(cur)
        if cur == ym_to:
            break
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def _date_range(months: list[str]) -> tuple[date, date]:
    y0, m0 = int(months[0][:4]), int(months[0][5:7])
    y1, m1 = int(months[-1][:4]), int(months[-1][5:7])
    return date(y0, m0, 1), date(y1, m1, calendar.monthrange(y1, m1)[1])


def _f(v) -> float:
    return float(v) if v else 0.0


def _i(v) -> int:
    return int(v) if v else 0


def aggregate_period(db: Session, ym_from: str, ym_to: str, office: str | None,
                     axis: str) -> dict:
    """期間集計本体(精算用途に純化)。axis='driver'|'vehicle'。

    列: 運行数・運行日数・走行km・ETC回数・ETC料金 のみ(すべて Estra 日報が出典)。
    給油量/燃費は「給油入力」画面、拘束時間は「法令・労務」画面に集約したため
    本画面では扱わない(重複解消 — 2026-07-20 ユーザー決定)。
    返り値: {months, rows, totals}。
    """
    months = month_seq(ym_from, ym_to)
    start, end = _date_range(months)
    office_on = bool(office) and office not in ("all", "ALL")

    q = db.query(TripReport).filter(
        TripReport.operation_date >= start,
        TripReport.operation_date <= end,
    )
    if office_on:
        q = q.filter(TripReport.driver_office_code == office)
    trips = q.all()

    rows_map: dict[str, dict] = {}

    def _row(key: str, name: str, office_code: str | None) -> dict:
        return rows_map.setdefault(key, {
            "key": key, "name": name, "office_code": office_code,
            "trip_count": 0, "day_count": 0, "_days": set(),
            "km": 0.0, "etc_count": 0, "etc_cost_yen": 0,
        })

    for t in trips:
        if axis == "vehicle":
            key = t.vehicle_code or "—"
            r = _row(key, t.vehicle_name or key, t.vehicle_office_code)
        else:
            key = normalize_driver_code(t.driver_code or "")
            r = _row(key, t.driver_name or key, t.driver_office_code)
        r["trip_count"] += 1
        r["_days"].add(t.operation_date)
        r["km"] += _i(t.distance_m) / 1000.0
        r["etc_count"] += _i(t.etc_count)
        r["etc_cost_yen"] += _i(t.etc_cost_yen)

    rows = []
    for r in rows_map.values():
        r["day_count"] = len(r.pop("_days"))
        rows.append(r)
    rows.sort(key=lambda r: (-r["km"], r["name"], r["key"]))

    totals = {
        "trip_count": sum(r["trip_count"] for r in rows),
        "day_count": sum(r["day_count"] for r in rows),
        "km": sum(r["km"] for r in rows),
        "etc_count": sum(r["etc_count"] for r in rows),
        "etc_cost_yen": sum(r["etc_cost_yen"] for r in rows),
    }
    return {"months": months, "rows": rows, "totals": totals}


def etc_detail(db: Session, d_from: date, d_to: date, office: str | None) -> dict:
    """ETC明細の年月日Range閲覧(顧客FB② 2026-07-24・おまけ機能)。

    日付基準は ETC の精算日時(used_at)。旧取込データ(used_at=NULL)は運行日で
    フォールバックし time_missing=True を付す(強制再取込で精算日時が入る)。
    位置づけ: 請求の証憑ではなく突合・精査の補助(参考) — 画面に明示。
    """
    from datetime import datetime, timedelta
    from app.models.csv_import import TollRecord

    office_on = bool(office) and office not in ("all", "ALL")
    lo = datetime.combine(d_from, datetime.min.time())
    hi = datetime.combine(d_to + timedelta(days=1), datetime.min.time())

    q = (db.query(TollRecord, TripReport)
         .join(TripReport, TripReport.report_number == TollRecord.report_number)
         .filter(
             ((TollRecord.used_at >= lo) & (TollRecord.used_at < hi))
             | (TollRecord.used_at.is_(None)
                & (TripReport.operation_date >= d_from)
                & (TripReport.operation_date <= d_to))))
    if office_on:
        q = q.filter(TripReport.driver_office_code == office)

    rows = []
    for toll, trip in q.all():
        rows.append({
            "used_at": toll.used_at,
            "date_str": (toll.used_at.strftime("%Y-%m-%d %H:%M") if toll.used_at
                         else f"{trip.operation_date.isoformat()} (時刻なし)"),
            "time_missing": toll.used_at is None,
            "operation_date": trip.operation_date,
            "driver_name": trip.driver_name or trip.driver_code,
            "vehicle_code": trip.vehicle_code,
            "vehicle_name": trip.vehicle_name or trip.vehicle_code,
            "entry_ic": toll.entry_ic or "",
            "exit_ic": toll.exit_ic or "",
            "toll_type": toll.toll_type or "",
            "cost_yen": toll.cost_yen or 0,
            "zero_cost": (toll.cost_yen or 0) == 0,
            "report_number": trip.report_number,
        })
    rows.sort(key=lambda r: (r["used_at"]
                             or datetime.combine(r["operation_date"],
                                                 datetime.min.time())))
    return {
        "rows": rows,
        "total_yen": sum(r["cost_yen"] for r in rows),
        "count": len(rows),
        "missing_count": sum(1 for r in rows if r["time_missing"]),
        "zero_count": sum(1 for r in rows if r["zero_cost"]),
    }


def etc_csv_lines(result: dict) -> list[str]:
    """ETC明細のCSV行(Excel想定)。"""
    lines = ["利用日時,運行日,乗務員,車両コード,車両名,入口IC,出口IC,区分,金額円,備考"]

    def _q(s) -> str:
        s = str(s if s is not None else "")
        return '"' + s.replace('"', '""') + '"' if ("," in s or '"' in s) else s

    for r in result["rows"]:
        remark = "料金ゲート非表示の可能性(実額はETC利用照会で確認)" if r.get("zero_cost") else ""
        lines.append(",".join([
            r["date_str"], r["operation_date"].isoformat(), _q(r["driver_name"]),
            _q(r["vehicle_code"]), _q(r["vehicle_name"]), _q(r["entry_ic"]),
            _q(r["exit_ic"]), _q(r["toll_type"]), str(r["cost_yen"]), _q(remark),
        ]))
    return lines


def source_timestamps(db: Session) -> dict:
    """算出時点表示用 — 各ソースの最終取込日時(契約 §5 スナップショット性)。"""
    return {
        "estra_last": db.query(func.max(ImportLog.imported_at))
        .filter(ImportLog.status != "error").scalar(),
    }


def csv_lines(result: dict, axis: str) -> list[str]:
    """CSV出力(Excel想定)。全列 Estra 日報が出典。呼出側で BOM を付ける。"""
    head_key = "車両コード,車両名" if axis == "vehicle" else "乗務員コード,乗務員名,営業所"
    cols = [head_key, "運行数", "運行日数", "走行km", "ETC回数", "ETC料金円"]
    lines = [",".join(cols)]

    def _q(s) -> str:
        s = str(s if s is not None else "")
        return '"' + s.replace('"', '""') + '"' if ("," in s or '"' in s) else s

    for r in result["rows"]:
        base = ([_q(r["key"]), _q(r["name"])] if axis == "vehicle"
                else [_q(r["key"]), _q(r["name"]), _q(r["office_code"] or "")])
        vals = base + [
            str(r["trip_count"]), str(r["day_count"]), f"{r['km']:.1f}",
            str(r["etc_count"]), str(r["etc_cost_yen"]),
        ]
        lines.append(",".join(vals))
    return lines
