"""労務簡易チェック(Phase N2) — Free Nippo 確定値(nippo_trips)の拘束時間判定。

労務値(拘束 restrict_sec 等)は Free Nippo の確定値のみを消費し、本システムで
生CSVから再計算しない(ADR-002)。集計は INTEGER 秒列の SUM のみ(契約 §2-2)。
上限は管理者設定値(SystemSetting)で法令に自動追従しない(R-27)。貨物基準のみ。
"""
import calendar
from datetime import date

from sqlalchemy.orm import Session

from app.importers.nippo_trip import normalize_driver_code
from app.models.master import Driver
from app.models.nippo import NippoTrip
from app.models.system import SystemSetting

# SystemSetting キー / 既定値。既定値は Free Nippo 既定(月284h・日13h)と同一
# = 契約 §2-4「両システム同一設定値の共有」。改正時は設定画面で数値更新(D-3)。
# 年間上限(3300h)は設計 §3.3 のとおり予約のみ — 画面表示すると実質判定に見え
# 免責「年間は未判定」と矛盾するため、キー自体を作らない。
LABOR_LIMIT_META = [
    {"key": "labor_restrict_day_limit_h",       "default": 13,  "label": "1日拘束・原則",
     "desc": "この時間を超えた日を黄色で表示します"},
    {"key": "labor_restrict_day_max_h",         "default": 15,  "label": "1日拘束・最大",
     "desc": "この時間を超えた日を赤で表示します(14時間超は週2回までが目安)"},
    {"key": "labor_restrict_day_longhaul_h",    "default": 16,  "label": "1日拘束・長距離特例",
     "desc": "この時間を超えた日を濃い赤で表示します(週2回・条件付きの特例)"},
    {"key": "labor_restrict_month_limit_h",     "default": 284, "label": "1か月拘束・原則",
     "desc": "月次一覧の上限。残時間はこの値から計算します"},
    {"key": "labor_restrict_month_agreement_h", "default": 310, "label": "1か月拘束・労使協定時",
     "desc": "労使協定がある場合の上限(年6か月までが目安)。超過は濃い赤で表示します"},
    {"key": "labor_month_warn_pct",             "default": 90,  "label": "月次の接近警告(原則上限比%)",
     "desc": "原則上限に対しこの割合以上に達した乗務員を黄色で表示します"},
]


def get_labor_limits(db: Session) -> dict:
    """労務上限の設定値。未設定・不正値は既定値。"""
    limits = {}
    for m in LABOR_LIMIT_META:
        row = db.query(SystemSetting).filter_by(key=m["key"]).first()
        try:
            limits[m["key"]] = int(float(row.value)) if row and row.value else m["default"]
        except (TypeError, ValueError):
            limits[m["key"]] = m["default"]
    return limits


def hmm(sec) -> str:
    """秒 → h:mm 表示(契約 §2-2: TEXT時刻のSUMは書かない。表示時のみ変換)。"""
    sec = int(sec or 0)
    sign = "-" if sec < 0 else ""
    sec = abs(sec)
    return f"{sign}{sec // 3600}:{(sec % 3600) // 60:02d}"


def day_status(sec: int, limits: dict) -> str:
    """日次セルの色分け。運行なし(none)は呼出側で判定。"""
    if sec > limits["labor_restrict_day_longhaul_h"] * 3600:
        return "darkred"
    if sec > limits["labor_restrict_day_max_h"] * 3600:
        return "red"
    if sec > limits["labor_restrict_day_limit_h"] * 3600:
        return "yellow"
    return "blue"


def month_status(total_sec: int, limits: dict) -> str:
    """月次行の色分け。原則上限の warn_pct% 以上で接近(黄)。"""
    if total_sec > limits["labor_restrict_month_agreement_h"] * 3600:
        return "darkred"
    if total_sec > limits["labor_restrict_month_limit_h"] * 3600:
        return "red"
    if total_sec >= limits["labor_restrict_month_limit_h"] * 3600 * limits["labor_month_warn_pct"] / 100:
        return "yellow"
    return "blue"


def driver_directory(db: Session) -> dict[str, dict]:
    """正規化コード → {name, office_code}(契約 §3: 照会は正規化キーで行う)。"""
    out = {}
    for d in db.query(Driver).all():
        out[normalize_driver_code(d.code)] = {"name": d.name, "office_code": d.office_code}
    return out


def month_trip_rows(db: Session, ym: str) -> list[NippoTrip]:
    """月次帰属は report_date(契約 §2-3)。"""
    return db.query(NippoTrip).filter(NippoTrip.report_date.like(f"{ym}-%")).all()


def _restrict_from_trip(trip) -> tuple[int, int] | None:
    """ESTRA 日報(TripReport)から拘束[秒]と近似フラグを算出。

    契約 §4 と同一定義: 拘束 = 終業 − 始業。始業/終業が欠損する運行は
    就業時間(employment_sec)で近似(approx=1・過少の恐れ)。両方無ければ None。
    Free Nippo の restrict_sec と同じ式なので、両ソースが並んでも値は一致する。
    """
    ws = getattr(trip, "work_start_datetime", None)
    we = getattr(trip, "work_end_datetime", None)
    if ws and we and we > ws:
        return int((we - ws).total_seconds()), 0
    emp = getattr(trip, "employment_sec", None)
    if emp:
        return int(emp), 1
    return None


def collect_labor_trips(db: Session, ym: str) -> list[dict]:
    """当月の労務値(拘束)を正規化して返す。ソース優先度は Free Nippo > ESTRA。

    - Free Nippo 確定値(nippo_trips)がある乗務員・月は**それを正**として使う(契約)。
    - Free Nippo に無い乗務員・月は ESTRA 日報(TripReport)から拘束を算出して補完する
      (Free Nippo 未導入の顧客でも労務チェックが機能する。ADR-002 追補=D-6)。
      両者は同一定義のため、後から Free Nippo を導入しても数値は整合する。
    - 二重計上防止: 同一乗務員・同一月で両ソースがある場合は Free Nippo のみ採用。

    返り値の各要素: {driver_code(正規化), driver_name, office_code, report_date,
                     start_dt, restrict_sec, restrict_approx, source('nippo'|'estra')}
    """
    from app.importers.nippo_trip import is_special_driver_code
    from app.models.csv_import import TripReport

    directory = driver_directory(db)
    out: list[dict] = []
    nippo_driver_codes: set[str] = set()

    for t in month_trip_rows(db, ym):
        nippo_driver_codes.add(t.driver_code)
        info = directory.get(t.driver_code)
        out.append({
            "driver_code": t.driver_code,
            "driver_name": info["name"] if info else f"{t.driver_code}(マスタ未登録)",
            "office_code": info["office_code"] if info else None,
            "report_date": t.report_date,
            "start_dt": t.start_dt,
            "restrict_sec": t.restrict_sec or 0,
            "restrict_approx": 1 if t.restrict_approx == 1 else 0,
            "source": "nippo",
        })

    # ESTRA 補完(Free Nippo に居ない乗務員・月のみ)
    y, m = int(ym[:4]), int(ym[5:7])
    start = date(y, m, 1)
    end = date(y, m, calendar.monthrange(y, m)[1])
    trips = (db.query(TripReport)
             .filter(TripReport.operation_date >= start,
                     TripReport.operation_date <= end).all())
    for t in trips:
        code = normalize_driver_code(t.driver_code or "")
        if not code or is_special_driver_code(code):
            continue
        if code in nippo_driver_codes:
            continue  # Free Nippo 側が正 — 二重計上しない
        r = _restrict_from_trip(t)
        if r is None:
            continue
        sec, approx = r
        info = directory.get(code)
        out.append({
            "driver_code": code,
            "driver_name": (t.driver_name or (info["name"] if info else code)),
            "office_code": t.driver_office_code or (info["office_code"] if info else None),
            "report_date": t.operation_date.isoformat(),
            "start_dt": (t.departure_datetime.isoformat()
                         if getattr(t, "departure_datetime", None) else None),
            "restrict_sec": sec,
            "restrict_approx": approx,
            "source": "estra",
        })
    return out


def _office_match_code(office_code, office: str | None) -> bool:
    if not office or office in ("all", "ALL"):
        return True
    return office_code == office


def _office_match(info: dict | None, office: str | None) -> bool:
    if not office or office in ("all", "ALL"):
        return True
    return bool(info) and info["office_code"] == office


def monthly_rows(db: Session, ym: str, office: str | None, limits: dict) -> list[dict]:
    """乗務員×当月の拘束合計・残・状態(契約 §4: SUM(COALESCE(restrict_sec,0)))。"""
    agg: dict[str, dict] = {}
    for t in collect_labor_trips(db, ym):
        if not _office_match_code(t["office_code"], office):
            continue
        a = agg.setdefault(t["driver_code"], {
            "total_sec": 0, "days": set(), "approx": 0,
            "name": t["driver_name"], "office_code": t["office_code"],
            "sources": set()})
        a["total_sec"] += t["restrict_sec"]
        a["days"].add(t["report_date"])
        if t["restrict_approx"] == 1:
            a["approx"] += 1
        a["sources"].add(t["source"])

    month_limit_sec = limits["labor_restrict_month_limit_h"] * 3600
    rows = []
    for code, a in agg.items():
        total_sec = a["total_sec"]
        # 表示は h:mm(分未満切り捨て)。残は「上限 − 表示された合計」で計算し、
        # 拘束合計 + 残時間 = 上限 が画面上も一致するようにする(独立丸めのズレ防止)。
        # 状態判定・近似の向きは正確な秒(total_sec)のまま。
        floored_total = (total_sec // 60) * 60
        rows.append({
            "driver_code": code,
            "driver_name": a["name"],
            "office_code": a["office_code"],
            "day_count": len(a["days"]),
            "total_sec": total_sec,
            # 近似(restrict_approx=1)は拘束の過少の恐れ → 残には「≦」を付け、
            # 合計側は「≧の可能性」注記のみ(設計 §3.4: 過大に働ける時間を出さない)
            "approx_count": a["approx"],
            "remain_sec": month_limit_sec - floored_total,
            "status": month_status(total_sec, limits),
            "source": "nippo" if "nippo" in a["sources"] else "estra",
        })
    rows.sort(key=lambda r: (-r["total_sec"], r["driver_name"], r["driver_code"]))
    return rows


def daily_matrix(db: Session, base: date, office: str | None, limits: dict):
    """乗務員×日付マトリクス(スピード管理表と同形)。セル=日の拘束合計。"""
    ym = f"{base.year:04d}-{base.month:02d}"
    last = calendar.monthrange(base.year, base.month)[1]
    days = list(range(1, last + 1))

    cells: dict[tuple[str, int], dict] = {}
    codes: set[str] = set()
    names: dict[str, str] = {}
    srcs: dict[str, set] = {}
    for t in collect_labor_trips(db, ym):
        if not _office_match_code(t["office_code"], office):
            continue
        code = t["driver_code"]
        codes.add(code)
        names.setdefault(code, t["driver_name"])
        srcs.setdefault(code, set()).add(t["source"])
        day = int(t["report_date"][8:10])
        c = cells.setdefault((code, day), {"sec": 0, "approx": False})
        c["sec"] += t["restrict_sec"]
        c["approx"] = c["approx"] or t["restrict_approx"] == 1

    def _name(code: str) -> str:
        return names.get(code, code)

    rows = []
    for code in sorted(codes, key=lambda c: (_name(c), c)):
        cell_list = []
        active = over_day = over_max = over_longhaul = 0
        total_sec = 0
        for day in days:
            c = cells.get((code, day))
            if c is None:
                cell_list.append({"day": day, "status": "none", "sec": 0, "approx": False})
                continue
            st = day_status(c["sec"], limits)
            active += 1
            total_sec += c["sec"]
            if st in ("yellow", "red", "darkred"):
                over_day += 1
            if st in ("red", "darkred"):
                over_max += 1
            if st == "darkred":
                over_longhaul += 1
            cell_list.append({"day": day, "status": st, "sec": c["sec"], "approx": c["approx"]})
        rows.append({
            "driver_code": code,
            "driver_name": _name(code),
            "cells": cell_list,
            "active_days": active,
            "total_sec": total_sec,
            "over_day": over_day,
            "over_max": over_max,
            "over_longhaul": over_longhaul,
            "source": "nippo" if "nippo" in srcs.get(code, set()) else "estra",
        })
    return days, rows


def available_nippo_months(db: Session) -> list[str]:
    """労務データのある月(新しい順、YYYY-MM)。Free Nippo ∪ ESTRA 日報。"""
    from sqlalchemy import func
    from app.models.csv_import import TripReport
    months = {m for (m,) in db.query(
        func.substr(NippoTrip.report_date, 1, 7)).distinct().all() if m}
    months |= {m for (m,) in db.query(
        func.strftime("%Y-%m", TripReport.operation_date)).distinct().all() if m}
    return sorted(months, reverse=True)


def last_import_at(db: Session):
    """取込最終日時(スナップショット性の表示用 — 契約 §5)。Free Nippo ∪ ESTRA。"""
    from sqlalchemy import func
    from app.models.csv_import import TripReport
    a = db.query(func.max(NippoTrip.imported_at)).scalar()
    b = db.query(func.max(TripReport.imported_at)).scalar()
    return max([x for x in (a, b) if x], default=None)
