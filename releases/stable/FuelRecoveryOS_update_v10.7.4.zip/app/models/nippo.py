"""Free Nippo 連携 — 運行別確定値(trips)のローカル永続コピー。

契約: C:\\Dev_work\\Free_nippo\\context\\portable\\04_FuelRecoveryOS連携境界.md
労務値(拘束時間等)は Free Nippo の確定値のみを消費し、本システムで生CSVから再計算しない(ADR-002)。
"""
from datetime import datetime

from sqlalchemy import DateTime, Float, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class NippoTrip(Base):
    """Free Nippo が確定した運行別値(1行=1運行=1日報)。

    取込は report_date 月単位の全置換 — Free Nippo 側で出庫日時が訂正されると
    trip_id 自体が変わるため、upsert では旧行が残留して二重計上する。
    """
    __tablename__ = "nippo_trips"

    trip_id: Mapped[str] = mapped_column(String(80), primary_key=True, comment="運行一意キー(顧客コード+出庫日時+車両コード)")
    driver_code: Mapped[str] = mapped_column(String(8), comment="乗務員コード(正規化済み: 先頭ゼロ除去)")
    report_date: Mapped[str] = mapped_column(String(10), comment="日報基準日 YYYY-MM-DD。月次帰属はこの列")
    start_dt: Mapped[str | None] = mapped_column(String(30), comment="出庫日時(ISO)。累計の順序境界")
    end_dt: Mapped[str | None] = mapped_column(String(30), comment="入庫日時(ISO)")
    restrict_sec: Mapped[int | None] = mapped_column(Integer, comment="拘束時間[秒]=ESTRA終業-始業")
    restrict_approx: Mapped[int | None] = mapped_column(Integer, comment="1=就業時間で近似(過少の恐れ)/0=実測/NULL=不明")
    drive_sec: Mapped[int | None] = mapped_column(Integer, comment="運転時間[秒]")
    rest_sec: Mapped[int | None] = mapped_column(Integer, comment="休憩時間[秒]")
    sleep_sec: Mapped[int | None] = mapped_column(Integer, comment="休息時間[秒]")
    total_km: Mapped[float | None] = mapped_column(Float, comment="走行km")
    toll_total: Mapped[int | None] = mapped_column(Integer, comment="通行料合計(参考値。費用の正はFR-OS側データ)")
    fuel_l: Mapped[float | None] = mapped_column(Float, comment="給油量L(参考値)")
    fuel_efficiency: Mapped[float | None] = mapped_column(Float, comment="燃費(参考値)")
    source_file: Mapped[str | None] = mapped_column(String(300), comment="取込元ファイル名")
    imported_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)

    __table_args__ = (
        Index("ix_nippo_trips_driver_date", "driver_code", "report_date"),
        Index("ix_nippo_trips_report_date", "report_date"),
    )


class NippoImportLog(Base):
    """Free Nippo trips CSV の取込履歴(append-only)。"""
    __tablename__ = "nippo_import_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    filename: Mapped[str] = mapped_column(String(300))
    status: Mapped[str] = mapped_column(String(20), index=True, comment="success/warning/error")
    months: Mapped[str | None] = mapped_column(String(100), comment="全置換した対象月(カンマ区切り YYYY-MM)")
    records_imported: Mapped[int] = mapped_column(Integer, default=0)
    records_replaced: Mapped[int] = mapped_column(Integer, default=0, comment="全置換で削除した既存行数")
    records_skipped: Mapped[int] = mapped_column(Integer, default=0, comment="特殊コード・不正行で除外した行数")
    warning_detail: Mapped[str | None] = mapped_column(Text)
    error_detail: Mapped[str | None] = mapped_column(Text)
    imported_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
