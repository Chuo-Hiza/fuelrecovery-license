"""モード設定の確認推奨運行 ルーター。"""
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.routers.month_utils import resolve_base_month, month_context
from app.services import mode_review as mode_review_svc

router = APIRouter(prefix="/analysis")
templates = Jinja2Templates(directory="app/templates")


@router.get("/mode-review")
async def mode_review_page(request: Request, db: Session = Depends(get_db)):
    """モード設定の確認推奨運行 一覧ページ。"""
    base = resolve_base_month(db, request.cookies.get("base_month"))
    results = mode_review_svc.get_review_results(db, base)
    return templates.TemplateResponse("analysis_mode_review.html", {
        "request": request,
        "current_page": "mode_review",
        "month_str": f"{base.year}年{base.month}月",
        "trips": results["trips"],
        "driver_ranking": results["driver_ranking"],
        "summary": results["summary"],
        "thresholds": {
            "min_hwy_min": mode_review_svc.MIN_HWY_SEC // 60,
            "low_avg_speed_hard": mode_review_svc.LOW_AVG_SPEED_HARD,
            "low_avg_speed_soft": mode_review_svc.LOW_AVG_SPEED_SOFT,
            "crawl_share_pct": int(mode_review_svc.CRAWL_SHARE_THRESHOLD * 100),
            "etc_lookback_days": mode_review_svc.ETC_LOOKBACK_DAYS,
            "score_threshold": mode_review_svc.SCORE_THRESHOLD,
        },
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("/mode-review/trip/{report_number}")
async def mode_review_trip(report_number: str, request: Request, db: Session = Depends(get_db)):
    """単一運行の軌跡を地図で表示。"""
    data = mode_review_svc.get_trip_trajectory(db, report_number)
    if not data:
        raise HTTPException(status_code=404, detail="運行が見つかりません")
    # 地図中心(有効 GPS 点があればその平均、無ければデフォルト東京)
    pts = data["points"]
    if pts:
        center_lat = sum(p["lat"] for p in pts) / len(pts)
        center_lon = sum(p["lon"] for p in pts) / len(pts)
    else:
        center_lat, center_lon = 35.68, 139.76
    return templates.TemplateResponse("analysis_mode_review_trip.html", {
        "request": request,
        "current_page": "mode_review",
        "trip": data["trip"],
        "evaluation": data["evaluation"],
        "pace_breakdown": data.get("pace_breakdown"),
        "mode_thresholds": data.get("thresholds"),
        "is_etc_linked": data["is_etc_linked"],
        "points": data["points"],
        "points_skipped": data.get("points_skipped", 0),
        "ts_rows_total": data.get("ts_rows_total", 0),
        "ts_imported": data.get("ts_imported", False),
        "ts_all_count": data.get("ts_all_count", 0),
        "ts_gps_rows": data.get("ts_gps_rows", 0),
        "toll_records": data["toll_records"],
        "center_lat": center_lat,
        "center_lon": center_lon,
        **month_context(db, request.cookies.get("base_month")),
    })
