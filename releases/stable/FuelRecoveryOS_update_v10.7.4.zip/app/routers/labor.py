"""労務(Free Nippo 連携) — 確定値CSVの取込 + 拘束時間の月次/日次チェック。

Phase N1: 取込基盤(/labor/import)。Phase N2: /labor/monthly・/labor/daily。
表示は参考値であり法令遵守の保証ではない(R-27 — 免責は各テンプレートに固定表示)。
"""
import logging
import re
from datetime import date

from fastapi import APIRouter, Depends, File, Request, UploadFile
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import desc, func
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.importers.nippo_trip import import_nippo_trips_csv
from app.models.nippo import NippoImportLog, NippoTrip
from app.routers.month_utils import month_context, resolve_base_month
from app.services import labor_check, rollup

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/labor", tags=["labor"])
templates = Jinja2Templates(directory="app/templates")

_YM_RE = re.compile(r"^\d{4}-\d{2}$")


def _resolve_labor_month(request: Request, db: Session, month: str | None) -> date:
    """?month=YYYY-MM を優先し、無ければ全画面共通の基軸月 cookie。

    Free Nippo データは Estra CSV より先行して存在し得るため、cookie の
    有効月リスト(TripReport 由来)に縛られない月指定を受け付ける。
    """
    if month and _YM_RE.match(month):
        try:
            return date(int(month[:4]), int(month[5:7]), 1)
        except ValueError:
            pass
    return resolve_base_month(db, request.cookies.get("base_month"))


def _office_name(db: Session, office: str) -> str:
    if not office or office in ("all", "ALL"):
        return "全営業所"
    for o in rollup.list_offices(db):
        if o["code"] == office:
            return o["name"]
    return office


def _labor_page_context(request: Request, db: Session, month: str | None, office: str):
    base = _resolve_labor_month(request, db, month)
    ym = f"{base.year:04d}-{base.month:02d}"
    limits = labor_check.get_labor_limits(db)
    return base, ym, limits, {
        "request": request,
        "base": base,
        "ym": ym,
        "limits": limits,
        "offices": rollup.list_offices(db),
        "selected_office": office,
        "office_name": _office_name(db, office),
        "nippo_months": labor_check.available_nippo_months(db),
        "last_import_at": labor_check.last_import_at(db),
        "hmm": labor_check.hmm,
        **month_context(db, request.cookies.get("base_month")),
    }


@router.get("/monthly")
async def labor_monthly(
    request: Request,
    month: str | None = None,
    office: str = "all",
    db: Session = Depends(get_db),
):
    """拘束時間 月次一覧 — 乗務員×当月の合計・上限・残・色分け。"""
    base, ym, limits, ctx = _labor_page_context(request, db, month, office)
    rows = labor_check.monthly_rows(db, ym, office, limits)
    return templates.TemplateResponse("labor_monthly.html", {
        **ctx,
        "current_page": "labor_monthly",
        "rows": rows,
    })


@router.get("/daily")
async def labor_daily(
    request: Request,
    month: str | None = None,
    office: str = "all",
    db: Session = Depends(get_db),
):
    """拘束時間 日次チェック — 乗務員×日付マトリクス。"""
    base, ym, limits, ctx = _labor_page_context(request, db, month, office)
    days, rows = labor_check.daily_matrix(db, base, office, limits)
    return templates.TemplateResponse("labor_daily.html", {
        **ctx,
        "current_page": "labor_daily",
        "days": days,
        "rows": rows,
    })


@router.get("/import")
async def labor_import_page(request: Request, db: Session = Depends(get_db)):
    """Free Nippo trips CSV の取込画面 + 取込ログ・保有データ状況。"""
    logs = db.query(NippoImportLog).order_by(desc(NippoImportLog.imported_at)).limit(50).all()

    month_col = func.substr(NippoTrip.report_date, 1, 7)
    month_counts = (
        db.query(month_col, func.count(NippoTrip.trip_id))
        .group_by(month_col)
        .order_by(desc(month_col))
        .limit(24)
        .all()
    )
    total_trips = db.query(func.count(NippoTrip.trip_id)).scalar() or 0

    return templates.TemplateResponse("labor_import.html", {
        "request": request,
        "current_page": "labor_import",
        "logs": logs,
        "month_counts": month_counts,
        "total_trips": total_trips,
    })


@router.post("/import")
async def labor_import_post(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """アップロードされた Free Nippo trips CSV を月単位全置換で取込。"""
    raw = await file.read()
    result = import_nippo_trips_csv(file.filename or "uploaded.csv", raw, db)
    if result.get("status") == "error":
        return RedirectResponse(url="/labor/import?result=error", status_code=303)
    return RedirectResponse(
        url=f"/labor/import?result={result['status']}&imported={result['imported']}",
        status_code=303,
    )
