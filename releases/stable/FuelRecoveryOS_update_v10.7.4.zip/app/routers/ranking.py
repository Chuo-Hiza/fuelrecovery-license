"""安全運転ランキング（営業所内版・項目別統合）— 第1波 ②⑤。

1画面で「総合評価（安全運転）」をデフォルトに、各指導項目（急加速/急減速/…/連続走行）を
タブで並べ替えできる。選択列を強調。A4印刷帳票も出力。
読み取りのみ・スキーマ変更なし（区分A）。補正は将来 overlay で別途。
"""
from datetime import date

from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.routers.month_utils import resolve_base_month, month_context
from app.services import rollup

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# 並べ替えタブ（key, ラベル）。先頭=デフォルト＝総合評価（安全運転）。
RANKING_TABS = [
    ("safety", "総合評価"),
    ("accel", "急加速"),
    ("decel", "急減速"),
    ("start", "急発進"),
    ("speed_over", "速度超過"),
    ("rpm_over", "回転数オーバー"),
    ("continuous", "連続走行"),
]


def _fmt_hms(sec) -> str:
    """秒 → H:MM（連続走行時間表示）。"""
    s = int(sec or 0)
    h, rem = divmod(s, 3600)
    return f"{h}:{rem // 60:02d}"


def _avg_row(rows: list[dict]):
    """平均行（数値項目の平均）。空なら None。"""
    if not rows:
        return None
    n = len(rows)

    def avg_of(field):
        vals = [r[field] for r in rows if r.get(field) is not None]
        return round(sum(vals) / len(vals), 1) if vals else None

    return {
        "trip_count": round(sum(r["trip_count"] for r in rows) / n, 1),
        "sudden_start": round(sum(r["sudden_start"] for r in rows) / n, 1),
        "sudden_accel": round(sum(r["sudden_accel"] for r in rows) / n, 1),
        "sudden_decel": round(sum(r["sudden_decel"] for r in rows) / n, 1),
        "speed_over": round(sum(r["speed_over"] for r in rows) / n, 1),
        "rpm_over": round(sum(r["rpm_over"] for r in rows) / n, 1),
        "avg_overall_score": avg_of("avg_overall_score"),
    }


def _office_name(db: Session, office: str) -> str:
    if not office or office in ("all", "ALL"):
        return "全営業所"
    for o in rollup.list_offices(db):
        if o["code"] == office:
            return o["name"]
    return office


def _ranking_rows(db: Session, base: date, office: str, key: str = "safety") -> list[dict]:
    trips = rollup.month_trips(db, base, office)
    rows = rollup.rank_drivers(rollup.aggregate_by_driver(trips), key)
    for r in rows:
        r["continuous_hms"] = _fmt_hms(r["max_continuous_sec"])
    return rows


def _norm_item(item: str) -> str:
    return item if item in dict(RANKING_TABS) else "safety"


# 抽出フィルタ（key, ラベル）
RANKING_FILTERS = [
    ("all", "全員"),
    ("430", "430注意"),
    ("target", "指導対象"),
]


def _norm_filter(f: str) -> str:
    return f if f in dict(RANKING_FILTERS) else "all"


def _apply_filter(rows: list[dict], sel_field: str, mode: str, avg_row) -> list[dict]:
    """選択中の並べ替え項目に対して抽出する。順位・平均は全体基準のまま。

    - 430   : 連続走行4時間超（is_430_warn）のみ
    - target: 指導対象＝選択項目で「平均より悪い」乗務員のみ
              （総合評価=平均未満 / カウント系=平均超 / 連続走行=430該当）
    """
    if mode == "430":
        return [r for r in rows if r.get("is_430_warn")]
    if mode == "target":
        if sel_field == "max_continuous_sec":
            return [r for r in rows if r.get("is_430_warn")]
        thr = (avg_row or {}).get(sel_field)
        if thr is None:
            return rows
        if sel_field == "avg_overall_score":  # 高い=良い → 平均未満が指導対象
            return [r for r in rows if r.get(sel_field) is not None and r[sel_field] < thr]
        return [r for r in rows if (r.get(sel_field) or 0) > thr]  # 高い=悪い
    return rows


@router.get("/ranking/safety")
async def ranking_safety(request: Request, item: str = "safety", office: str = "all",
                         filter: str = "all", db: Session = Depends(get_db)):
    item = _norm_item(item)
    mode = _norm_filter(filter)
    base = resolve_base_month(db, request.cookies.get("base_month"))
    rows = _ranking_rows(db, base, office, item)
    sel_field, _desc, sel_label = rollup.RANK_KEYS[item]
    avg = _avg_row(rows)  # 平均は全体基準（フィルタ前）
    shown = _apply_filter(rows, sel_field, mode, avg)
    return templates.TemplateResponse("ranking_safety.html", {
        "request": request,
        "current_page": "ranking_safety",
        "rows": shown,
        "total_count": len(rows),
        "avg": avg,
        "tabs": RANKING_TABS,
        "item": item,
        "filters": RANKING_FILTERS,
        "filter_mode": mode,
        "sel_field": sel_field,
        "sel_label": sel_label,
        "offices": rollup.list_offices(db),
        "selected_office": office,
        "office_name": _office_name(db, office),
        "base": base,
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("/ranking/safety/print")
async def ranking_safety_print(request: Request, item: str = "safety", office: str = "all",
                               filter: str = "all", db: Session = Depends(get_db)):
    item = _norm_item(item)
    mode = _norm_filter(filter)
    base = resolve_base_month(db, request.cookies.get("base_month"))
    rows = _ranking_rows(db, base, office, item)
    _f, _d, sel_label = rollup.RANK_KEYS[item]
    avg = _avg_row(rows)
    shown = _apply_filter(rows, _f, mode, avg)
    filter_label = dict(RANKING_FILTERS).get(mode, "全員")
    return templates.TemplateResponse("ranking_safety_print.html", {
        "request": request,
        "rows": shown,
        "avg": avg,
        "office_name": _office_name(db, office),
        "sel_label": sel_label,
        "filter_label": filter_label,
        "base": base,
    })
