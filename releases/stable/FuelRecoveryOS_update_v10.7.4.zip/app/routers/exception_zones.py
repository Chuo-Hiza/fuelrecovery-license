"""速度超過 例外区間マスター — 第2波 ⑥（スパイクGO）。

TripTimeseries（分単位・速度+GPSをほぼ全件保持）から「速度 > 閾値」の点を抽出し、
登録された矩形（例外区間）内に入るかを突合する。判定カウントは変更せず、
「例外区間内の超過（確認候補）」として非破壊で注記するためのマスター管理。
"""
from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.operations import SpeedExceptionZone
from app.models.csv_import import TripTimeseries
from app.models.system import SystemSetting

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

SPEED_LIMIT_KEY = "speed_over_check_kmh"
DEFAULT_SPEED_LIMIT = 80


def get_speed_limit(db: Session) -> int:
    row = db.query(SystemSetting).filter_by(key=SPEED_LIMIT_KEY).first()
    try:
        return int(row.value) if row and row.value else DEFAULT_SPEED_LIMIT
    except (TypeError, ValueError):
        return DEFAULT_SPEED_LIMIT


def active_zones(db: Session) -> list[SpeedExceptionZone]:
    return (db.query(SpeedExceptionZone)
            .filter(SpeedExceptionZone.is_active == True)  # noqa: E712
            .all())


def point_in_zones(zones: list[SpeedExceptionZone], lat_e5: int, lon_e5: int) -> str | None:
    """点(×10^5)が有効な矩形のいずれかに入れば区間名を返す。"""
    for z in zones:
        if z.min_lat <= lat_e5 <= z.max_lat and z.min_lon <= lon_e5 <= z.max_lon:
            return z.name
    return None


def speed_over_zone_check(db: Session, report_number: str, limit_kmh: int | None = None) -> dict:
    """運行の「速度 > 閾値」点を抽出し、各点が例外区間に入るか判定（非破壊・参考）。"""
    limit = limit_kmh if limit_kmh is not None else get_speed_limit(db)
    zones = active_zones(db)
    rows = (db.query(TripTimeseries)
            .filter(TripTimeseries.report_number == report_number,
                    TripTimeseries.speed_kmh > limit,
                    TripTimeseries.gps_lat.isnot(None), TripTimeseries.gps_lat != 0,
                    TripTimeseries.gps_lon.isnot(None), TripTimeseries.gps_lon != 0)
            .order_by(TripTimeseries.recorded_at.asc()).all())
    points = []
    in_zone = 0
    for r in rows:
        zname = point_in_zones(zones, r.gps_lat, r.gps_lon)
        if zname:
            in_zone += 1
        points.append({
            "time": r.recorded_at.strftime("%H:%M") if r.recorded_at else "—",
            "speed": r.speed_kmh,
            "lat": r.gps_lat / 100000.0,
            "lon": r.gps_lon / 100000.0,
            "zone": zname,
        })
    return {
        "limit": limit,
        "total": len(points),
        "in_zone": in_zone,
        "points": points,
        "zones_defined": len(zones),
    }


# ── マスター CRUD ─────────────────────────────────────────────
@router.get("/settings/exception-zones")
async def zones_list(request: Request, db: Session = Depends(get_db)):
    zones = (db.query(SpeedExceptionZone)
             .order_by(SpeedExceptionZone.is_active.desc(), SpeedExceptionZone.id.desc()).all())
    return templates.TemplateResponse("exception_zones.html", {
        "request": request,
        "current_page": "settings",
        "zones": zones,
        "speed_limit": get_speed_limit(db),
    })


@router.post("/settings/exception-zones/limit")
async def zones_set_limit(request: Request, speed_limit: str = Form(...),
                          db: Session = Depends(get_db)):
    """速度超過チェック閾値(km/h)を設定。実データでの検証時に下げられる。"""
    try:
        val = int(float(speed_limit))
    except (TypeError, ValueError):
        return RedirectResponse(url="/settings/exception-zones?error=1", status_code=303)
    val = max(1, min(200, val))
    row = db.query(SystemSetting).filter_by(key=SPEED_LIMIT_KEY).first()
    if row:
        row.value = str(val)
    else:
        db.add(SystemSetting(key=SPEED_LIMIT_KEY, value=str(val),
                             description="速度超過チェック閾値(km/h)"))
    db.commit()
    return RedirectResponse(url="/settings/exception-zones", status_code=303)


def _to_e5(v: str) -> int:
    return int(round(float(v) * 100000))


@router.post("/settings/exception-zones")
async def zones_add(request: Request,
                    name: str = Form(...),
                    road_category: str = Form(""),
                    lat1: str = Form(...), lon1: str = Form(...),
                    lat2: str = Form(...), lon2: str = Form(...),
                    note: str = Form(""),
                    db: Session = Depends(get_db)):
    try:
        a_lat, b_lat = _to_e5(lat1), _to_e5(lat2)
        a_lon, b_lon = _to_e5(lon1), _to_e5(lon2)
    except (TypeError, ValueError):
        return RedirectResponse(url="/settings/exception-zones?error=1", status_code=303)
    if not name.strip():
        return RedirectResponse(url="/settings/exception-zones?error=1", status_code=303)
    db.add(SpeedExceptionZone(
        name=name.strip(), road_category=road_category.strip() or None,
        min_lat=min(a_lat, b_lat), max_lat=max(a_lat, b_lat),
        min_lon=min(a_lon, b_lon), max_lon=max(a_lon, b_lon),
        note=note.strip() or None, is_active=True,
    ))
    db.commit()
    return RedirectResponse(url="/settings/exception-zones", status_code=303)


@router.post("/settings/exception-zones/{zone_id}/delete")
async def zones_delete(request: Request, zone_id: int, db: Session = Depends(get_db)):
    z = db.query(SpeedExceptionZone).filter_by(id=zone_id).first()
    if z:
        db.delete(z)
        db.commit()
    return RedirectResponse(url="/settings/exception-zones", status_code=303)
