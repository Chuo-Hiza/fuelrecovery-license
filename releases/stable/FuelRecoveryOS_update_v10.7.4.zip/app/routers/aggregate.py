"""期間集計(Phase N3) — /aggregate/period。旧 FR-31/32(Free Nippo 期間集計)の移設。

ETC・給油・走行km は FR-OS 既存取込(Estra)が正、拘束時間は Free Nippo 確定値(D-2/ADR-002)。
Excel 出力は行わず CSV + 印刷用 HTML(新規 pip 依存を増やさない既存方針)。
"""
from datetime import datetime

from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.routers.month_utils import get_available_months, month_context, resolve_base_month
from app.services import period_aggregate, rollup

router = APIRouter(prefix="/aggregate", tags=["aggregate"])
templates = Jinja2Templates(directory="app/templates")


def _month_options(db: Session) -> list[str]:
    """選択肢 = Estra 運行のある月(新しい順)。本画面は Estra 実測値のみを扱う。"""
    months = {f"{d.year:04d}-{d.month:02d}" for d in get_available_months(db)}
    return sorted(months, reverse=True)


def _resolve_params(request: Request, db: Session, ym_from: str | None,
                    ym_to: str | None, office: str, axis: str):
    base = resolve_base_month(db, request.cookies.get("base_month"))
    default_ym = f"{base.year:04d}-{base.month:02d}"
    ym_from = period_aggregate.parse_ym(ym_from) or default_ym
    ym_to = period_aggregate.parse_ym(ym_to) or ym_from
    if ym_to < ym_from:
        ym_from, ym_to = ym_to, ym_from
    axis = axis if axis in ("driver", "vehicle") else "driver"
    result = period_aggregate.aggregate_period(db, ym_from, ym_to, office, axis)
    return ym_from, ym_to, axis, result


def _office_name(db: Session, office: str) -> str:
    if not office or office in ("all", "ALL"):
        return "全営業所"
    for o in rollup.list_offices(db):
        if o["code"] == office:
            return o["name"]
    return office


def _common_ctx(request: Request, db: Session, ym_from: str, ym_to: str,
                office: str, axis: str, result: dict) -> dict:
    return {
        "request": request,
        "ym_from": ym_from,
        "ym_to": ym_to,
        "axis": axis,
        "result": result,
        "offices": rollup.list_offices(db),
        "selected_office": office,
        "office_name": _office_name(db, office),
        "timestamps": period_aggregate.source_timestamps(db),
        "printed_at": datetime.now(),
    }


@router.get("/period")
async def aggregate_period_page(
    request: Request,
    ym_from: str | None = None,
    ym_to: str | None = None,
    office: str = "all",
    axis: str = "driver",
    db: Session = Depends(get_db),
):
    """期間集計画面 — 期間(月range)×乗務員/車両。"""
    ym_from, ym_to, axis, result = _resolve_params(request, db, ym_from, ym_to, office, axis)
    return templates.TemplateResponse("aggregate_period.html", {
        **_common_ctx(request, db, ym_from, ym_to, office, axis, result),
        "current_page": "aggregate_period",
        "month_options": _month_options(db),
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("/period/csv")
async def aggregate_period_csv(
    request: Request,
    ym_from: str | None = None,
    ym_to: str | None = None,
    office: str = "all",
    axis: str = "driver",
    db: Session = Depends(get_db),
):
    """CSV ダウンロード(UTF-8 BOM・Excel想定)。"""
    ym_from, ym_to, axis, result = _resolve_params(request, db, ym_from, ym_to, office, axis)
    ts = period_aggregate.source_timestamps(db)
    meta = (
        f"# 期間: {ym_from}〜{ym_to} / {_office_name(db, office)} / 軸: "
        + ("車両" if axis == "vehicle" else "乗務員")
        + f" / 出力: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        + (f" / Estra取込最終: {ts['estra_last'].strftime('%Y-%m-%d %H:%M')}" if ts["estra_last"] else "")
    )
    lines = [meta] + period_aggregate.csv_lines(result, axis)
    body = "﻿" + "\r\n".join(lines) + "\r\n"
    fname = f"period_{ym_from.replace('-', '')}-{ym_to.replace('-', '')}_{axis}.csv"
    return Response(
        content=body,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


_DATE_RE_STR = r"\d{4}-\d{2}-\d{2}"


def _resolve_etc_dates(request: Request, db: Session, d_from: str | None,
                       d_to: str | None):
    """年月日Range(単日可)。既定は基軸月の1日〜末日。逆転は入替。上限366日。"""
    import re
    from datetime import date as _date, timedelta
    from app.routers.month_utils import month_last_day

    base = resolve_base_month(db, request.cookies.get("base_month"))

    def _parse(v):
        if v and re.fullmatch(_DATE_RE_STR, v):
            try:
                return _date.fromisoformat(v)
            except ValueError:
                return None
        return None

    f = _parse(d_from) or base
    t = _parse(d_to) or (_parse(d_from) or month_last_day(base))
    if t < f:
        f, t = t, f
    if (t - f).days > 366:
        t = f + timedelta(days=366)
    return f, t


@router.get("/etc")
async def aggregate_etc_page(
    request: Request,
    date_from: str | None = None,
    date_to: str | None = None,
    office: str = "all",
    db: Session = Depends(get_db),
):
    """ETC明細の年月日Range閲覧(単日可・精査補助)。"""
    f, t = _resolve_etc_dates(request, db, date_from, date_to)
    result = period_aggregate.etc_detail(db, f, t, office)
    return templates.TemplateResponse("aggregate_etc.html", {
        "request": request,
        "current_page": "aggregate_period",
        "date_from": f.isoformat(),
        "date_to": t.isoformat(),
        "result": result,
        "offices": rollup.list_offices(db),
        "selected_office": office,
        "office_name": _office_name(db, office),
        "timestamps": period_aggregate.source_timestamps(db),
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("/etc/csv")
async def aggregate_etc_csv(
    request: Request,
    date_from: str | None = None,
    date_to: str | None = None,
    office: str = "all",
    db: Session = Depends(get_db),
):
    f, t = _resolve_etc_dates(request, db, date_from, date_to)
    result = period_aggregate.etc_detail(db, f, t, office)
    meta = (f"# ETC明細 {f.isoformat()}〜{t.isoformat()} / {_office_name(db, office)}"
            f" / 出力: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            " / 本一覧は精査補助(参考)。請求の証憑はETC利用照会サービス等を正としてください")
    lines = [meta] + period_aggregate.etc_csv_lines(result)
    body = "﻿" + "\r\n".join(lines) + "\r\n"
    fname = f"etc_{f.isoformat()}_{t.isoformat()}.csv"
    return Response(
        content=body,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


@router.get("/period/print")
async def aggregate_period_print(
    request: Request,
    ym_from: str | None = None,
    ym_to: str | None = None,
    office: str = "all",
    axis: str = "driver",
    db: Session = Depends(get_db),
):
    """印刷用 A4 横(算出時点を必ず印字 — 契約 §5 スナップショット性)。"""
    ym_from, ym_to, axis, result = _resolve_params(request, db, ym_from, ym_to, office, axis)
    return templates.TemplateResponse(
        "aggregate_period_print.html",
        _common_ctx(request, db, ym_from, ym_to, office, axis, result),
    )
