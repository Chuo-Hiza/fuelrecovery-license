"""運行の急加減速 実データ確認支援 — 第1波 ⑦。

trip_events(E204=急加減速: G値/速度/GPS/時刻) と trip_timeseries(分速度) を突合し、
イベント時刻の速度・回転数・G値を「説明できる粒度」で表示する。速度推移グラフは補助、
イベント表を主（G値未格納でも表は機能）。読み取りのみ・スキーマ変更なし（区分A）。
"""
from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.csv_import import TripReport, TripEvent, TripTimeseries
from app.routers.exception_zones import speed_over_zone_check

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

ACCEL_EVENT_TYPE = "E204"  # 急加減速イベント（Estra コード）


def _safe_back(back: str) -> str | None:
    if back and back.startswith("/") and not back.startswith("//"):
        return back
    return None


def get_accel_detail(db: Session, report_number: str) -> dict | None:
    trip = db.query(TripReport).filter_by(report_number=report_number).first()
    if not trip:
        return None

    ts_rows = (db.query(TripTimeseries)
               .filter(TripTimeseries.report_number == report_number)
               .order_by(TripTimeseries.recorded_at.asc()).all())
    labels, speeds, rpms = [], [], []
    ts_by_min: dict[str, tuple] = {}
    for r in ts_rows:
        if not r.recorded_at:
            continue
        hm = r.recorded_at.strftime("%H:%M")
        labels.append(hm)
        speeds.append(r.speed_kmh or 0)
        rpms.append(r.engine_rpm or 0)
        ts_by_min.setdefault(hm, (r.speed_kmh, r.engine_rpm))
    label_index = {hm: i for i, hm in enumerate(labels)}

    evs = (db.query(TripEvent)
           .filter(TripEvent.report_number == report_number,
                   TripEvent.event_type == ACCEL_EVENT_TYPE)
           .order_by(TripEvent.event_datetime.asc()).all())
    events, markers = [], []
    for e in evs:
        hm = e.event_datetime.strftime("%H:%M") if e.event_datetime else ""
        spd, rpm = e.speed_kmh, e.engine_rpm
        if (spd is None or rpm is None) and hm in ts_by_min:
            f_spd, f_rpm = ts_by_min[hm]
            spd = spd if spd is not None else f_spd
            rpm = rpm if rpm is not None else f_rpm
        direction = None
        if e.g_value_x is not None:
            direction = "加速" if e.g_value_x >= 0 else "減速"
        extra = e.extra_fields or {}
        events.append({
            "time": e.event_datetime.strftime("%H:%M:%S") if e.event_datetime else "—",
            "speed": spd, "rpm": rpm,
            "gx": e.g_value_x, "gy": e.g_value_y, "direction": direction,
            "heading": extra.get("heading_deg"),
        })
        if hm in label_index:
            markers.append({"i": label_index[hm], "speed": spd if spd is not None else speeds[label_index[hm]]})

    return {
        "trip": {
            "report_number": trip.report_number,
            "operation_date": trip.operation_date,
            "driver_code": trip.driver_code,
            "driver_name": trip.driver_name or trip.driver_code,
            "vehicle_name": trip.vehicle_name or trip.vehicle_code,
            "sudden_accel": trip.sudden_accel_count or 0,
            "sudden_decel": trip.sudden_decel_count or 0,
            "sudden_start": trip.sudden_start_count or 0,
        },
        "labels": labels,
        "speeds": speeds,
        "rpms": rpms,
        "events": events,
        "markers": markers,
        "has_gvalue": any(e["gx"] is not None for e in events),
        "has_timeseries": bool(labels),
    }


@router.get("/trip/{report_number}/accel-detail")
async def accel_detail(request: Request, report_number: str,
                       back: str = "", back_label: str = "",
                       db: Session = Depends(get_db)):
    detail = get_accel_detail(db, report_number)
    if detail is None:
        return templates.TemplateResponse("trip_accel_detail.html", {
            "request": request, "current_page": "coaching", "detail": None,
            "back_href": _safe_back(back) or "/coaching", "back_label": back_label or "戻る",
        })
    drv = detail["trip"]["driver_code"]
    speed_check = speed_over_zone_check(db, report_number)
    return templates.TemplateResponse("trip_accel_detail.html", {
        "request": request,
        "current_page": "coaching",
        "detail": detail,
        "speed_check": speed_check,
        "back_href": _safe_back(back) or (f"/coaching/{drv}" if drv else "/coaching"),
        "back_label": back_label or "面談カードに戻る",
    })
