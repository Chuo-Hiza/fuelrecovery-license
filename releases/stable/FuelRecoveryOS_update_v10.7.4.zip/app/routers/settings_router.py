"""Settings router — 指導書自動判別条件などシステム設定管理。"""
import json
from datetime import datetime

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.master import Vehicle
from app.models.system import SystemSetting
from app.services.labor_check import LABOR_LIMIT_META, get_labor_limits

DEFAULT_BASELINE_EFFICIENCY = 5.0  # km/L — 車両別基準燃費の未設定時デフォルト

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# 判別条件の定義（field, label, op, unit, default_threshold, default_enabled）
CRITERIA_META = [
    {"field": "avg_score",        "label": "総合評価点",     "op": "lte", "unit": "点", "default": 70,  "enabled": True},
    {"field": "avg_safety",       "label": "安全評価",       "op": "lte", "unit": "点", "default": 70,  "enabled": False},
    {"field": "avg_economy",      "label": "経済評価",       "op": "lte", "unit": "点", "default": 70,  "enabled": False},
    {"field": "idle_rate",        "label": "アイドリング率",  "op": "gte", "unit": "%",  "default": 15,  "enabled": True},
    {"field": "events_per_100km", "label": "急操作/100km",   "op": "gte", "unit": "回", "default": 3.0, "enabled": True},
    {"field": "speed_over",       "label": "速度超過",       "op": "gte", "unit": "回", "default": 5,   "enabled": False},
]

SETTING_KEY = "coaching_auto_criteria"
FUEL_PRICE_KEY = "fuel_price"
FUEL_PRICE_DEFAULT = 162  # yen/L


def get_fuel_price(db: Session, month: str | None = None) -> float:
    """軽油単価を取得(月別対応・2026-07-24 顧客FB①)。

    参照ルール: 対象月の月別単価 → それ以前で最新の月別単価 → 既定値(従来キー)
    → デフォルト。過去月は当時の単価が保持され、以後の月は最新設定が効く。
    """
    if month:
        rows = (db.query(SystemSetting)
                .filter(SystemSetting.key.like(f"{FUEL_PRICE_KEY}_____-__"))
                .all())
        candidates = []
        for r in rows:
            m = r.key[len(FUEL_PRICE_KEY) + 1:]
            if m <= month:
                try:
                    candidates.append((m, float(r.value)))
                except (ValueError, TypeError):
                    pass
        if candidates:
            return max(candidates)[1]   # 対象月以前で最新の月
    row = db.query(SystemSetting).filter(SystemSetting.key == FUEL_PRICE_KEY).first()
    if row:
        try:
            return float(row.value)
        except (ValueError, TypeError):
            pass
    return float(FUEL_PRICE_DEFAULT)


def list_monthly_fuel_prices(db: Session) -> list[dict]:
    """月別単価の履歴(新しい月順)。設定画面の一覧表示用。"""
    rows = (db.query(SystemSetting)
            .filter(SystemSetting.key.like(f"{FUEL_PRICE_KEY}_____-__"))
            .all())
    out = []
    for r in rows:
        try:
            out.append({"month": r.key[len(FUEL_PRICE_KEY) + 1:],
                        "price": float(r.value)})
        except (ValueError, TypeError):
            continue
    out.sort(key=lambda x: x["month"], reverse=True)
    return out


def get_criteria(db: Session) -> list:
    """DBから判別条件を取得。未設定の場合はデフォルト値を返す。"""
    row = db.query(SystemSetting).filter(SystemSetting.key == SETTING_KEY).first()
    if row:
        saved = {c["field"]: c for c in json.loads(row.value)}
        result = []
        for m in CRITERIA_META:
            c = saved.get(m["field"], {})
            result.append({
                "field":     m["field"],
                "label":     m["label"],
                "op":        m["op"],
                "unit":      m["unit"],
                "threshold": c.get("threshold", m["default"]),
                "enabled":   c.get("enabled", m["enabled"]),
            })
        return result
    # 初回: デフォルト
    return [
        {"field": m["field"], "label": m["label"], "op": m["op"],
         "unit": m["unit"], "threshold": m["default"], "enabled": m["enabled"]}
        for m in CRITERIA_META
    ]


def get_vehicle_baseline(db: Session, vehicle_code: str) -> float:
    """車両の基準燃費を取得。未設定時はデフォルト値を返す。"""
    v = db.query(Vehicle).filter(Vehicle.code == vehicle_code).first()
    if v and v.baseline_efficiency_kml is not None:
        return v.baseline_efficiency_kml
    return DEFAULT_BASELINE_EFFICIENCY


@router.get("/settings")
async def settings_page(request: Request, db: Session = Depends(get_db)):
    criteria = get_criteria(db)
    saved = db.query(SystemSetting).filter(SystemSetting.key == SETTING_KEY).first()
    updated_at = saved.updated_at.strftime("%Y/%m/%d %H:%M") if saved and saved.updated_at else None
    fuel_price = get_fuel_price(db)

    # 車両プロファイル
    vehicles = db.query(Vehicle).filter(Vehicle.is_active == 1).order_by(Vehicle.code).all()

    return templates.TemplateResponse("settings.html", {
        "request": request,
        "current_page": "settings",
        "criteria": criteria,
        "updated_at": updated_at,
        "fuel_price": fuel_price,
        "fuel_price_default": FUEL_PRICE_DEFAULT,
        "monthly_fuel_prices": list_monthly_fuel_prices(db),
        "current_month": datetime.now().strftime("%Y-%m"),
        "labor_limit_meta": LABOR_LIMIT_META,
        "labor_limits": get_labor_limits(db),
        "vehicles": vehicles,
        "default_efficiency": DEFAULT_BASELINE_EFFICIENCY,
        "profile_saved": request.query_params.get("profile_saved"),
    })


@router.post("/settings")
async def save_settings(request: Request, db: Session = Depends(get_db)):
    form = await request.form()
    criteria = []
    for m in CRITERIA_META:
        f = m["field"]
        raw = form.get(f"threshold_{f}", str(m["default"]))
        try:
            threshold = float(raw)
        except ValueError:
            threshold = float(m["default"])
        criteria.append({
            "field":     f,
            "label":     m["label"],
            "op":        m["op"],
            "unit":      m["unit"],
            "threshold": threshold,
            "enabled":   form.get(f"enabled_{f}") == "on",
        })

    row = db.query(SystemSetting).filter(SystemSetting.key == SETTING_KEY).first()
    value = json.dumps(criteria, ensure_ascii=False)
    if row:
        row.value = value
        row.updated_at = datetime.now()
    else:
        db.add(SystemSetting(
            key=SETTING_KEY,
            value=value,
            description="指導書自動判別条件",
            updated_at=datetime.now(),
        ))

    # 軽油単価の保存(v10.7.2で専用カードへ移設。フォームに欄がある場合のみ更新
    # — 欄なしで既定値がリセットされる事故を防ぐ後方互換ガード)
    if "fuel_price" in form:
        raw_price = form.get("fuel_price", "")
        try:
            fuel_price_val = round(float(raw_price), 1)
            if fuel_price_val <= 0:
                raise ValueError
        except (ValueError, TypeError):
            fuel_price_val = float(FUEL_PRICE_DEFAULT)
        fp_row = db.query(SystemSetting).filter(SystemSetting.key == FUEL_PRICE_KEY).first()
        if fp_row:
            fp_row.value = str(fuel_price_val)
            fp_row.updated_at = datetime.now()
        else:
            db.add(SystemSetting(
                key=FUEL_PRICE_KEY,
                value=str(fuel_price_val),
                description="軽油単価（円/L）",
                updated_at=datetime.now(),
            ))

    # 労務上限設定値の保存(N2)。Free Nippo 側と同一値を運用ルールで共有(D-3)
    for m in LABOR_LIMIT_META:
        raw = form.get(m["key"], "")
        try:
            val = int(float(raw))
            if val <= 0:
                raise ValueError
        except (ValueError, TypeError):
            val = m["default"]
        lrow = db.query(SystemSetting).filter(SystemSetting.key == m["key"]).first()
        if lrow:
            lrow.value = str(val)
            lrow.updated_at = datetime.now()
        else:
            db.add(SystemSetting(
                key=m["key"],
                value=str(val),
                description=f"労務: {m['label']}",
                updated_at=datetime.now(),
            ))

    db.commit()
    return RedirectResponse(url="/settings?saved=1", status_code=303)


@router.post("/settings/fuel-price-default")
async def save_default_fuel_price(request: Request, db: Session = Depends(get_db)):
    """既定の軽油単価の保存(専用カードから。v10.7.2 UI整頓)。"""
    form = await request.form()
    try:
        price = round(float(form.get("fuel_price", "")), 1)
        if not (1 <= price <= 9999):
            raise ValueError
    except (ValueError, TypeError):
        return RedirectResponse(url="/settings?fuel_month_error=1", status_code=303)
    row = db.query(SystemSetting).filter(SystemSetting.key == FUEL_PRICE_KEY).first()
    if row:
        row.value = str(price)
        row.updated_at = datetime.now()
    else:
        db.add(SystemSetting(key=FUEL_PRICE_KEY, value=str(price),
                             description="軽油単価（円/L）",
                             updated_at=datetime.now()))
    db.commit()
    return RedirectResponse(url="/settings?fuel_month_saved=1", status_code=303)


@router.post("/settings/fuel-price-month")
async def save_monthly_fuel_price(request: Request, db: Session = Depends(get_db)):
    """月別軽油単価の追加/更新(顧客FB① 2026-07-24)。0.1円刻み。"""
    import re
    form = await request.form()
    month = str(form.get("month", "")).strip()
    if not re.fullmatch(r"\d{4}-\d{2}", month):
        return RedirectResponse(url="/settings?fuel_month_error=1", status_code=303)
    try:
        price = round(float(form.get("price", "")), 1)
        if not (1 <= price <= 9999):
            raise ValueError
    except (ValueError, TypeError):
        return RedirectResponse(url="/settings?fuel_month_error=1", status_code=303)

    key = f"{FUEL_PRICE_KEY}_{month}"
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    if row:
        row.value = str(price)
        row.updated_at = datetime.now()
    else:
        db.add(SystemSetting(key=key, value=str(price),
                             description=f"軽油単価 {month}(円/L)",
                             updated_at=datetime.now()))
    db.commit()
    return RedirectResponse(url="/settings?fuel_month_saved=1", status_code=303)


@router.post("/settings/fuel-price-month/delete")
async def delete_monthly_fuel_price(request: Request, db: Session = Depends(get_db)):
    form = await request.form()
    month = str(form.get("month", "")).strip()
    (db.query(SystemSetting)
     .filter(SystemSetting.key == f"{FUEL_PRICE_KEY}_{month}")
     .delete(synchronize_session=False))
    db.commit()
    return RedirectResponse(url="/settings?fuel_month_saved=1", status_code=303)


@router.post("/settings/vehicle-profile")
async def save_vehicle_profile(request: Request, db: Session = Depends(get_db)):
    """車両別基準燃費を一括保存。"""
    form = await request.form()
    vehicles = db.query(Vehicle).filter(Vehicle.is_active == 1).all()
    updated = 0
    for v in vehicles:
        raw = form.get(f"eff_{v.code}", "")
        if raw.strip():
            try:
                val = float(raw)
                if 0 < val < 100:
                    v.baseline_efficiency_kml = val
                    updated += 1
            except (ValueError, TypeError):
                pass
        else:
            # 空欄 → Noneに戻す（デフォルト値を使用）
            v.baseline_efficiency_kml = None
    db.commit()
    return RedirectResponse(url=f"/settings?profile_saved={updated}", status_code=303)
