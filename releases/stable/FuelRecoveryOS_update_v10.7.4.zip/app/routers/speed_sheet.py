"""スピード管理表（乗務員×日付マトリクス）— 第2波 G1（表示・色分け・A4横印刷）。

TripReport を (driver_code, operation_date) で都度集計し、速度超過の回数・秒で
セルを 青/黄/赤/灰 に塗り分ける。実体化はしない（区分最小・スキーマ変更なし）。
セル補正（judgment_overrides）は Phase 3 で別途。閾値は SystemSetting で可変。
"""
import calendar
from datetime import date

from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.system import SystemSetting
from app.routers.month_utils import resolve_base_month, month_context
from app.routers.overrides import apply_speed_overrides, speed_override_records, SPEED_CELL_LABELS
from app.services import rollup

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# 閾値（SystemSetting キー / 既定値）。speed_over の既存 criteria(=5) と整合。
RED_COUNT_KEY = "speed_sheet_red_count"
RED_SEC_KEY = "speed_sheet_red_sec"
DEFAULT_RED_COUNT = 5
DEFAULT_RED_SEC = 300


def _si(v) -> int:
    return int(v) if v else 0


def _thresholds(db: Session) -> tuple[int, int]:
    def geti(key: str, default: int) -> int:
        row = db.query(SystemSetting).filter_by(key=key).first()
        try:
            return int(row.value) if row and row.value else default
        except (TypeError, ValueError):
            return default
    return geti(RED_COUNT_KEY, DEFAULT_RED_COUNT), geti(RED_SEC_KEY, DEFAULT_RED_SEC)


def _office_name(db: Session, office: str) -> str:
    if not office or office in ("all", "ALL"):
        return "全営業所"
    for o in rollup.list_offices(db):
        if o["code"] == office:
            return o["name"]
    return office


def _cell_status(count: int, sec: int, red_count: int, red_sec: int) -> str:
    """灰=データ無は呼出側で判定。ここは運行のあった日のみ。"""
    if count >= red_count or sec >= red_sec:
        return "red"
    if count >= 1:
        return "yellow"
    return "blue"


def _build_matrix(db: Session, base: date, office: str, red_count: int, red_sec: int):
    last = calendar.monthrange(base.year, base.month)[1]
    days = list(range(1, last + 1))
    trips = rollup.month_trips(db, base, office)

    cells: dict[tuple[str, int], dict] = {}
    names: dict[str, str] = {}
    for t in trips:
        dc = t.driver_code or "—"
        if t.driver_name:
            names[dc] = t.driver_name
        names.setdefault(dc, dc)
        day = t.operation_date.day
        c = cells.setdefault((dc, day), {"count": 0, "sec": 0})
        c["count"] += (_si(t.speed_over_general_count) + _si(t.speed_over_highway_count)
                       + _si(t.speed_over_dedicated_count))
        c["sec"] += _si(t.speed_over_general_sec) + _si(t.speed_over_highway_sec)

    rows = []
    for dc in sorted(names, key=lambda k: (names[k] or "", k)):
        cell_list = []
        month_count = red_days = active_days = 0
        for day in days:
            c = cells.get((dc, day))
            if c is None:
                cell_list.append({"day": day, "status": "none", "count": 0, "sec": 0})
                continue
            st = _cell_status(c["count"], c["sec"], red_count, red_sec)
            if st == "red":
                red_days += 1
            active_days += 1
            month_count += c["count"]
            cell_list.append({"day": day, "status": st, "count": c["count"], "sec": c["sec"]})
        rows.append({
            "driver_code": dc,
            "driver_name": names[dc],
            "cells": cell_list,
            "month_count": month_count,
            "red_days": red_days,
            "active_days": active_days,
        })
    return days, rows


@router.get("/speed-sheet")
async def speed_sheet(request: Request, office: str = "all", db: Session = Depends(get_db)):
    base = resolve_base_month(db, request.cookies.get("base_month"))
    red_count, red_sec = _thresholds(db)
    days, rows = _build_matrix(db, base, office, red_count, red_sec)
    rows = apply_speed_overrides(db, base, rows)
    return templates.TemplateResponse("speed_sheet.html", {
        "request": request,
        "current_page": "speed_sheet",
        "days": days,
        "rows": rows,
        "offices": rollup.list_offices(db),
        "selected_office": office,
        "office_name": _office_name(db, office),
        "red_count": red_count,
        "red_sec": red_sec,
        "base": base,
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("/speed-sheet/print")
async def speed_sheet_print(request: Request, office: str = "all", db: Session = Depends(get_db)):
    base = resolve_base_month(db, request.cookies.get("base_month"))
    red_count, red_sec = _thresholds(db)
    days, rows = _build_matrix(db, base, office, red_count, red_sec)
    rows = apply_speed_overrides(db, base, rows)
    name_map = {r["driver_code"]: r["driver_name"] for r in rows}
    records = speed_override_records(db, base, set(name_map.keys()))
    for rec in records:
        rec["driver_name"] = name_map.get(rec["driver_code"], rec["driver_code"])
    return templates.TemplateResponse("speed_sheet_print.html", {
        "request": request,
        "days": days,
        "rows": rows,
        "office_name": _office_name(db, office),
        "red_count": red_count,
        "red_sec": red_sec,
        "records": records,
        "cell_labels": SPEED_CELL_LABELS,
        "base": base,
    })
