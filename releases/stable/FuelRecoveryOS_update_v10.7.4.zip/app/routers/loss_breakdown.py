"""燃費金額の内訳表示 — 第1波 ①（詳細画面）。

ダッシュボードの損失回収ファネル下「損失内訳」からクリックで到達する詳細画面。
既存の損失集計（rollup.loss_breakdown ＝ dashboard と総額一致）を指導項目別に
按分し、金額・割合・**推奨アクション（何をすべきか）・上位対象者**を表示する。
総額は不変（回帰ゼロ）。読み取りのみ・スキーマ変更なし（区分A）。
"""
from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.csv_import import TripReport
from app.routers.month_utils import resolve_base_month, month_context
from app.routers.settings_router import get_fuel_price
from app.services import rollup

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


def _office_name(db: Session, office: str) -> str:
    if not office or office in ("all", "ALL"):
        return "全営業所"
    for o in rollup.list_offices(db):
        if o["code"] == office:
            return o["name"]
    return office


@router.get("/loss/breakdown")
async def loss_breakdown_view(request: Request, office: str = "all",
                              db: Session = Depends(get_db)):
    base = resolve_base_month(db, request.cookies.get("base_month"))
    fuel_price = get_fuel_price(db, base.strftime("%Y-%m"))
    trips = rollup.month_trips(db, base, office)
    agg = rollup.aggregate_by_driver(trips)
    # 車両層は dashboard と同じく全期間の運行から算出（office 指定時は当該営業所に限定）。
    # office=all では dashboard の損失総額と完全一致（車両層込み・総額不変）。
    vehicle_trips = db.query(TripReport)
    if office and office not in ("all", "ALL"):
        vehicle_trips = vehicle_trips.filter(TripReport.driver_office_code == office)
    vehicle_trips = vehicle_trips.all()
    items, total_l = rollup.build_full_loss_items(trips, vehicle_trips, agg, fuel_price)

    return templates.TemplateResponse("loss_breakdown.html", {
        "request": request,
        "current_page": "loss_breakdown",
        "items": items,
        "total_l": round(total_l, 1),
        "total_yen": int(total_l * fuel_price),
        "fuel_price": fuel_price,
        "offices": rollup.list_offices(db),
        "selected_office": office,
        "office_name": _office_name(db, office),
        "base": base,
        **month_context(db, request.cookies.get("base_month")),
    })
