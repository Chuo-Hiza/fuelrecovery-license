"""Shipper evidence router — 荷主交渉エビデンス。"""
from datetime import date

from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.operations import ShipperWaitSummary
from app.routers.month_utils import month_context, resolve_base_month

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@router.get("/shipper")
async def shipper_list(request: Request, db: Session = Depends(get_db)):
    # 基軸月に連動(従来は 2026-03 固定のままだった=全体整理 2026-07-21 で是正)
    base = resolve_base_month(db, request.cookies.get("base_month"))
    month_str = f"{base.year:04d}-{base.month:02d}"
    shippers = db.query(ShipperWaitSummary).filter(
        ShipperWaitSummary.month == month_str,
    ).order_by(ShipperWaitSummary.total_impact_yen.desc()).all()

    return templates.TemplateResponse("shipper.html", {
        "request": request,
        "current_page": "shipper",
        "month_str": f"{base.year}年{base.month}月",
        "shippers": shippers,
        **month_context(db, request.cookies.get("base_month")),
    })
