"""判定補正（管理者オーバーレイ）— 第2波 G1。

生データ（TripReport 等）は改変せず、判定キー単位の補正を judgment_overrides に
永続化し、表示時に overlay 適用する。全変更は judgment_override_logs に追記（誰/いつ/なぜ）。
現状の利用: speed_cell（スピード管理表のセル補正）。cases 補正は将来同テーブルで共用。
"""
from datetime import date

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.operations import JudgmentOverride, JudgmentOverrideLog

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# speed_cell の区分（override_value）。dismiss は is_dismissed=True（対象外）。
SPEED_CELL_VALUES = {"blue", "yellow", "red", "dismiss"}
SPEED_CELL_LABELS = {"blue": "青(超過なし)", "yellow": "黄", "red": "赤", "dismiss": "対象外(除外)"}

# case の補正（override_value=優先度）。dismiss は対象外（ボード/バッジから除外）。
# done は「対応済み」= 見直し・面談等の対応を完了した記録（バッジから除外・✓表示）。
CASE_VALUES = {"high", "mid", "low", "done", "dismiss"}
CASE_LABELS = {"high": "HIGH", "mid": "MID", "low": "LOW",
               "done": "対応済み", "dismiss": "対象外(除外)"}
# 履歴表示用の共通ラベル（speed_cell と case の値を両方カバー）。
ALL_LABELS = {**SPEED_CELL_LABELS, **CASE_LABELS}


def _safe_back(back: str) -> str:
    if back and back.startswith("/") and not back.startswith("//"):
        return back
    return "/speed-sheet"


def upsert_override(db: Session, judgment_type: str, target_key: str,
                    override_value: str | None, is_dismissed: bool,
                    note: str, actor: str) -> JudgmentOverride:
    """補正を upsert し、変更を履歴に追記する。"""
    row = (db.query(JudgmentOverride)
           .filter_by(judgment_type=judgment_type, target_key=target_key)
           .first())
    old = None if row is None else (("dismiss" if row.is_dismissed else row.override_value) or "")
    new = "dismiss" if is_dismissed else (override_value or "")
    if row is None:
        row = JudgmentOverride(judgment_type=judgment_type, target_key=target_key)
        db.add(row)
    row.override_value = None if is_dismissed else override_value
    row.is_dismissed = is_dismissed
    row.note = note
    row.actor = actor
    db.add(JudgmentOverrideLog(
        judgment_type=judgment_type, target_key=target_key,
        field_name="status", old_value=old, new_value=new,
        reason=note, actor=actor,
    ))
    db.commit()
    return row


def speed_override_map(db: Session) -> dict[str, JudgmentOverride]:
    """speed_cell の補正を target_key -> override で返す。"""
    return {o.target_key: o for o in
            db.query(JudgmentOverride).filter_by(judgment_type="speed_cell").all()}


def speed_override_records(db: Session, base: date,
                           driver_codes: set[str] | None = None) -> list[dict]:
    """当月のスピード管理表セル補正の記録（印刷の管理表下に載せる用）。

    1補正セルにつき1行: {date, driver_code, old, new, reason, actor, changed_at}。
    old/new は 'blue'/'yellow'/'red'/'dismiss'（表示側で日本語化）。
    """
    ym = f"{base.year:04d}-{base.month:02d}"
    overrides = (db.query(JudgmentOverride)
                 .filter(JudgmentOverride.judgment_type == "speed_cell",
                         JudgmentOverride.target_key.like(f"%:{ym}-%"))
                 .all())
    records = []
    for o in overrides:
        parts = o.target_key.split(":")
        if len(parts) != 2:
            continue
        dc, dstr = parts
        if driver_codes is not None and dc not in driver_codes:
            continue
        log = (db.query(JudgmentOverrideLog)
               .filter_by(judgment_type="speed_cell", target_key=o.target_key)
               .order_by(JudgmentOverrideLog.changed_at.desc()).first())
        records.append({
            "date": dstr,
            "driver_code": dc,
            "old": (log.old_value if log else None),
            "new": (log.new_value if log else ("dismiss" if o.is_dismissed else o.override_value)),
            "reason": o.note or (log.reason if log else ""),
            "actor": o.actor or (log.actor if log else ""),
            "changed_at": (log.changed_at if log else o.updated_at),
        })
    records.sort(key=lambda r: (r["date"], r["driver_code"]))
    return records


def apply_speed_overrides(db: Session, base: date, rows: list[dict]) -> list[dict]:
    """スピード管理表の行配列に補正を overlay 適用（色上書き＋赤日再計算）。"""
    omap = speed_override_map(db)
    ym = f"{base.year:04d}-{base.month:02d}"
    for r in rows:
        red_days = 0
        for c in r["cells"]:
            tk = f"{r['driver_code']}:{ym}-{c['day']:02d}"
            o = omap.get(tk)
            if o is not None:
                c["overridden"] = True
                c["override_note"] = o.note or ""
                if o.is_dismissed:
                    c["status"] = "dismiss"
                elif o.override_value in ("blue", "yellow", "red"):
                    c["status"] = o.override_value
            if c["status"] == "red":
                red_days += 1
        r["red_days"] = red_days
    return rows


def case_override_map(db: Session) -> dict[str, JudgmentOverride]:
    return {o.target_key: o for o in
            db.query(JudgmentOverride).filter_by(judgment_type="case").all()}


def apply_case_overrides(db: Session, cases: list[dict]) -> list[dict]:
    """案件リストに補正を overlay（priority上書き・dismissedフラグ付与）。ドロップはしない。

    各 case に target_key/overridden/dismissed/override_note を付与して返す。
    件数集計・表示側で dismissed を扱う（バッジ・合計は除外、ボードは灰表示）。
    """
    omap = case_override_map(db)
    for c in cases:
        tk = f"{c.get('report_number')}:{c.get('layer')}"
        c["target_key"] = tk
        o = omap.get(tk)
        c["overridden"] = o is not None
        c["dismissed"] = bool(o and o.is_dismissed)
        c["done"] = bool(o and not o.is_dismissed and o.override_value == "done")
        c["override_note"] = (o.note if o else "") or ""
        if o is not None and not o.is_dismissed and o.override_value in ("high", "mid", "low"):
            c["priority"] = o.override_value
    return cases


@router.post("/overrides/case")
async def post_case(request: Request,
                    report_number: str = Form(...),
                    layer: str = Form(...),
                    override_value: str = Form(...),
                    reason: str = Form(""),
                    actor: str = Form(""),
                    back: str = Form("/cases"),
                    db: Session = Depends(get_db)):
    dest = back if (back and back.startswith("/") and not back.startswith("//")) else "/cases"
    if override_value not in CASE_VALUES or not actor.strip():
        return RedirectResponse(url=dest, status_code=303)
    target_key = f"{report_number}:{layer}"
    upsert_override(
        db, "case", target_key,
        override_value=None if override_value == "dismiss" else override_value,
        is_dismissed=(override_value == "dismiss"),
        note=reason.strip(), actor=actor.strip(),
    )
    return RedirectResponse(url=dest, status_code=303)


@router.post("/overrides/speed_cell")
async def post_speed_cell(request: Request,
                          driver_code: str = Form(...),
                          cell_date: str = Form(...),
                          override_value: str = Form(...),
                          reason: str = Form(""),
                          actor: str = Form(""),
                          back: str = Form("/speed-sheet"),
                          db: Session = Depends(get_db)):
    dest = _safe_back(back)
    if override_value not in SPEED_CELL_VALUES or not actor.strip():
        # actor 必須・不正値は保存せず戻す
        return RedirectResponse(url=dest, status_code=303)
    target_key = f"{driver_code}:{cell_date}"
    upsert_override(
        db, "speed_cell", target_key,
        override_value=None if override_value == "dismiss" else override_value,
        is_dismissed=(override_value == "dismiss"),
        note=reason.strip(), actor=actor.strip(),
    )
    return RedirectResponse(url=dest, status_code=303)


@router.get("/overrides/history")
async def override_history(request: Request, judgment_type: str, target_key: str,
                           db: Session = Depends(get_db)):
    logs = (db.query(JudgmentOverrideLog)
            .filter_by(judgment_type=judgment_type, target_key=target_key)
            .order_by(JudgmentOverrideLog.changed_at.desc())
            .all())
    return templates.TemplateResponse("partials/_override_history.html", {
        "request": request, "logs": logs, "labels": ALL_LABELS,
    })
