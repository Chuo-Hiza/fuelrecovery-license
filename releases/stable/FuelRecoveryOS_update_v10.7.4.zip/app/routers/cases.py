"""Intervention cases router — 今日の介入案件。
Generates cases directly from trip_reports data.
"""
from datetime import date, timedelta

from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.csv_import import TripReport
from app.routers.settings_router import get_fuel_price
from app.routers.month_utils import resolve_base_month, month_last_day, month_context
from app.routers.overrides import apply_case_overrides

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

IDLE_CONSUMPTION_LH = 1.5  # L/h

LAYER_LABELS = {
    "driving": "運転",
    "dispatch": "配車",
    "shipper": "荷主",
    "vehicle": "車両",
}

ACTION_TEMPLATES = {
    "driving_accel": "急加速/急減速が多い → 個別面談で改善指導",
    "driving_speed": "速度超過 → 巡航速度の意識改善指導",
    "driving_rpm": "高回転維持 → シフトアップ指導",
    "dispatch_idle": "長時間アイドリング → 出庫時間/ルート見直し",
    "shipper_wait": "待機時間が長い → 荷主へ受付時刻調整を交渉",
    "vehicle_anomaly": "同型車比較で悪化 → タイヤ/DPF/アライメント点検",
}


def generate_cases_from_trips(trips, all_trips_for_baseline, fuel_price):
    """Analyze trips and generate intervention cases."""
    cases = []

    # Build per-vehicle baseline
    vehicle_avg_score = {}
    for t in all_trips_for_baseline:
        vc = t.vehicle_code
        if vc not in vehicle_avg_score:
            vehicle_avg_score[vc] = {"scores": [], "dist": []}
        if t.overall_score:
            vehicle_avg_score[vc]["scores"].append(t.overall_score)

    global_avg_score = 0
    all_scores = [s for v in vehicle_avg_score.values() for s in v["scores"]]
    if all_scores:
        global_avg_score = sum(all_scores) / len(all_scores)

    for t in trips:
        dist_km = (t.distance_m or 0) / 1000
        if dist_km < 1:
            continue

        # Layer 1: Driving events
        accel_events = (t.sudden_accel_count or 0) + (t.sudden_decel_count or 0) + (t.sudden_start_count or 0)
        speed_events = (t.speed_over_general_count or 0) + (t.speed_over_highway_count or 0)
        rpm_events = (t.rpm_over_general_count or 0) + (t.rpm_over_highway_count or 0)

        if accel_events >= 3 or speed_events >= 5:
            loss_l = accel_events * 0.15 + speed_events * 0.2
            priority = "high" if accel_events >= 5 or speed_events >= 10 else "mid"
            action = ACTION_TEMPLATES["driving_accel"] if accel_events > speed_events else ACTION_TEMPLATES["driving_speed"]
            cases.append({
                "date": t.operation_date,
                "report_number": t.report_number,
                "priority": priority,
                "vehicle_name": t.vehicle_name,
                "driver_name": t.driver_name,
                "route": t.course_name or f"{dist_km:.0f}km運行",
                "loss_l": round(loss_l, 1),
                "loss_yen": int(loss_l * fuel_price),
                "layer": "driving",
                "layer_label": "運転",
                "action": action,
                "status": "未対応",
                "score": t.overall_score,
            })

        # Layer 2: Dispatch — excessive idle
        idle_sec = t.idle_time_sec or 0
        if idle_sec > 1800:  # >30min idle
            loss_l = (idle_sec / 3600) * IDLE_CONSUMPTION_LH
            cases.append({
                "date": t.operation_date,
                "report_number": t.report_number,
                "priority": "high" if idle_sec > 3600 else "mid",
                "vehicle_name": t.vehicle_name,
                "driver_name": t.driver_name,
                "route": t.course_name or f"{dist_km:.0f}km運行",
                "loss_l": round(loss_l, 1),
                "loss_yen": int(loss_l * fuel_price),
                "layer": "dispatch",
                "layer_label": "配車",
                "action": ACTION_TEMPLATES["dispatch_idle"],
                "status": "未対応",
                "score": t.overall_score,
            })

        # Layer 3: Shipper — waiting time
        wait_sec = t.waiting_time_sec or 0
        if wait_sec > 1800:  # >30min wait
            loss_l = (wait_sec / 3600) * IDLE_CONSUMPTION_LH
            cases.append({
                "date": t.operation_date,
                "report_number": t.report_number,
                "priority": "high" if wait_sec > 3600 else "mid",
                "vehicle_name": t.vehicle_name,
                "driver_name": t.driver_name,
                "route": t.course_name or f"{dist_km:.0f}km運行",
                "loss_l": round(loss_l, 1),
                "loss_yen": int(loss_l * fuel_price),
                "layer": "shipper",
                "layer_label": "荷主",
                "action": ACTION_TEMPLATES["shipper_wait"],
                "status": "未対応",
                "score": t.overall_score,
            })

        # Layer 4: Vehicle — low score compared to average
        if t.overall_score and t.overall_score < global_avg_score * 0.85 and dist_km > 10:
            loss_l = (global_avg_score - t.overall_score) / 100 * dist_km * 0.02
            cases.append({
                "date": t.operation_date,
                "report_number": t.report_number,
                "priority": "mid" if t.overall_score >= 60 else "high",
                "vehicle_name": t.vehicle_name,
                "driver_name": t.driver_name,
                "route": t.course_name or f"{dist_km:.0f}km運行",
                "loss_l": round(loss_l, 1),
                "loss_yen": int(loss_l * fuel_price),
                "layer": "vehicle",
                "layer_label": "車両",
                "action": ACTION_TEMPLATES["vehicle_anomaly"],
                "status": "未対応",
                "score": t.overall_score,
            })

    # Sort by loss descending
    cases.sort(key=lambda c: c["loss_yen"], reverse=True)
    return cases


def count_pending_cases(db: Session, base_month: date) -> dict:
    """ナビバッジ用の未対応案件件数を返す。基軸月の直近7日を対象とする。"""
    today = month_last_day(base_month)
    start = today - timedelta(days=7)
    fuel_price = get_fuel_price(db, base_month.strftime("%Y-%m"))
    trips = db.query(TripReport).filter(
        TripReport.operation_date >= start,
        TripReport.operation_date <= today,
    ).all()
    all_trips = db.query(TripReport).all()
    cases = generate_cases_from_trips(trips, all_trips, fuel_price)
    apply_case_overrides(db, cases)
    # 対象外・対応済みはバッジから除外(=残っている数字は「未対応」の実数)
    cases = [c for c in cases if not c["dismissed"] and not c.get("done")]
    return {
        "total": len(cases),
        "high": sum(1 for c in cases if c.get("priority") == "high"),
    }


@router.get("/cases")
async def cases_list(request: Request, db: Session = Depends(get_db),
                     layer_filter: str = "all", period: str = "week"):
    base = resolve_base_month(db, request.cookies.get("base_month"))
    FUEL_PRICE = get_fuel_price(db, base.strftime("%Y-%m"))
    today = month_last_day(base)

    if period == "today":
        start = today
    elif period == "week":
        start = today - timedelta(days=7)
    else:
        start = base

    trips = db.query(TripReport).filter(
        TripReport.operation_date >= start,
        TripReport.operation_date <= today,
    ).all()

    all_trips = db.query(TripReport).all()

    all_cases = generate_cases_from_trips(trips, all_trips, FUEL_PRICE)
    apply_case_overrides(db, all_cases)  # target_key/priority/dismissed を付与

    if layer_filter != "all":
        all_cases = [c for c in all_cases if c["layer"] == layer_filter]

    active = [c for c in all_cases if not c["dismissed"] and not c.get("done")]
    done = [c for c in all_cases if c.get("done") and not c["dismissed"]]
    dismissed = [c for c in all_cases if c["dismissed"]]

    # Counts by layer（対象外・対応済みは除外＝実作業量）
    layer_counts = {}
    for c in active:
        layer_counts[c["layer"]] = layer_counts.get(c["layer"], 0) + 1

    # 表示: 未対応(損失降順)を上位、対応済み(✓)→対象外(灰)を末尾に
    display_cases = active[:50] + done + dismissed

    return templates.TemplateResponse("cases.html", {
        "request": request,
        "current_page": "cases",
        "today": today,
        "cases": display_cases,
        "total_count": len(active),
        "done_count": len(done),
        "dismissed_count": len(dismissed),
        "layer_counts": layer_counts,
        "layer_filter": layer_filter,
        "period": period,
        "layer_labels": LAYER_LABELS,
        **month_context(db, request.cookies.get("base_month")),
    })
