"""キーワード検索 — ヒアリング §4.12（目的別入口の相方）。

ドライバー名・車両番号・項目キーワードを入力すると、関連画面への候補リンクを表示する
“候補ジャンプ”検索。読み取りのみ・スキーマ変更なし（区分A）。
"""
from urllib.parse import quote

from fastapi import APIRouter, Depends, Query, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.csv_import import TripReport
from app.routers.month_utils import month_context

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# 項目キーワード → 候補（ラベル, リンク）。キー or 入力語が相互に部分一致で採用。
ITEM_MAP: dict[str, list[tuple[str, str]]] = {
    "急加速": [("急加速ランキング", "/ranking/safety?item=accel")],
    "急減速": [("急減速ランキング", "/ranking/safety?item=decel")],
    "急発進": [("急発進ランキング", "/ranking/safety?item=start")],
    "速度超過": [("速度超過ランキング", "/ranking/safety?item=speed_over"),
                 ("スピード管理表", "/speed-sheet")],
    "スピード": [("スピード管理表", "/speed-sheet"),
                 ("速度超過ランキング", "/ranking/safety?item=speed_over")],
    "回転数": [("回転数オーバーランキング", "/ranking/safety?item=rpm_over")],
    "連続走行": [("連続走行ランキング", "/ranking/safety?item=continuous")],
    "430": [("430注意（連続走行）", "/ranking/safety?item=continuous&filter=430")],
    "指導対象": [("指導対象の抽出", "/ranking/safety?filter=target"),
                 ("面談カード一覧", "/coaching")],
    "アイドリング": [("燃料・損失内訳", "/loss/breakdown")],
    "待機": [("燃料・損失内訳", "/loss/breakdown")],
    "燃料": [("燃料・損失内訳", "/loss/breakdown")],
    "損失": [("燃料・損失内訳", "/loss/breakdown")],
    "推定": [("推定残 車両一覧", "/fuel/estimated")],
    "給油": [("給油入力", "/fuel")],
    "安全": [("安全運転ランキング", "/ranking/safety")],
    "ランキング": [("安全運転ランキング", "/ranking/safety")],
    "案件": [("要確認案件", "/cases")],
    "面談": [("面談カード一覧", "/coaching")],
    "指導": [("面談カード一覧", "/coaching")],
    "高速": [("高速モード低速の確認", "/analysis/mode-review")],
}


def _match_items(q: str) -> list[dict]:
    seen: set[str] = set()
    out: list[dict] = []
    for key, links in ITEM_MAP.items():
        if q in key or key in q:
            for label, href in links:
                if href in seen:
                    continue
                seen.add(href)
                out.append({"label": label, "href": href})
    return out


@router.get("/search")
async def search(request: Request, q: str = Query(""), db: Session = Depends(get_db)):
    q = (q or "").strip()
    drivers: list[dict] = []
    vehicles: list[dict] = []
    items: list[dict] = []

    if q:
        like = f"%{q}%"
        # 乗務員（重複排除・上位20）
        drv = (db.query(TripReport.driver_code, func.max(TripReport.driver_name))
               .filter(TripReport.driver_code.isnot(None),
                       or_(TripReport.driver_name.like(like), TripReport.driver_code.like(like)))
               .group_by(TripReport.driver_code).limit(20).all())
        for code, name in drv:
            label = f"{name or code}（{code}）"
            back = quote("/search?q=" + q)
            drivers.append({
                "label": label,
                "href": f"/coaching/{code}?back={back}&back_label={quote('検索に戻る')}",
            })
        # 車両（重複排除・上位20）
        veh = (db.query(TripReport.vehicle_code, func.max(TripReport.vehicle_name))
               .filter(TripReport.vehicle_code.isnot(None),
                       or_(TripReport.vehicle_name.like(like), TripReport.vehicle_code.like(like)))
               .group_by(TripReport.vehicle_code).limit(20).all())
        for code, name in veh:
            vehicles.append({
                "label": f"{name or code}（{code}）",
                "href": f"/fuel?tab=manual&filter_vehicle={quote(code)}",
            })
        items = _match_items(q)

    return templates.TemplateResponse("search.html", {
        "request": request,
        "current_page": "search",
        "q": q,
        "drivers": drivers,
        "vehicles": vehicles,
        "items": items,
        "total": len(drivers) + len(vehicles) + len(items),
        **month_context(db, request.cookies.get("base_month")),
    })
