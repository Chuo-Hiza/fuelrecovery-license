"""Free Nippo trips エクスポートCSVの取込。

契約(04_FuelRecoveryOS連携境界.md §3)の14列を取り込む。
- report_date 月単位の全置換(出庫日時訂正で trip_id が変わっても二重計上しない)
- 特殊乗務員コード(全桁同一文字 & f/a/n 始まり & 長さ>=6、空/"0")は除外
- 労務値は本CSVのみを正とし、生ESTRA CSVから再計算しない(ADR-002)
"""
import csv
import io
import logging
import re

from sqlalchemy.orm import Session

from app.models.master import Driver
from app.models.nippo import NippoImportLog, NippoTrip

logger = logging.getLogger(__name__)

REQUIRED_COLUMNS = ["trip_id", "driver_code", "report_date", "restrict_sec"]
OPTIONAL_COLUMNS = [
    "start_dt", "end_dt", "restrict_approx", "drive_sec", "rest_sec",
    "sleep_sec", "total_km", "toll_total", "fuel_l", "fuel_efficiency",
]
# 労務上限設定値の同梱列(D-3。仕様: Free_nippo/context/portable/05_trips_export仕様.md
# — 全行同値。本システム設定と突合し、不一致は警告のみで取込は拒否しない)
LIMIT_COLUMNS = {"limit_month_h": "labor_restrict_month_limit_h",
                 "limit_day_h": "labor_restrict_day_limit_h"}
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _limit_mismatch_warnings(header: list[str], first_row: dict, db: Session) -> list[str]:
    """CSV 同梱の上限設定値と本システム設定の突合(不一致=両システムの設定更新漏れ)。"""
    if not any(c in header for c in LIMIT_COLUMNS):
        return []  # 旧仕様ファイル(列なし)は突合スキップ
    from app.services.labor_check import get_labor_limits  # 循環import回避の遅延import
    limits = get_labor_limits(db)
    label = {"limit_month_h": "1か月拘束上限", "limit_day_h": "1日拘束上限"}
    out = []
    for col, key in LIMIT_COLUMNS.items():
        their = _parse_int(first_row.get(col))
        if their is not None and their != limits[key]:
            out.append(
                f"労務上限設定の不一致({label[col]}): 日報システム側 {their}h / "
                f"本システム設定 {limits[key]}h — 両システムの設定を同じ値に揃えてください")
    return out


def decode_csv_bytes(raw: bytes) -> str:
    """Free Nippo エクスポートは UTF-8(BOM付き)を仮定。旧環境向けに cp932 フォールバック。"""
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp932", errors="replace")


def normalize_driver_code(code: str) -> str:
    """契約 §3: 照会は正規化キー(先頭ゼロ除去等)で行う。"""
    code = (code or "").strip()
    stripped = code.lstrip("0")
    return stripped if stripped else code


def is_special_driver_code(code: str) -> bool:
    """実在乗務でないコード(Free Nippo core/codes.py と同一仕様)+ 空/"0"。"""
    if not code or code == "0":
        return True
    return len(code) >= 6 and len(set(code.lower())) == 1 and code[0].lower() in "fan"


def _parse_int(v) -> int | None:
    try:
        s = str(v).strip()
        return int(float(s)) if s else None
    except (ValueError, TypeError):
        return None


def _parse_float(v) -> float | None:
    try:
        s = str(v).strip()
        return float(s) if s else None
    except (ValueError, TypeError):
        return None


def import_nippo_trips_csv(filename: str, raw: bytes, db: Session) -> dict:
    """CSVバイト列を取り込み、結果を NippoImportLog に記録して返す。

    ファイルに含まれる report_date 月ごとに「既存行削除→全挿入」を1トランザクションで行う。
    """
    warnings: list[str] = []
    skipped = 0

    try:
        reader = csv.DictReader(io.StringIO(decode_csv_bytes(raw)))
        header = [h.strip() for h in (reader.fieldnames or [])]
        missing = [c for c in REQUIRED_COLUMNS if c not in header]
        if missing:
            detail = f"必須列がありません: {', '.join(missing)}(ヘッダ: {', '.join(header) or 'なし'})"
            db.add(NippoImportLog(filename=filename, status="error", error_detail=detail))
            db.commit()
            return {"status": "error", "error": detail}

        rows: dict[str, NippoTrip] = {}
        first_raw: dict | None = None
        for i, r in enumerate(reader, start=2):
            if first_raw is None:
                first_raw = r
            trip_id = (r.get("trip_id") or "").strip()
            report_date = (r.get("report_date") or "").strip()
            code = normalize_driver_code(r.get("driver_code") or "")

            if not trip_id or not _DATE_RE.match(report_date):
                skipped += 1
                warnings.append(f"{i}行目: trip_id または report_date が不正のため除外")
                continue
            if is_special_driver_code(code):
                skipped += 1
                continue
            if trip_id in rows:
                warnings.append(f"{i}行目: trip_id 重複({trip_id})— 後の行を採用")

            rows[trip_id] = NippoTrip(
                trip_id=trip_id,
                driver_code=code,
                report_date=report_date,
                start_dt=(r.get("start_dt") or "").strip() or None,
                end_dt=(r.get("end_dt") or "").strip() or None,
                restrict_sec=_parse_int(r.get("restrict_sec")),
                restrict_approx=_parse_int(r.get("restrict_approx")),
                drive_sec=_parse_int(r.get("drive_sec")),
                rest_sec=_parse_int(r.get("rest_sec")),
                sleep_sec=_parse_int(r.get("sleep_sec")),
                total_km=_parse_float(r.get("total_km")),
                toll_total=_parse_int(r.get("toll_total")),
                fuel_l=_parse_float(r.get("fuel_l")),
                fuel_efficiency=_parse_float(r.get("fuel_efficiency")),
                source_file=filename,
            )

        if not rows:
            detail = "取込対象の運行行がありません"
            db.add(NippoImportLog(
                filename=filename, status="error", records_skipped=skipped,
                error_detail=detail, warning_detail="\n".join(warnings) or None,
            ))
            db.commit()
            return {"status": "error", "error": detail}

        months = sorted({t.report_date[:7] for t in rows.values()})

        # D-3: 上限設定値の突合(全行同値のため先頭行で判定)
        warnings.extend(_limit_mismatch_warnings(header, first_raw or {}, db))

        # drivers マスタとの突合(正規化キー同士)。未知コードは警告のみで取込は拒否しない
        master_codes = {normalize_driver_code(c) for (c,) in db.query(Driver.code).all()}
        unknown = sorted({t.driver_code for t in rows.values()} - master_codes)
        if unknown:
            warnings.append(f"マスタ未登録の乗務員コード: {', '.join(unknown[:10])}"
                            + (f" 他{len(unknown) - 10}件" if len(unknown) > 10 else ""))

        replaced = 0
        for m in months:
            replaced += (
                db.query(NippoTrip)
                .filter(NippoTrip.report_date.like(f"{m}-%"))
                .delete(synchronize_session=False)
            )
        for t in rows.values():
            db.add(t)

        status = "warning" if warnings else "success"
        db.add(NippoImportLog(
            filename=filename, status=status, months=",".join(months),
            records_imported=len(rows), records_replaced=replaced,
            records_skipped=skipped, warning_detail="\n".join(warnings) or None,
        ))
        db.commit()
        return {
            "status": status, "imported": len(rows), "replaced": replaced,
            "skipped": skipped, "months": months, "warnings": warnings,
        }

    except Exception as e:
        db.rollback()
        logger.exception(f"nippo_trips import failed: {filename}")
        db.add(NippoImportLog(filename=filename, status="error", error_detail=str(e)))
        db.commit()
        return {"status": "error", "error": str(e)}
