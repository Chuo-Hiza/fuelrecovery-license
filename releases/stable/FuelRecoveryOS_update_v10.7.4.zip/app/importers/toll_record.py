"""通行料明細 CSV インポーター (_etc ファイル)。"""
import logging
from pathlib import Path

from sqlalchemy.orm import Session

from app.importers.base import (
    parse_datetime,
    parse_int,
    read_csv_shift_jis,
    resolve_report_number,
)
from app.models.csv_import import TollRecord

logger = logging.getLogger(__name__)


def import_toll_record(filepath: Path, db: Session) -> dict:
    """_etc.csv を読み込み TollRecord テーブルに投入する。

    Returns:
        dict with keys: status, imported, updated, errors
    """
    rows = read_csv_shift_jis(filepath)
    if not rows:
        return {"status": "success", "imported": 0, "updated": 0, "errors": []}

    first_rn = (rows[0].get("日報番号") or "").strip()
    if not first_rn:
        return {"status": "error", "imported": 0, "updated": 0,
                "errors": ["Missing 日報番号 in first row"]}

    # 日報番号の full/short 形式混在を実キーへ解決(v10.7.2 — _tc と同じ規約。
    # 解決しないと日報とJOINできず ETC明細から消える)
    resolved_rn, note = resolve_report_number(db, first_rn, filepath.name)
    if note:
        logger.info(f"toll: {note} ({filepath.name})")

    # 洗い替え(解決済みキーで)
    existing = db.query(TollRecord).filter_by(report_number=resolved_rn).count()
    if existing > 0:
        db.query(TollRecord).filter_by(report_number=resolved_rn).delete()
        db.flush()

    imported = 0
    errors = []

    for i, row in enumerate(rows, start=2):
        report_number = (row.get("日報番号") or "").strip() or None
        if not report_number:
            continue
        # 1ファイル=1日報のため、先頭行で解決したキーを全行に適用
        report_number = resolved_rn

        try:
            entry_ic = (row.get("入口IC") or "").strip() or None
            exit_ic = (row.get("出口IC") or "").strip() or None
            # 利用実績の判定はIC欄で行い、金額では行わない(v10.7.3・FreeNippo正本と同一判定)。
            # 首都高の連結車両(2軸トレーラーヘッド)等はゲート料金非表示のため金額が
            # 0円/空欄でも「利用あり」— 除外すると請求精査から漏れる。
            if not entry_ic and not exit_ic:
                continue

            record = TollRecord(
                report_number=report_number,
                entry_ic=entry_ic,
                exit_ic=exit_ic,
                cost_yen=parse_int(row.get("金額")) or 0,
                toll_type=row.get("区分名", "").strip() or None,
                # 精算日付/精算時刻 = ETC利用日時(v10.7.2 日次明細用)
                used_at=parse_datetime(row.get("精算日付"), row.get("精算時刻")),
            )
            db.add(record)
            imported += 1
        except Exception as e:
            errors.append(f"Row {i}: {e}")

    db.commit()
    return {
        "status": "success",
        "imported": imported,
        "updated": existing,
        "errors": errors,
    }
