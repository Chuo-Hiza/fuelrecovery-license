"""CSV import base — shared utilities for all importers."""
import csv
import hashlib
import io
import re
from datetime import date, datetime
from pathlib import Path


def read_csv_shift_jis(filepath: Path) -> list[dict]:
    """Read a Shift_JIS CSV file and return list of dicts (column-name based)."""
    raw = filepath.read_bytes()
    text = raw.decode("cp932", errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    return list(reader)


def file_sha256(filepath: Path) -> str:
    """Compute SHA-256 hash of a file."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_time_to_sec(time_str: str | None) -> int | None:
    """Convert h:mm:ss or HH:mm:ss or H:mm to seconds."""
    if not time_str or not time_str.strip():
        return None
    time_str = time_str.strip()
    parts = time_str.split(":")
    if len(parts) == 3:
        return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
    if len(parts) == 2:
        return int(parts[0]) * 3600 + int(parts[1]) * 60
    return None


def parse_km_to_m(km_str: str | None) -> int | None:
    """Convert km string (e.g. '123.45') to meters integer."""
    if not km_str or not km_str.strip():
        return None
    try:
        return int(float(km_str.strip()) * 1000)
    except (ValueError, TypeError):
        return None


def parse_int(val: str | None) -> int | None:
    if not val or not val.strip():
        return None
    try:
        return int(val.strip())
    except (ValueError, TypeError):
        return None


def parse_float(val: str | None) -> float | None:
    if not val or not val.strip():
        return None
    try:
        return float(val.strip())
    except (ValueError, TypeError):
        return None


def parse_datetime(date_str: str | None, time_str: str | None = None) -> datetime | None:
    """Parse Estra-WEB2 date/time strings to datetime.
    Accepts: 'yyyy/MM/dd HH:mm:ss', 'yyyy/MM/dd' + 'HH:mm:ss', 'yyyy/MM/dd' + 'HH:mm'
    """
    if not date_str or not date_str.strip():
        return None
    date_str = date_str.strip()
    if time_str:
        combined = f"{date_str} {time_str.strip()}"
    else:
        combined = date_str

    for fmt in ("%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M", "%Y/%m/%d"):
        try:
            return datetime.strptime(combined, fmt)
        except ValueError:
            continue
    return None


def parse_date(date_str: str | None):
    """Parse date string to date object."""
    dt = parse_datetime(date_str)
    return dt.date() if dt else None


def parse_flexible_date(s: str | None) -> date | None:
    """区切り(/, -)・ゼロ埋めの揺れを吸収して date を返す (v10.7.4)。

    '2026/7/5'・'2026-7-5'・'2026-07-05' → date(2026, 7, 5)。
    解釈できない・暦上あり得ない日付は None。
    ※ parse_date (Estra CSV のスラッシュ形式専用) の手入力CSV向け拡張版。
    """
    if not s or not s.strip():
        return None
    parts = s.strip().replace("/", "-").split("-")
    if len(parts) != 3:
        return None
    y, m, d = parts
    if not (y.isdigit() and m.isdigit() and d.isdigit() and len(y) == 4):
        return None
    try:
        return date(int(y), int(m), int(d))
    except ValueError:
        return None


def normalize_year_month(s: str | None) -> str | None:
    """年月文字列を 'YYYY-MM' に正規化する (v10.7.4)。

    '2026/7'・'2026-7' → '2026-07'。月が 1..12 でない・形式不正は None。
    (不正値をそのまま保存すると月次燃費実績の描画が落ちるため、ここで弾く)
    """
    if not s or not s.strip():
        return None
    parts = s.strip().replace("/", "-").split("-")
    if len(parts) != 2:
        return None
    y, m = parts
    if not (y.isdigit() and m.isdigit() and len(y) == 4):
        return None
    mi = int(m)
    if not 1 <= mi <= 12:
        return None
    return f"{y}-{mi:02d}"


def parse_meter_to_m(val: str | None) -> int | None:
    """Convert meter reading (e.g. '13738.70') to integer meters."""
    if not val or not val.strip():
        return None
    try:
        return int(float(val.strip()) * 1000)
    except (ValueError, TypeError):
        return None


def extract_report_number(filename: str) -> str | None:
    """Extract report number from CSV filename.
    Pattern: {report_number}.csv or {report_number}_h.csv etc.
    """
    stem = Path(filename).stem
    # Remove suffixes like _h, _gas, _etc, _evn, _tc
    base = re.sub(r"_(h|gas|etc|evn|tc)$", "", stem)
    return base if base else None


def resolve_report_number(db, raw: str, filename: str) -> tuple[str, str | None]:
    """CSV内の日報番号を trip_reports の実キーへ解決する(共通ヘルパー)。

    ESTRA の日報番号は「顧客コード8桁+出庫日時12桁+車両8桁=28桁」(full形)と
    顧客コード無しの20桁(short形)が経路・ファイル種別で混在する。形式が食い違うと
    子テーブル(時系列・通行料等)が日報に紐づかず画面から消えるため、
    完全一致→full/short相互変換→後方一致(唯一時)の順で照合する。
    (v10.7.2: _tc用の実装を _etc でも使うため base へ共通化)
    """
    from app.models.csv_import import TripReport

    raw = (raw or "").strip()
    candidates = [raw] if raw else []
    fname = extract_report_number(filename) or ""
    if fname and fname != raw:
        candidates.append(fname)
    for c in list(candidates):
        if len(c) == 28 and c[8:] not in candidates:
            candidates.append(c[8:])          # full形 → short形
    for c in candidates:
        if c and db.get(TripReport, c) is not None:
            note = None if c == raw else f"日報番号を {c} に解決(元値: {raw})"
            return c, note
    if raw:
        like = db.query(TripReport.report_number).filter(
            TripReport.report_number.like(f"%{raw}")).limit(2).all()
        if len(like) == 1:
            return like[0][0], f"日報番号を {like[0][0]} に解決(後方一致。元値: {raw})"
    return raw, None  # 日報未着(先に子CSVが来た)等: 元値のまま取り込む


def classify_csv_file(filename: str) -> str | None:
    """Classify CSV file type from filename suffix.
    Returns: 'report', 'detail', 'fuel', 'toll', 'event', 'timeseries',
             'fuel_invoice', or None
    """
    stem = Path(filename).stem
    if stem.endswith("_h"):
        return "detail"
    if stem.endswith("_gas"):
        return "fuel"
    if stem.endswith("_etc"):
        return "toll"
    if stem.endswith("_evn"):
        return "event"
    if stem.endswith("_tc"):
        return "timeseries"
    # 給油請求書(ベンダー横断、複数フォーマット対応)
    if stem.startswith("請求書"):
        return "fuel_invoice"
    if filename.endswith(".csv"):
        return "report"
    return None
