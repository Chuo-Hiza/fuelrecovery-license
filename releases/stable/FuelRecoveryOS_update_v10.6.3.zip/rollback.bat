@echo off
chcp 65001 >NUL
title Fuel Recovery OS - Rollback
setlocal enabledelayedexpansion
set "INSTALL_DIR=%~dp0"
cd /d "%INSTALL_DIR%"
set PORT=8007
set "STAGING=%INSTALL_DIR%update_staging"
set "ROLLBACK=%STAGING%\rollback\previous"
set "APPLIED=%STAGING%\applied"
set "FAILED=%STAGING%\failed"

if not exist "%ROLLBACK%\app" (
    echo [ERROR] No rollback snapshot found at %ROLLBACK%
    pause
    exit /b 1
)

echo ============================================================
echo   Fuel Recovery OS - Rollback in progress
echo ============================================================

REM Wait for any uvicorn to release port (30s)
set /a WAIT=0
:wait_loop
netstat -ano | findstr ":%PORT% " | findstr "LISTENING" >NUL 2>&1
if errorlevel 1 goto port_free
set /a WAIT+=1
if !WAIT! GEQ 30 goto port_free
timeout /t 1 /nobreak >NUL
goto wait_loop
:port_free

REM Preserve failed version artifacts
REM usebackq: パスに空白を含む場合 (e.g. Program Files) も読み込めるよう
set FAILED_VER=unknown
if exist "%APPLIED%\applied_version" (
    for /f "usebackq tokens=*" %%V in ("%APPLIED%\applied_version") do set "FAILED_VER=%%V"
)
mkdir "%FAILED%" 2>NUL
if exist "%FAILED%\v!FAILED_VER!" rmdir /s /q "%FAILED%\v!FAILED_VER!" 2>NUL
move "%APPLIED%" "%FAILED%\v!FAILED_VER!" >NUL 2>&1

REM Restore from snapshot
echo Restoring previous version...
robocopy "%ROLLBACK%\app"    "%INSTALL_DIR%app"    /E /R:3 /W:5 /NFL /NDL /NJH /NJS /NP /XD __pycache__ /XF *.pyc >NUL
robocopy "%ROLLBACK%\static" "%INSTALL_DIR%static" /E /R:3 /W:5 /NFL /NDL /NJH /NJS /NP >NUL
if exist "%ROLLBACK%\start.bat" copy /Y "%ROLLBACK%\start.bat" "%INSTALL_DIR%start.bat" >NUL

REM Force notify mode on next startup
echo rolled_back > "%STAGING%\rollback_force_notify"

REM Restart with restored binaries
echo Restarting with previous version...
start "" /B cmd /c "%INSTALL_DIR%start.bat"
exit /b 0
