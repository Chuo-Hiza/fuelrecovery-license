"""ライセンス期限管理モジュール。

設計概要:
- 初期6ヶ月は無償試用 (顧客ID不要、オフライン)。install_date を SystemSetting に保存し、
  install_date + 6ヶ月 を試用期限とする。
- 顧客ID が SystemSetting に設定されると本契約フェーズに移行。
  GitHub Pages 上の自顧客JSONを毎日チェックし、ベンダーが指定した期限を取得する。
- 期限切れ後、7日のGrace期間（読み取り専用）→ Locked（完全停止）。
- システム時刻改ざんへの耐性として last_seen_date を毎ページ表示時に更新し、
  effective_date = max(today, last_seen, latest_trip_date) を判定基準とする。
"""
from __future__ import annotations

import base64
import json
import logging
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Optional

from sqlalchemy import func
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

# ── 設定値 ────────────────────────────────────────────────────────
TRIAL_DURATION_DAYS = 180  # 6ヶ月相当
GRACE_PERIOD_DAYS = 7
NOTICE_THRESHOLD = 30  # 残30日で黄バナー
WARNING_THRESHOLD = 14
CRITICAL_THRESHOLD = 7
NETWORK_FAILURE_BANNER_DAYS = 14  # 連続14日チェック失敗で警告

# ベンダーが管理する GitHub Pages のベースURL
# Chuo-Hiza/fuelrecovery-license リポジトリ (https://github.com/Chuo-Hiza/fuelrecovery-license)
DEFAULT_LICENSE_BASE_URL = "https://chuo-hiza.github.io/fuelrecovery-license/customers"

PUBLIC_KEY_PATH = Path(__file__).parent / "license_keys" / "public.pem"


# ── データクラス ───────────────────────────────────────────────────
class LicensePhase(str, Enum):
    TRIAL = "trial"
    ACTIVE = "active"
    NOTICE = "notice"
    WARNING = "warning"
    CRITICAL = "critical"
    GRACE = "grace"
    LOCKED = "locked"
    NETWORK_ERROR = "network_error"


@dataclass
class LicenseStatus:
    phase: LicensePhase
    expiry_date: Optional[date]
    days_remaining: int  # 期限まで何日 (負数=期限切れ後経過日数)
    customer_id: Optional[str]
    customer_name: Optional[str]
    last_check_date: Optional[datetime]
    last_check_success: bool
    network_failure_days: int  # 連続失敗日数
    is_trial: bool

    @property
    def is_writable(self) -> bool:
        """書込可能か (False の場合 read-only mode)"""
        return self.phase not in (LicensePhase.GRACE, LicensePhase.LOCKED)

    @property
    def is_locked(self) -> bool:
        """完全ロック状態か (License更新画面のみアクセス可)"""
        return self.phase == LicensePhase.LOCKED

    @property
    def banner_color(self) -> Optional[str]:
        """バナー色 (#hex) or None で非表示"""
        return {
            LicensePhase.NOTICE: "#F5A623",  # 黄
            LicensePhase.WARNING: "#E8652D",  # 橙
            LicensePhase.CRITICAL: "#E03E3E",  # 赤
            LicensePhase.GRACE: "#E03E3E",  # 赤
            LicensePhase.NETWORK_ERROR: "#F5A623",  # 黄
        }.get(self.phase)

    @property
    def banner_message(self) -> Optional[str]:
        if self.phase == LicensePhase.NOTICE:
            return f"ライセンス期限まで残り {self.days_remaining} 日です"
        if self.phase == LicensePhase.WARNING:
            return f"ライセンス期限まで残り {self.days_remaining} 日 — まもなく切れます"
        if self.phase == LicensePhase.CRITICAL:
            return f"⚠ ライセンス期限まで残り {self.days_remaining} 日です（要更新）"
        if self.phase == LicensePhase.GRACE:
            grace_days_left = GRACE_PERIOD_DAYS - abs(self.days_remaining)
            return (f"⚠ ライセンス期限切れ — あと {grace_days_left} 日後に"
                    f"完全ロックされます。ベンダーまでご連絡ください")
        if self.phase == LicensePhase.NETWORK_ERROR:
            return ("ライセンスサーバに接続できません。"
                    "ネットワーク接続を確認してください")
        return None


# ── 署名検証 ──────────────────────────────────────────────────────
def _load_public_key():
    """埋め込みの公開鍵をロード。"""
    from cryptography.hazmat.primitives import serialization
    with open(PUBLIC_KEY_PATH, "rb") as f:
        return serialization.load_pem_public_key(f.read())


def verify_json_signature(payload: dict) -> bool:
    """ライセンスJSON の signature フィールドを Ed25519 で検証する。

    対象データ: customer_id|customer_name|issued|expiry の連結文字列
    """
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        public_key = _load_public_key()
        if not isinstance(public_key, Ed25519PublicKey):
            logger.error("Public key is not Ed25519")
            return False

        sig_b64 = payload.get("signature")
        if not sig_b64:
            return False

        signed_message = (
            f"{payload['customer_id']}|"
            f"{payload['customer_name']}|"
            f"{payload['issued']}|"
            f"{payload['expiry']}"
        ).encode("utf-8")
        signature = base64.b64decode(sig_b64)
        public_key.verify(signature, signed_message)
        return True
    except Exception as e:
        logger.warning(f"Signature verification failed: {e}")
        return False


# ── DB アクセス ────────────────────────────────────────────────────
def _get_setting(db: Session, key: str) -> Optional[str]:
    from app.models.system import SystemSetting
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    return row.value if row else None


def _set_setting(db: Session, key: str, value: str) -> None:
    from app.models.system import SystemSetting
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    if row:
        row.value = value
    else:
        row = SystemSetting(key=key, value=value)
        db.add(row)
    db.commit()


def get_install_date(db: Session) -> date:
    """インストール日を返す。未設定なら今日でセット。"""
    val = _get_setting(db, "license_install_date")
    if val:
        try:
            return datetime.strptime(val, "%Y-%m-%d").date()
        except ValueError:
            pass
    today = date.today()
    _set_setting(db, "license_install_date", today.isoformat())
    return today


def get_customer_id(db: Session) -> Optional[str]:
    """顧客IDを返す。空文字や空白だけの場合は None として扱う
    (= 試用版モード)。これにより誤って空値が DB に書かれた場合も
    試用版にフォールバックする。"""
    val = _get_setting(db, "license_customer_id")
    if val and val.strip():
        return val.strip()
    return None


def set_customer_id(db: Session, customer_id: str) -> None:
    _set_setting(db, "license_customer_id", customer_id.strip())


def get_last_seen_date(db: Session) -> Optional[date]:
    val = _get_setting(db, "license_last_seen_date")
    if val:
        try:
            return datetime.strptime(val, "%Y-%m-%d").date()
        except ValueError:
            pass
    return None


def update_last_seen_date(db: Session) -> None:
    """毎ページ表示時に呼ばれる。今日 > 保存値なら更新する（単調増加）。"""
    today = date.today()
    stored = get_last_seen_date(db)
    if stored is None or today > stored:
        _set_setting(db, "license_last_seen_date", today.isoformat())


def get_latest_trip_date(db: Session) -> Optional[date]:
    """DB上の最新の業務日を返す（改ざん耐性用）。"""
    try:
        from app.models.csv_import import TripReport
        result = db.query(func.max(TripReport.operation_date)).scalar()
        return result
    except Exception:
        return None


def compute_effective_date(db: Session) -> date:
    """改ざん耐性のある「現在日」を計算する。

    システム時計を巻き戻されても、過去の last_seen_date や
    DBの最新trip date が優先される。
    """
    today = date.today()
    last_seen = get_last_seen_date(db)
    latest_trip = get_latest_trip_date(db)
    candidates = [today]
    if last_seen:
        candidates.append(last_seen)
    if latest_trip:
        candidates.append(latest_trip)
    return max(candidates)


def get_stored_expiry_date(db: Session) -> Optional[date]:
    val = _get_setting(db, "license_expiry_date")
    if val:
        try:
            return datetime.strptime(val, "%Y-%m-%d").date()
        except ValueError:
            pass
    return None


def set_stored_expiry_date(db: Session, expiry: date) -> None:
    _set_setting(db, "license_expiry_date", expiry.isoformat())


def get_customer_name(db: Session) -> Optional[str]:
    return _get_setting(db, "license_customer_name")


def set_customer_name(db: Session, name: str) -> None:
    _set_setting(db, "license_customer_name", name)


def get_last_check_info(db: Session) -> tuple[Optional[datetime], bool, int]:
    """最終チェック日時、成否、連続失敗日数を返す。"""
    iso = _get_setting(db, "license_last_check_date")
    last_dt = None
    if iso:
        try:
            last_dt = datetime.fromisoformat(iso)
        except ValueError:
            pass
    success = _get_setting(db, "license_last_check_success") == "true"
    fail_count_str = _get_setting(db, "license_check_failure_count") or "0"
    try:
        fail_count = int(fail_count_str)
    except ValueError:
        fail_count = 0
    return last_dt, success, fail_count


def record_check_result(db: Session, success: bool) -> None:
    now = datetime.now()
    _set_setting(db, "license_last_check_date", now.isoformat(timespec="seconds"))
    _set_setting(db, "license_last_check_success", "true" if success else "false")
    if success:
        _set_setting(db, "license_check_failure_count", "0")
    else:
        _, _, fail_count = get_last_check_info(db)
        _set_setting(db, "license_check_failure_count", str(fail_count + 1))


# ── フェーズ計算 ───────────────────────────────────────────────────
def compute_status(db: Session) -> LicenseStatus:
    """現在のライセンス状態を判定する。"""
    effective_date = compute_effective_date(db)
    install_date = get_install_date(db)
    customer_id = get_customer_id(db)
    customer_name = get_customer_name(db)
    last_check_dt, last_success, fail_count = get_last_check_info(db)

    is_trial = customer_id is None
    if is_trial:
        # 顧客ID未設定 → 試用期限 = install + 6ヶ月
        expiry = install_date + timedelta(days=TRIAL_DURATION_DAYS)
    else:
        # 本契約 → DBに保存された期限を使う (なければ install + 6ヶ月)
        expiry = get_stored_expiry_date(db) or (install_date + timedelta(days=TRIAL_DURATION_DAYS))

    days_remaining = (expiry - effective_date).days
    phase = _phase_from_days(days_remaining)

    # ネットワーク連続失敗の警告 (本契約フェーズかつ Active/Notice 中のみ)
    if (not is_trial
            and phase in (LicensePhase.ACTIVE, LicensePhase.NOTICE)
            and fail_count >= NETWORK_FAILURE_BANNER_DAYS):
        phase = LicensePhase.NETWORK_ERROR

    return LicenseStatus(
        phase=phase,
        expiry_date=expiry,
        days_remaining=days_remaining,
        customer_id=customer_id,
        customer_name=customer_name,
        last_check_date=last_check_dt,
        last_check_success=last_success,
        network_failure_days=fail_count,
        is_trial=is_trial,
    )


def _phase_from_days(days: int) -> LicensePhase:
    if days >= 31:
        return LicensePhase.ACTIVE
    if days >= 15:
        return LicensePhase.NOTICE
    if days >= 8:
        return LicensePhase.WARNING
    if days >= 1:
        return LicensePhase.CRITICAL
    if days >= -GRACE_PERIOD_DAYS:
        return LicensePhase.GRACE
    return LicensePhase.LOCKED


# ── オンラインチェック ──────────────────────────────────────────────
def fetch_and_apply_license(db: Session, base_url: Optional[str] = None) -> bool:
    """GitHub Pages から自顧客のライセンスJSONを取得して適用する。

    成功時 True、失敗時 False を返す。失敗カウントもDBに記録される。
    顧客ID 未設定時は何もしない (試用フェーズはオンラインチェック不要)。
    """
    customer_id = get_customer_id(db)
    if not customer_id:
        return False

    base = base_url or DEFAULT_LICENSE_BASE_URL
    url = f"{base.rstrip('/')}/{customer_id}.json"

    try:
        import httpx
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(url)
            resp.raise_for_status()
            payload = resp.json()
    except Exception as e:
        logger.warning(f"License fetch failed from {url}: {e}")
        record_check_result(db, success=False)
        return False

    # 署名検証
    if not verify_json_signature(payload):
        logger.error(f"Invalid signature for license JSON from {url}")
        record_check_result(db, success=False)
        return False

    # 顧客IDが一致するか確認 (URL差し替え攻撃対策)
    if payload.get("customer_id") != customer_id:
        logger.error(
            f"Customer ID mismatch: expected {customer_id}, got {payload.get('customer_id')}"
        )
        record_check_result(db, success=False)
        return False

    # 期限を保存
    try:
        expiry = datetime.strptime(payload["expiry"], "%Y-%m-%d").date()
    except (KeyError, ValueError) as e:
        logger.error(f"Invalid expiry in license JSON: {e}")
        record_check_result(db, success=False)
        return False

    set_stored_expiry_date(db, expiry)
    set_customer_name(db, payload.get("customer_name", ""))
    record_check_result(db, success=True)
    logger.info(
        f"License updated for {customer_id}: expiry={expiry}, "
        f"name={payload.get('customer_name')}"
    )
    return True


def should_check_now(db: Session) -> bool:
    """24時間以上前 or 一度もチェックしていない場合に True"""
    last_check, _, _ = get_last_check_info(db)
    if last_check is None:
        return True
    return (datetime.now() - last_check) > timedelta(hours=24)
