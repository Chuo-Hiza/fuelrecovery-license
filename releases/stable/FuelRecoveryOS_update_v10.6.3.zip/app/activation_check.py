"""Activation check / activate script.

Usage:
    python app/activation_check.py          -> exit 0 if activated, exit 1 if not
    python app/activation_check.py PASSWORD -> activate with password, exit 0 if ok, exit 1 if bad
"""
import sys
import os

# Ensure project root is in path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import SessionLocal, Base, engine
from app.activation import check_activation, activate

Base.metadata.create_all(bind=engine)
db = SessionLocal()

try:
    if len(sys.argv) >= 2:
        # Activate mode
        password = sys.argv[1]
        ok = activate(db, password)
        sys.exit(0 if ok else 1)
    else:
        # Check mode
        ok = check_activation(db)
        sys.exit(0 if ok else 1)
finally:
    db.close()
