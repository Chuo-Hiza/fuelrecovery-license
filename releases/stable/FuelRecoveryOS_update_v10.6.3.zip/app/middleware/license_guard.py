"""ライセンス期限ミドルウェア。

- Locked フェーズ: 全GETを /license_locked にリダイレクト
  (例外: /license_locked, /static, /health, /settings/license の GET/POST)
- Grace フェーズ: 書込系メソッド (POST/PUT/PATCH/DELETE) を 403 Forbidden で拒否
  (例外: /settings/license, /license_unlock など)
"""
from __future__ import annotations

import logging

from fastapi import Request
from fastapi.responses import JSONResponse, RedirectResponse
from starlette.middleware.base import BaseHTTPMiddleware

from app.database import SessionLocal
from app.license import LicensePhase, compute_status, update_last_seen_date

logger = logging.getLogger(__name__)

# ロックダウン中でもアクセスを許可するパスプレフィックス
LOCKDOWN_ALLOWED_PREFIXES = (
    "/license_locked",
    "/settings/license",
    "/static",
    "/health",
)

# Grace期(読み取り専用)で書込を許可するパスプレフィックス
GRACE_WRITE_ALLOWED_PREFIXES = (
    "/settings/license",
    "/license_locked",
)


class LicenseGuardMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        method = request.method

        # last_seen_date の更新 + 状態取得
        # DBエラーで全リクエストが落ちないよう、エラーをキャッチして通常処理を継続
        status = None
        try:
            db = SessionLocal()
            try:
                update_last_seen_date(db)
                status = compute_status(db)
            finally:
                db.close()
        except Exception as e:
            logger.error("License guard DB error: %s", e, exc_info=True)
            # DBエラー時はライセンスチェックをスキップして通常処理
            return await call_next(request)

        # request.state にぶら下げて全ルーター/テンプレートで参照可能にする
        request.state.license_status = status

        # Locked フェーズ: 許可されたパス以外は強制リダイレクト
        if status.phase == LicensePhase.LOCKED:
            if not any(path.startswith(p) for p in LOCKDOWN_ALLOWED_PREFIXES):
                # POST等もすべて /license_locked へ
                return RedirectResponse(url="/license_locked", status_code=302)

        # Grace フェーズ: 書込系メソッドを遮断 (例外パス以外)
        if status.phase == LicensePhase.GRACE and method in ("POST", "PUT", "PATCH", "DELETE"):
            if not any(path.startswith(p) for p in GRACE_WRITE_ALLOWED_PREFIXES):
                return JSONResponse(
                    status_code=403,
                    content={
                        "detail": (
                            "ライセンス期限切れのため読み取り専用モードです。"
                            "ベンダーまでご連絡ください。"
                        )
                    },
                )

        response = await call_next(request)
        return response
