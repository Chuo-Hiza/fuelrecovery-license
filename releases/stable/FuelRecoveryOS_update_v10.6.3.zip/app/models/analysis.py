"""Group C: Analysis tables — FR-OS computed data."""
from datetime import date, datetime

from sqlalchemy import (
    BigInteger, Boolean, Date, DateTime, Float, Index, Integer, String, UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class BaselineGroup(Base):
    """同条件グループ — 車格×積載×路線種別×時間帯×季節。"""
    __tablename__ = "baseline_groups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vehicle_type_code: Mapped[str] = mapped_column(String(8), comment="車種コード")
    loading_category: Mapped[str] = mapped_column(String(10), comment="積載帯(empty/half/full)")
    route_category: Mapped[str] = mapped_column(String(20), comment="路線種別(urban/highway/rural)")
    time_period: Mapped[str] = mapped_column(String(10), comment="時間帯(morning/daytime/night)")
    season: Mapped[str] = mapped_column(String(10), comment="季節(spring/summer/autumn/winter)")
    sample_count: Mapped[int] = mapped_column(Integer, default=0, comment="サンプル数")
    expected_efficiency_kml: Mapped[float | None] = mapped_column(Float, comment="期待燃費(km/L)")
    median_efficiency_kml: Mapped[float | None] = mapped_column(Float, comment="中央値燃費(km/L)")
    std_dev: Mapped[float | None] = mapped_column(Float, comment="標準偏差")
    updated_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now)

    __table_args__ = (
        UniqueConstraint("vehicle_type_code", "loading_category", "route_category",
                         "time_period", "season", name="uq_baseline_condition"),
    )


class TripAnalysis(Base):
    """運行別分析 — 実績 vs 期待値、4層要因分解。"""
    __tablename__ = "trip_analysis"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    report_number: Mapped[str] = mapped_column(String(24), unique=True, index=True, comment="日報番号")
    operation_date: Mapped[date | None] = mapped_column(Date, index=True)
    baseline_group_id: Mapped[int | None] = mapped_column(Integer, comment="適用ベースラインID")

    # 燃費比較
    expected_efficiency: Mapped[float | None] = mapped_column(Float, comment="期待燃費(km/L)")
    actual_efficiency: Mapped[float | None] = mapped_column(Float, comment="実績燃費(km/L)")
    deviation_pct: Mapped[float | None] = mapped_column(Float, comment="乖離率(%)")

    # 損失総量
    total_loss_l: Mapped[float | None] = mapped_column(Float, comment="総損失(L)")
    total_loss_yen: Mapped[int | None] = mapped_column(Integer, comment="総損失(円)")

    # 4層分解
    driving_loss_l: Mapped[float | None] = mapped_column(Float, comment="運転由来損失(L)")
    dispatch_loss_l: Mapped[float | None] = mapped_column(Float, comment="配車由来損失(L)")
    shipper_loss_l: Mapped[float | None] = mapped_column(Float, comment="荷主由来損失(L)")
    vehicle_loss_l: Mapped[float | None] = mapped_column(Float, comment="車両由来損失(L)")

    # 詳細内訳
    idle_loss_l: Mapped[float | None] = mapped_column(Float, comment="アイドリング損失(L)")
    accel_loss_l: Mapped[float | None] = mapped_column(Float, comment="急加減速損失(L)")
    rpm_loss_l: Mapped[float | None] = mapped_column(Float, comment="高回転損失(L)")
    wait_loss_l: Mapped[float | None] = mapped_column(Float, comment="荷待ち損失(L)")
    congestion_loss_l: Mapped[float | None] = mapped_column(Float, comment="渋滞損失(L)")

    avoidable: Mapped[bool | None] = mapped_column(Boolean, comment="回避可能フラグ")
    analyzed_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class DailySummary(Base):
    """日次サマリ — 営業所/乗務員/車両別の日次集計。"""
    __tablename__ = "daily_summaries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    summary_date: Mapped[date] = mapped_column(Date, index=True)
    office_code: Mapped[str | None] = mapped_column(String(8), index=True)
    driver_code: Mapped[str | None] = mapped_column(String(8))
    vehicle_code: Mapped[str | None] = mapped_column(String(8))

    trip_count: Mapped[int] = mapped_column(Integer, default=0)
    total_distance_m: Mapped[int] = mapped_column(Integer, default=0)
    total_fuel_l: Mapped[float] = mapped_column(Float, default=0.0)
    actual_efficiency_kml: Mapped[float | None] = mapped_column(Float)

    total_loss_l: Mapped[float] = mapped_column(Float, default=0.0)
    total_loss_yen: Mapped[int] = mapped_column(Integer, default=0)
    avoidable_loss_l: Mapped[float] = mapped_column(Float, default=0.0)
    avoidable_loss_yen: Mapped[int] = mapped_column(Integer, default=0)

    driving_loss_l: Mapped[float] = mapped_column(Float, default=0.0)
    dispatch_loss_l: Mapped[float] = mapped_column(Float, default=0.0)
    shipper_loss_l: Mapped[float] = mapped_column(Float, default=0.0)
    vehicle_loss_l: Mapped[float] = mapped_column(Float, default=0.0)

    idle_rate_pct: Mapped[float | None] = mapped_column(Float, comment="アイドリング率(%)")
    empty_run_rate_pct: Mapped[float | None] = mapped_column(Float, comment="空車回送比率(%)")

    computed_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)

    __table_args__ = (
        Index("ix_daily_office_date", "office_code", "summary_date"),
        UniqueConstraint("summary_date", "driver_code", "vehicle_code", name="uq_daily_summary"),
    )


class MonthlySummary(Base):
    """月次サマリ。"""
    __tablename__ = "monthly_summaries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    month: Mapped[str] = mapped_column(String(7), index=True, comment="YYYY-MM")
    office_code: Mapped[str | None] = mapped_column(String(8), index=True)
    driver_code: Mapped[str | None] = mapped_column(String(8))
    vehicle_code: Mapped[str | None] = mapped_column(String(8))

    trip_count: Mapped[int] = mapped_column(Integer, default=0)
    total_distance_m: Mapped[int] = mapped_column(Integer, default=0)
    total_fuel_l: Mapped[float] = mapped_column(Float, default=0.0)
    total_fuel_yen: Mapped[int] = mapped_column(Integer, default=0)
    actual_efficiency_kml: Mapped[float | None] = mapped_column(Float)

    total_loss_l: Mapped[float] = mapped_column(Float, default=0.0)
    total_loss_yen: Mapped[int] = mapped_column(Integer, default=0)
    avoidable_loss_l: Mapped[float] = mapped_column(Float, default=0.0)
    avoidable_loss_yen: Mapped[int] = mapped_column(Integer, default=0)
    recovery_l: Mapped[float] = mapped_column(Float, default=0.0, comment="回収済み(L)")
    recovery_rate_pct: Mapped[float | None] = mapped_column(Float, comment="回収率(%)")

    driving_loss_l: Mapped[float] = mapped_column(Float, default=0.0)
    dispatch_loss_l: Mapped[float] = mapped_column(Float, default=0.0)
    shipper_loss_l: Mapped[float] = mapped_column(Float, default=0.0)
    vehicle_loss_l: Mapped[float] = mapped_column(Float, default=0.0)

    idle_rate_pct: Mapped[float | None] = mapped_column(Float)
    empty_run_rate_pct: Mapped[float | None] = mapped_column(Float)

    computed_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)

    __table_args__ = (
        UniqueConstraint("month", "office_code", "driver_code", "vehicle_code", name="uq_monthly_summary"),
    )
