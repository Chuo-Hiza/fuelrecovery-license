"""Group B: Master tables — synced from Estra-WEB2 masters."""
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class Driver(Base):
    """乗務員マスタ。"""
    __tablename__ = "drivers"
    code: Mapped[str] = mapped_column(String(8), primary_key=True, comment="乗務員コード")
    name: Mapped[str] = mapped_column(String(50), comment="乗務員名")
    office_code: Mapped[str | None] = mapped_column(String(8), index=True, comment="所属事業所")
    org_code: Mapped[str | None] = mapped_column(String(8), comment="所属組織")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    synced_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class Vehicle(Base):
    """車両マスタ。"""
    __tablename__ = "vehicles"
    code: Mapped[str] = mapped_column(String(8), primary_key=True, comment="車両コード")
    name: Mapped[str] = mapped_column(String(50), comment="車両名")
    vehicle_type_code: Mapped[str | None] = mapped_column(String(8), index=True, comment="車種コード")
    office_code: Mapped[str | None] = mapped_column(String(8), index=True, comment="所属事業所")
    year: Mapped[int | None] = mapped_column(Integer, comment="年式")
    transmission: Mapped[str | None] = mapped_column(String(10), comment="ミッション(AT/MT)")
    baseline_efficiency_kml: Mapped[float | None] = mapped_column(Float, comment="基準燃費(km/L)")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    synced_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class VehicleType(Base):
    """車種マスタ。"""
    __tablename__ = "vehicle_types"
    code: Mapped[str] = mapped_column(String(8), primary_key=True, comment="車種コード")
    name: Mapped[str] = mapped_column(String(50), comment="車種名")
    tonnage: Mapped[float | None] = mapped_column(Float, comment="トン数")
    body_type: Mapped[str | None] = mapped_column(String(30), comment="架装(ウイング/バン/冷凍等)")
    synced_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class Organization(Base):
    """組織/事業所マスタ。"""
    __tablename__ = "organizations"
    code: Mapped[str] = mapped_column(String(8), primary_key=True, comment="組織コード")
    name: Mapped[str] = mapped_column(String(50), comment="組織名")
    parent_code: Mapped[str | None] = mapped_column(String(8), comment="親組織コード")
    level: Mapped[int | None] = mapped_column(Integer, comment="階層レベル")
    synced_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class Shipper(Base):
    """荷主マスタ。"""
    __tablename__ = "shippers"
    code: Mapped[str] = mapped_column(String(16), primary_key=True, comment="荷主コード")
    name: Mapped[str] = mapped_column(String(100), comment="荷主名")
    synced_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class Destination(Base):
    """集配先マスタ。"""
    __tablename__ = "destinations"
    code: Mapped[str] = mapped_column(String(16), primary_key=True, comment="集配先コード")
    name: Mapped[str] = mapped_column(String(100), comment="集配先名")
    address: Mapped[str | None] = mapped_column(String(200), comment="住所")
    gps_lat: Mapped[int | None] = mapped_column(Integer, comment="GPS緯度")
    gps_lon: Mapped[int | None] = mapped_column(Integer, comment="GPS経度")
    synced_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class Route(Base):
    """コースマスタ。"""
    __tablename__ = "routes"
    code: Mapped[str] = mapped_column(String(16), primary_key=True, comment="コースコード")
    name: Mapped[str] = mapped_column(String(100), comment="コース名")
    synced_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class LoadingStatus(Base):
    """積載状況マスタ。"""
    __tablename__ = "loading_statuses"
    code: Mapped[str] = mapped_column(String(8), primary_key=True, comment="積載状況コード")
    name: Mapped[str] = mapped_column(String(50), comment="積載状況名")
    synced_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class FuelStation(Base):
    """給油スタンドマスタ。"""
    __tablename__ = "fuel_stations"
    code: Mapped[str] = mapped_column(String(16), primary_key=True, comment="スタンドコード")
    name: Mapped[str] = mapped_column(String(100), comment="スタンド名")
    synced_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)
