"""Group A: CSV import tables — receiving Estra-WEB2 data."""
from datetime import date, datetime

from sqlalchemy import (
    BigInteger, Date, DateTime, Float, ForeignKey, Index, Integer, JSON, String, Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class TripReport(Base):
    """日報 — 1運行1レコード。Fuel Recovery OS の中核テーブル。"""
    __tablename__ = "trip_reports"

    # ── 基本情報 (No.1-22) ──
    report_number: Mapped[str] = mapped_column(String(24), primary_key=True, comment="日報番号")
    operation_date: Mapped[date] = mapped_column(Date, index=True, comment="運行日")
    driver_code: Mapped[str] = mapped_column(String(8), index=True, comment="乗務員コード")
    driver_name: Mapped[str | None] = mapped_column(String(50), comment="乗務員名")
    vehicle_code: Mapped[str] = mapped_column(String(8), index=True, comment="車両コード")
    vehicle_name: Mapped[str | None] = mapped_column(String(50), comment="車両名")
    driver_office_code: Mapped[str | None] = mapped_column(String(8), index=True, comment="乗務員事業所コード")
    driver_office_name: Mapped[str | None] = mapped_column(String(50), comment="乗務員事業所名")
    driver_org_code: Mapped[str | None] = mapped_column(String(8), comment="乗務員組織コード")
    driver_org_name: Mapped[str | None] = mapped_column(String(50), comment="乗務員組織名")
    vehicle_office_code: Mapped[str | None] = mapped_column(String(8), comment="車両事業所コード")
    vehicle_office_name: Mapped[str | None] = mapped_column(String(50))
    vehicle_org_code: Mapped[str | None] = mapped_column(String(8))
    vehicle_org_name: Mapped[str | None] = mapped_column(String(50))
    setting_group_code: Mapped[int | None] = mapped_column(Integer, comment="設定グループコード")
    setting_group_name: Mapped[str | None] = mapped_column(String(50))
    two_man_report_number: Mapped[str | None] = mapped_column(String(24), comment="2マン日報番号")
    weather: Mapped[str | None] = mapped_column(String(20), comment="天候")
    course_code: Mapped[str | None] = mapped_column(String(16), comment="コースコード")
    course_name: Mapped[str | None] = mapped_column(String(50), comment="コース名称")

    # ── 出庫/入庫 (No.24-31) ──
    departure_datetime: Mapped[datetime | None] = mapped_column(DateTime, comment="出庫日時")
    arrival_datetime: Mapped[datetime | None] = mapped_column(DateTime, comment="入庫日時")
    departure_meter: Mapped[int | None] = mapped_column(Integer, comment="出庫メータ(m)")
    arrival_meter: Mapped[int | None] = mapped_column(Integer, comment="入庫メータ(m)")

    # ── 走行距離 (No.32-45) 全てメートル格納 ──
    distance_m: Mapped[int | None] = mapped_column(Integer, comment="走行距離(m)")
    general_loaded_m: Mapped[int | None] = mapped_column(Integer, comment="一般実車距離(m)")
    general_empty_m: Mapped[int | None] = mapped_column(Integer, comment="一般空車距離(m)")
    highway_loaded_m: Mapped[int | None] = mapped_column(Integer, comment="高速実車距離(m)")
    highway_empty_m: Mapped[int | None] = mapped_column(Integer, comment="高速空車距離(m)")
    dedicated_loaded_m: Mapped[int | None] = mapped_column(Integer, comment="専用道実車距離(m)")
    dedicated_empty_m: Mapped[int | None] = mapped_column(Integer, comment="専用道空車距離(m)")

    # ── 時間 (No.37-48) 全て秒格納 ──
    empty_time_sec: Mapped[int | None] = mapped_column(Integer, comment="空車時間(秒)")
    loaded_time_sec: Mapped[int | None] = mapped_column(Integer, comment="実車時間(秒)")
    empty_driving_sec: Mapped[int | None] = mapped_column(Integer, comment="空車走行時間(秒)")
    loaded_driving_sec: Mapped[int | None] = mapped_column(Integer, comment="実車走行時間(秒)")
    general_driving_sec: Mapped[int | None] = mapped_column(Integer, comment="一般走行時間(秒)")
    highway_driving_sec: Mapped[int | None] = mapped_column(Integer, comment="高速走行時間(秒)")
    dedicated_driving_sec: Mapped[int | None] = mapped_column(Integer, comment="専用道走行時間(秒)")
    working_time_sec: Mapped[int | None] = mapped_column(Integer, comment="稼動時間(秒)")
    idle_time_sec: Mapped[int | None] = mapped_column(Integer, comment="アイドリング時間(秒)")
    stop_time_sec: Mapped[int | None] = mapped_column(Integer, comment="停止時間(秒)")

    # ── 勤務・作業時間 (No.49-71) ──
    work_start_datetime: Mapped[datetime | None] = mapped_column(DateTime, comment="始業日時")
    work_end_datetime: Mapped[datetime | None] = mapped_column(DateTime, comment="終業日時")
    employment_sec: Mapped[int | None] = mapped_column(Integer, comment="就業時間(秒)")
    overtime_sec: Mapped[int | None] = mapped_column(Integer, comment="残業時間(秒)")
    night_sec: Mapped[int | None] = mapped_column(Integer, comment="深夜時間(秒)")
    loading_time_sec: Mapped[int | None] = mapped_column(Integer, comment="荷積み時間(秒)")
    unloading_time_sec: Mapped[int | None] = mapped_column(Integer, comment="荷卸し時間(秒)")
    waiting_time_sec: Mapped[int | None] = mapped_column(Integer, comment="待機時間(秒)")
    inspection_sec: Mapped[int | None] = mapped_column(Integer, comment="点検時間(秒)")
    break_sec: Mapped[int | None] = mapped_column(Integer, comment="休憩時間(秒)")
    rest_sec: Mapped[int | None] = mapped_column(Integer, comment="休息時間(秒)")
    other_work1_sec: Mapped[int | None] = mapped_column(Integer, comment="他作業1時間(秒)")
    other_work2_sec: Mapped[int | None] = mapped_column(Integer, comment="他作業2時間(秒)")
    other_work3_sec: Mapped[int | None] = mapped_column(Integer, comment="他作業3時間(秒)")
    other_work4_sec: Mapped[int | None] = mapped_column(Integer, comment="他作業4時間(秒)")
    pto_dpr_sec: Mapped[int | None] = mapped_column(Integer, comment="PTO/DPR時間(秒)")
    ferry_sec: Mapped[int | None] = mapped_column(Integer, comment="フェリー時間(秒)")

    # ── 回数 (No.72-81) ──
    loading_count: Mapped[int | None] = mapped_column(Integer, comment="荷積み回数")
    unloading_count: Mapped[int | None] = mapped_column(Integer, comment="荷卸し回数")
    pto_dpr_count: Mapped[int | None] = mapped_column(Integer, comment="PTO/DPR回数")

    # ── 評価 (No.82-87) ──
    safety_rank: Mapped[str | None] = mapped_column(String(1), comment="安全運転評価ランク")
    economy_rank: Mapped[str | None] = mapped_column(String(1), comment="経済運転評価ランク")
    overall_rank: Mapped[str | None] = mapped_column(String(1), comment="総合評価ランク")
    safety_score: Mapped[float | None] = mapped_column(Float, comment="安全運転評価点")
    economy_score: Mapped[float | None] = mapped_column(Float, comment="経済運転評価点")
    overall_score: Mapped[float | None] = mapped_column(Float, comment="総合評価点")

    # ── 燃費 (No.94-98) ──
    fuel_amount_l: Mapped[float | None] = mapped_column(Float, comment="燃費対象給油量(L)")
    prev_fuel_meter: Mapped[int | None] = mapped_column(Integer, comment="前回給油メータ(m)")
    curr_fuel_meter: Mapped[int | None] = mapped_column(Integer, comment="今回給油メータ(m)")
    fuel_section_m: Mapped[int | None] = mapped_column(Integer, comment="区間距離(m)")
    fuel_efficiency_kml: Mapped[float | None] = mapped_column(Float, comment="燃費(km/L)")

    # ── 運転イベント (No.99-170 主要項目) ──
    toll_total_yen: Mapped[int | None] = mapped_column(Integer, comment="通行料合計(円)")
    max_continuous_sec: Mapped[int | None] = mapped_column(Integer, comment="連続走行時間(秒)")
    max_speed_empty_general: Mapped[int | None] = mapped_column(Integer, comment="最高速度:空車一般(km/h)")
    max_speed_loaded_general: Mapped[int | None] = mapped_column(Integer, comment="最高速度:実車一般(km/h)")
    max_speed_empty_highway: Mapped[int | None] = mapped_column(Integer, comment="最高速度:空車高速(km/h)")
    max_speed_loaded_highway: Mapped[int | None] = mapped_column(Integer, comment="最高速度:実車高速(km/h)")
    speed_over_general_count: Mapped[int | None] = mapped_column(Integer, comment="速度オーバー回数:一般")
    speed_over_highway_count: Mapped[int | None] = mapped_column(Integer, comment="速度オーバー回数:高速")
    speed_over_dedicated_count: Mapped[int | None] = mapped_column(Integer, comment="速度オーバー回数:専用道")
    speed_over_general_sec: Mapped[int | None] = mapped_column(Integer, comment="速度オーバー時間:一般(秒)")
    speed_over_highway_sec: Mapped[int | None] = mapped_column(Integer, comment="速度オーバー時間:高速(秒)")
    sudden_accel_count: Mapped[int | None] = mapped_column(Integer, comment="急加速回数")
    sudden_decel_count: Mapped[int | None] = mapped_column(Integer, comment="急減速回数")
    sudden_start_count: Mapped[int | None] = mapped_column(Integer, comment="急発進回数")
    sudden_turn_count: Mapped[int | None] = mapped_column(Integer, comment="急旋回回数")
    lane_departure_count: Mapped[int | None] = mapped_column(Integer, comment="車線逸脱警報回数")
    sway_count: Mapped[int | None] = mapped_column(Integer, comment="ふらつき回数")
    sudden_brake_count: Mapped[int | None] = mapped_column(Integer, comment="急ブレーキ回数")
    following_distance_count: Mapped[int | None] = mapped_column(Integer, comment="車間距離警報回数")
    max_rpm_general: Mapped[int | None] = mapped_column(Integer, comment="エンジン最高回転数:一般")
    max_rpm_highway: Mapped[int | None] = mapped_column(Integer, comment="エンジン最高回転数:高速")
    rpm_over_general_count: Mapped[int | None] = mapped_column(Integer, comment="回転オーバー回数:一般")
    rpm_over_highway_count: Mapped[int | None] = mapped_column(Integer, comment="回転オーバー回数:高速")
    rpm_over_general_loaded_sec: Mapped[int | None] = mapped_column(Integer, comment="回転オーバー時間:実車一般(秒)")
    rpm_over_general_empty_sec: Mapped[int | None] = mapped_column(Integer, comment="回転オーバー時間:空車一般(秒)")
    rpm_over_highway_loaded_sec: Mapped[int | None] = mapped_column(Integer, comment="回転オーバー時間:実車高速(秒)")
    rpm_over_highway_empty_sec: Mapped[int | None] = mapped_column(Integer, comment="回転オーバー時間:空車高速(秒)")
    engine_on_sec: Mapped[int | None] = mapped_column(Integer, comment="エンジンON時間(秒)")
    engine_on_count: Mapped[int | None] = mapped_column(Integer, comment="エンジンON回数")
    brake_count: Mapped[int | None] = mapped_column(Integer, comment="ブレーキ回数")
    start_count: Mapped[int | None] = mapped_column(Integer, comment="発進回数")
    avg_speed_general: Mapped[int | None] = mapped_column(Integer, comment="平均速度:一般(km/h)")
    avg_speed_highway: Mapped[int | None] = mapped_column(Integer, comment="平均速度:高速(km/h)")
    avg_speed_dedicated: Mapped[int | None] = mapped_column(Integer, comment="平均速度:専用道(km/h)")
    ext_ch1_count: Mapped[int | None] = mapped_column(Integer, comment="外部入力CH1回数")
    ext_ch2_count: Mapped[int | None] = mapped_column(Integer, comment="外部入力CH2回数")
    ext_ch3_count: Mapped[int | None] = mapped_column(Integer, comment="外部入力CH3回数")
    ext_ch4_count: Mapped[int | None] = mapped_column(Integer, comment="外部入力CH4回数")
    crawl_sec: Mapped[int | None] = mapped_column(Integer, comment="微速走行時間(秒)")
    steering_sec: Mapped[int | None] = mapped_column(Integer, comment="ハンドル時間(秒)")
    etc_count: Mapped[int | None] = mapped_column(Integer, comment="ETC利用回数")
    etc_cost_yen: Mapped[int | None] = mapped_column(Integer, comment="ETC料金(円)")

    # ── 安全警報 ──
    drowsy_count: Mapped[int | None] = mapped_column(Integer, comment="居眠り警報回数")
    distracted_count: Mapped[int | None] = mapped_column(Integer, comment="脇見警報回数")
    co2_emission: Mapped[float | None] = mapped_column(Float, comment="CO2排出量")

    # ── 残り項目をJSON格納 ──
    extra_fields: Mapped[dict | None] = mapped_column(JSON, comment="CSV残余フィールド")

    # ── タイムスタンプ ──
    imported_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)
    updated_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now)

    # ── Relationships ──
    delivery_details: Mapped[list["DeliveryDetail"]] = relationship(back_populates="trip_report", cascade="all, delete-orphan")
    fuel_records: Mapped[list["FuelRecord"]] = relationship(back_populates="trip_report", cascade="all, delete-orphan")
    toll_records: Mapped[list["TollRecord"]] = relationship(back_populates="trip_report", cascade="all, delete-orphan")
    events: Mapped[list["TripEvent"]] = relationship(back_populates="trip_report", cascade="all, delete-orphan")
    timeseries: Mapped[list["TripTimeseries"]] = relationship(back_populates="trip_report", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_trip_reports_date_driver", "operation_date", "driver_code"),
        Index("ix_trip_reports_date_vehicle", "operation_date", "vehicle_code"),
        Index("ix_trip_reports_office_date", "driver_office_code", "operation_date"),
    )


class DeliveryDetail(Base):
    """配送明細 — 1運行内の各停車地点。"""
    __tablename__ = "delivery_details"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    report_number: Mapped[str] = mapped_column(String(24), ForeignKey("trip_reports.report_number"), index=True, comment="日報番号")
    detail_number: Mapped[int | None] = mapped_column(Integer, comment="明細行番号")
    work_type: Mapped[str | None] = mapped_column(String(20), comment="着地作業")
    arrival_datetime: Mapped[datetime | None] = mapped_column(DateTime, comment="着日時")
    scheduled_datetime: Mapped[datetime | None] = mapped_column(DateTime, comment="着予定日時")
    departure_datetime: Mapped[datetime | None] = mapped_column(DateTime, comment="発日時")
    work_time_sec: Mapped[int | None] = mapped_column(Integer, comment="作業時間(秒)")
    address: Mapped[str | None] = mapped_column(String(200), comment="住所")
    destination_code: Mapped[str | None] = mapped_column(String(16), index=True, comment="集配先コード")
    destination_name: Mapped[str | None] = mapped_column(String(100), comment="集配先名")
    shipper_code: Mapped[str | None] = mapped_column(String(16), index=True, comment="荷主コード")
    shipper_name: Mapped[str | None] = mapped_column(String(100), comment="荷主名")
    gps_lat: Mapped[int | None] = mapped_column(Integer, comment="GPS緯度(×10^5)")
    gps_lon: Mapped[int | None] = mapped_column(Integer, comment="GPS経度(×10^5)")
    travel_time_sec: Mapped[int | None] = mapped_column(Integer, comment="走行時間(秒)")
    idle_time_sec: Mapped[int | None] = mapped_column(Integer, comment="アイドリング時間(秒)")
    stop_time_sec: Mapped[int | None] = mapped_column(Integer, comment="停止時間(秒)")
    travel_distance_m: Mapped[int | None] = mapped_column(Integer, comment="走行距離(m)")
    loaded_distance_m: Mapped[int | None] = mapped_column(Integer, comment="実車距離(m)")
    empty_distance_m: Mapped[int | None] = mapped_column(Integer, comment="空車距離(m)")
    cumulative_distance_m: Mapped[int | None] = mapped_column(Integer, comment="累積走行距離(m)")
    loading_status_code: Mapped[str | None] = mapped_column(String(8), comment="積載状況コード")
    total_quantity: Mapped[float | None] = mapped_column(Float, comment="全数量")
    total_weight: Mapped[float | None] = mapped_column(Float, comment="全重量")
    extra_fields: Mapped[dict | None] = mapped_column(JSON, comment="CSV残余フィールド")
    imported_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)

    trip_report: Mapped["TripReport"] = relationship(back_populates="delivery_details")

    __table_args__ = (
        Index("ix_dd_shipper_report", "shipper_code", "report_number"),
    )


class FuelRecord(Base):
    """給油明細。"""
    __tablename__ = "fuel_records"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    report_number: Mapped[str] = mapped_column(String(24), ForeignKey("trip_reports.report_number"), index=True, comment="日報番号")
    station_name: Mapped[str | None] = mapped_column(String(100), comment="給油スタンド")
    fuel_type: Mapped[str | None] = mapped_column(String(20), comment="給油区分")
    amount_l: Mapped[float | None] = mapped_column(Float, comment="給油量(L)")
    cost_yen: Mapped[int | None] = mapped_column(Integer, comment="給油金額(円)")
    fill_date: Mapped[date | None] = mapped_column(Date, comment="給油日付")
    fill_time: Mapped[str | None] = mapped_column(String(5), comment="給油時間(HH:mm)")
    imported_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)

    trip_report: Mapped["TripReport"] = relationship(back_populates="fuel_records")


class TollRecord(Base):
    """通行料明細。"""
    __tablename__ = "toll_records"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    report_number: Mapped[str] = mapped_column(String(24), ForeignKey("trip_reports.report_number"), index=True, comment="日報番号")
    entry_ic: Mapped[str | None] = mapped_column(String(100), comment="入口IC名称")
    exit_ic: Mapped[str | None] = mapped_column(String(100), comment="出口IC名称")
    cost_yen: Mapped[int | None] = mapped_column(Integer, comment="金額(円)")
    toll_type: Mapped[str | None] = mapped_column(String(20), comment="通行料区分")
    imported_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)

    trip_report: Mapped["TripReport"] = relationship(back_populates="toll_records")


class TripEvent(Base):
    """イベントデータ — 急加減速・速度超過等。"""
    __tablename__ = "trip_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    report_number: Mapped[str] = mapped_column(String(24), ForeignKey("trip_reports.report_number"), index=True, comment="日報番号")
    event_type: Mapped[str | None] = mapped_column(String(30), index=True, comment="イベント種別")
    event_datetime: Mapped[datetime | None] = mapped_column(DateTime, comment="発生日時")
    speed_kmh: Mapped[int | None] = mapped_column(Integer, comment="速度(km/h)")
    engine_rpm: Mapped[int | None] = mapped_column(Integer, comment="エンジン回転数")
    gps_lat: Mapped[int | None] = mapped_column(Integer, comment="GPS緯度")
    gps_lon: Mapped[int | None] = mapped_column(Integer, comment="GPS経度")
    g_value_x: Mapped[float | None] = mapped_column(Float, comment="G値X")
    g_value_y: Mapped[float | None] = mapped_column(Float, comment="G値Y")
    extra_fields: Mapped[dict | None] = mapped_column(JSON)
    imported_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)

    trip_report: Mapped["TripReport"] = relationship(back_populates="events")


class TripTimeseries(Base):
    """1分時系列データ。"""
    __tablename__ = "trip_timeseries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    report_number: Mapped[str] = mapped_column(String(24), ForeignKey("trip_reports.report_number"), index=True, comment="日報番号")
    recorded_at: Mapped[datetime | None] = mapped_column(DateTime, comment="記録日時")
    speed_kmh: Mapped[int | None] = mapped_column(Integer, comment="速度(km/h)")
    engine_rpm: Mapped[int | None] = mapped_column(Integer, comment="エンジン回転数")
    gps_lat: Mapped[int | None] = mapped_column(Integer, comment="GPS緯度")
    gps_lon: Mapped[int | None] = mapped_column(Integer, comment="GPS経度")
    altitude_m: Mapped[int | None] = mapped_column(Integer, comment="標高(m)")
    extra_fields: Mapped[dict | None] = mapped_column(JSON)

    trip_report: Mapped["TripReport"] = relationship(back_populates="timeseries")

    __table_args__ = (
        Index("ix_ts_report_time", "report_number", "recorded_at"),
    )
