"""Fuel input models — manual entry and CSV import for companies without gas data."""
from datetime import date, datetime

from sqlalchemy import Date, DateTime, Float, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class MonthlyFuelInput(Base):
    """月次給油入力 — 車両ごとの月間給油実績。

    燃料カード明細やスタンド伝票から手入力 or CSVインポート。
    """
    __tablename__ = "monthly_fuel_inputs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vehicle_code: Mapped[str] = mapped_column(String(8), index=True, comment="車両コード")
    vehicle_name: Mapped[str | None] = mapped_column(String(50), comment="車両名")
    year_month: Mapped[str] = mapped_column(String(7), index=True, comment="YYYY-MM")
    fuel_amount_l: Mapped[float] = mapped_column(Float, comment="給油量合計(L)")
    fuel_cost_yen: Mapped[int | None] = mapped_column(Integer, comment="給油金額合計(円)")
    fuel_unit_price: Mapped[float | None] = mapped_column(Float, comment="平均単価(円/L)")
    source: Mapped[str | None] = mapped_column(String(20), default="manual", comment="manual/csv_import")
    note: Mapped[str | None] = mapped_column(Text, comment="備考")
    created_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)
    updated_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now)


class DailyFuelInput(Base):
    """日次給油入力 — 個別の給油イベント。より詳細な入力用。"""
    __tablename__ = "daily_fuel_inputs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vehicle_code: Mapped[str] = mapped_column(String(8), index=True, comment="車両コード")
    vehicle_name: Mapped[str | None] = mapped_column(String(50), comment="車両名")
    fill_date: Mapped[date] = mapped_column(Date, index=True, comment="給油日")
    odometer_km: Mapped[float | None] = mapped_column(Float, comment="オドメーター(km)")
    fuel_amount_l: Mapped[float] = mapped_column(Float, comment="給油量(L)")
    fuel_cost_yen: Mapped[int | None] = mapped_column(Integer, comment="給油金額(円)")
    fuel_unit_price: Mapped[float | None] = mapped_column(Float, comment="単価(円/L)")
    station_name: Mapped[str | None] = mapped_column(String(100), comment="給油スタンド")
    is_full_tank: Mapped[int] = mapped_column(Integer, default=1, comment="満タン給油=1")
    source: Mapped[str | None] = mapped_column(String(20), default="manual", comment="manual/csv_import")
    note: Mapped[str | None] = mapped_column(Text, comment="備考")
    created_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)
