"""All SQLAlchemy models — import here for Alembic auto-detection."""
from app.models.csv_import import (
    TripReport,
    DeliveryDetail,
    FuelRecord,
    TollRecord,
    TripEvent,
    TripTimeseries,
)
from app.models.master import (
    Driver,
    Vehicle,
    VehicleType,
    Organization,
    Shipper,
    Destination,
    Route,
    LoadingStatus,
    FuelStation,
)
from app.models.analysis import (
    BaselineGroup,
    TripAnalysis,
    DailySummary,
    MonthlySummary,
)
from app.models.operations import (
    InterventionCase,
    CaseAction,
    ShipperWaitSummary,
    VehicleAnomaly,
    DriverCoachingCard,
    ImprovementGoal,
)
from app.models.system import (
    User,
    SystemSetting,
    ImportLog,
    CsvFileRegistry,
)
from app.models.fuel_input import (
    MonthlyFuelInput,
    DailyFuelInput,
)
from app.models.fuel_invoice import FuelInvoice, FuelInvoiceVehicleMapping

__all__ = [
    "TripReport", "DeliveryDetail", "FuelRecord", "TollRecord",
    "TripEvent", "TripTimeseries",
    "Driver", "Vehicle", "VehicleType", "Organization",
    "Shipper", "Destination", "Route", "LoadingStatus", "FuelStation",
    "BaselineGroup", "TripAnalysis", "DailySummary", "MonthlySummary",
    "InterventionCase", "CaseAction", "ShipperWaitSummary",
    "VehicleAnomaly", "DriverCoachingCard", "ImprovementGoal",
    "User", "SystemSetting", "ImportLog", "CsvFileRegistry",
    "MonthlyFuelInput", "DailyFuelInput",
    "FuelInvoice", "FuelInvoiceVehicleMapping",
]
