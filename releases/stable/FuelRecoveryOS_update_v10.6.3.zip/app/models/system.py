"""Group E: System tables — users, settings, import tracking."""
from datetime import datetime

from sqlalchemy import DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class User(Base):
    """システムユーザー。"""
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    username: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(50))
    role: Mapped[str] = mapped_column(String(20), comment="admin/manager/driver")
    office_code: Mapped[str | None] = mapped_column(String(8), comment="所属事業所")
    hashed_password: Mapped[str] = mapped_column(String(128))
    is_active: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class SystemSetting(Base):
    """システム設定 — key-value。"""
    __tablename__ = "system_settings"

    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[str] = mapped_column(Text)
    description: Mapped[str | None] = mapped_column(String(200))
    updated_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now)


class ImportLog(Base):
    """CSV取込ログ。"""
    __tablename__ = "import_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    pipeline: Mapped[str] = mapped_column(String(1), index=True, comment="A/B/C/D")
    filename: Mapped[str] = mapped_column(String(300))
    file_type: Mapped[str | None] = mapped_column(String(20), comment="report/detail/fuel/toll/event/timeseries/master")
    status: Mapped[str] = mapped_column(String(20), index=True, comment="success/error/warning")
    records_imported: Mapped[int] = mapped_column(Integer, default=0)
    records_updated: Mapped[int] = mapped_column(Integer, default=0)
    error_detail: Mapped[str | None] = mapped_column(Text)
    imported_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class CsvFileRegistry(Base):
    """CSVファイル管理台帳 — 二重取込防止。"""
    __tablename__ = "csv_file_registry"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    filepath: Mapped[str] = mapped_column(String(500), unique=True)
    file_hash: Mapped[str | None] = mapped_column(String(64), comment="SHA-256")
    file_size: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), index=True, comment="pending/processing/done/error")
    report_number: Mapped[int | None] = mapped_column(Integer, comment="抽出した日報番号")
    processed_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
