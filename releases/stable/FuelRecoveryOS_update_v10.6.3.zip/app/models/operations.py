"""Group D: Operations tables — case management, coaching, anomaly detection."""
from datetime import date, datetime

from sqlalchemy import (
    BigInteger, Date, DateTime, Float, ForeignKey, Index, Integer, JSON, String, Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class InterventionCase(Base):
    """介入案件 — システムの心臓部。運行管理者のタスクボード。"""
    __tablename__ = "intervention_cases"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    case_date: Mapped[date] = mapped_column(Date, index=True, comment="案件発生日")
    priority: Mapped[str] = mapped_column(String(10), index=True, comment="high/mid/low")
    report_number: Mapped[str | None] = mapped_column(String(24), comment="関連日報番号")
    vehicle_code: Mapped[str | None] = mapped_column(String(8), comment="車番")
    driver_code: Mapped[str | None] = mapped_column(String(8), comment="乗務員コード")
    route_name: Mapped[str | None] = mapped_column(String(100), comment="路線/便名")
    estimated_loss_l: Mapped[float | None] = mapped_column(Float, comment="推定損失(L)")
    estimated_loss_yen: Mapped[int | None] = mapped_column(Integer, comment="推定損失(円)")
    root_cause_layer: Mapped[str | None] = mapped_column(String(10), comment="driving/dispatch/shipper/vehicle")
    root_cause_detail: Mapped[str | None] = mapped_column(Text, comment="原因詳細")
    recommended_action: Mapped[str | None] = mapped_column(Text, comment="推奨アクション")
    assignee: Mapped[str | None] = mapped_column(String(50), comment="担当者")
    deadline: Mapped[date | None] = mapped_column(Date, comment="期限")
    status: Mapped[str] = mapped_column(String(20), default="open", index=True, comment="open/in_progress/resolved/needs_review")
    recurrence_count: Mapped[int] = mapped_column(Integer, default=1, comment="繰返し発生回数")
    created_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)
    updated_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now)

    actions: Mapped[list["CaseAction"]] = relationship(back_populates="case", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_case_status_priority", "status", "priority"),
        Index("ix_case_date_status", "case_date", "status"),
    )


class CaseAction(Base):
    """案件アクション履歴。"""
    __tablename__ = "case_actions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    case_id: Mapped[int] = mapped_column(Integer, ForeignKey("intervention_cases.id"), index=True, comment="案件ID")
    action_datetime: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    action_type: Mapped[str] = mapped_column(String(20), comment="status_change/note/assignment")
    old_value: Mapped[str | None] = mapped_column(String(100))
    new_value: Mapped[str | None] = mapped_column(String(100))
    note: Mapped[str | None] = mapped_column(Text)
    actor: Mapped[str | None] = mapped_column(String(50), comment="操作者")

    case: Mapped["InterventionCase"] = relationship(back_populates="actions")


class ShipperWaitSummary(Base):
    """荷主別待機集計 — 荷主交渉エビデンスの基礎データ。"""
    __tablename__ = "shipper_wait_summaries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    shipper_code: Mapped[str] = mapped_column(String(16), index=True, comment="荷主コード")
    shipper_name: Mapped[str | None] = mapped_column(String(100))
    month: Mapped[str] = mapped_column(String(7), index=True, comment="YYYY-MM")
    total_trips: Mapped[int] = mapped_column(Integer, default=0, comment="総便数")
    trips_with_wait: Mapped[int] = mapped_column(Integer, default=0, comment="待機発生便数")
    wait_rate_pct: Mapped[float | None] = mapped_column(Float, comment="待機発生率(%)")
    avg_wait_min: Mapped[float | None] = mapped_column(Float, comment="平均待機時間(分)")
    max_wait_min: Mapped[float | None] = mapped_column(Float, comment="最大待機時間(分)")
    total_wait_min: Mapped[float | None] = mapped_column(Float, comment="合計待機時間(分)")
    fuel_loss_l: Mapped[float] = mapped_column(Float, default=0.0, comment="燃料損失(L)")
    fuel_loss_yen: Mapped[int] = mapped_column(Integer, default=0, comment="燃料損失(円)")
    labor_cost_yen: Mapped[int] = mapped_column(Integer, default=0, comment="拘束コスト(円)")
    total_impact_yen: Mapped[int] = mapped_column(Integer, default=0, comment="合計影響額(円)")
    day_of_week_distribution: Mapped[dict | None] = mapped_column(JSON, comment="曜日別分布")
    hour_distribution: Mapped[dict | None] = mapped_column(JSON, comment="時間帯別分布")
    computed_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class VehicleAnomaly(Base):
    """車両異常検知。"""
    __tablename__ = "vehicle_anomalies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vehicle_code: Mapped[str] = mapped_column(String(8), index=True, comment="車両コード")
    detected_date: Mapped[date] = mapped_column(Date, index=True, comment="検知日")
    deviation_pct: Mapped[float | None] = mapped_column(Float, comment="同型平均との偏差(%)")
    trend: Mapped[str | None] = mapped_column(String(20), comment="worsening/sudden/gradual")
    weeks_declining: Mapped[int | None] = mapped_column(Integer, comment="連続悪化週数")
    suspected_cause: Mapped[str | None] = mapped_column(Text, comment="推定原因")
    status: Mapped[str] = mapped_column(String(20), default="detected", comment="detected/inspecting/resolved/dismissed")
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime)
    resolution_note: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)


class DriverCoachingCard(Base):
    """ドライバー面談カード — 月次。"""
    __tablename__ = "driver_coaching_cards"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    driver_code: Mapped[str] = mapped_column(String(8), index=True, comment="乗務員コード")
    month: Mapped[str] = mapped_column(String(7), index=True, comment="YYYY-MM")
    actual_efficiency: Mapped[float | None] = mapped_column(Float, comment="今月実燃費")
    prev_month_efficiency: Mapped[float | None] = mapped_column(Float, comment="先月実燃費")
    peer_avg_efficiency: Mapped[float | None] = mapped_column(Float, comment="同条件平均燃費")
    avoidable_loss_l: Mapped[float | None] = mapped_column(Float, comment="回避可能損失(L)")
    idle_rate_pct: Mapped[float | None] = mapped_column(Float, comment="アイドリング率(%)")
    improvement_rank: Mapped[int | None] = mapped_column(Integer, comment="改善ランキング順位")
    good_points: Mapped[list | None] = mapped_column(JSON, comment="良かった点")
    improvement_points: Mapped[list | None] = mapped_column(JSON, comment="改善ポイント")
    unavoidable_notes: Mapped[list | None] = mapped_column(JSON, comment="不可避事情")
    interview_date: Mapped[date | None] = mapped_column(Date, comment="面談日")
    interviewer: Mapped[str | None] = mapped_column(String(50), comment="面談者")
    created_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)

    goals: Mapped[list["ImprovementGoal"]] = relationship(back_populates="coaching_card", cascade="all, delete-orphan")


class ImprovementGoal(Base):
    """改善目標。"""
    __tablename__ = "improvement_goals"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    coaching_card_id: Mapped[int] = mapped_column(Integer, ForeignKey("driver_coaching_cards.id"), index=True, comment="面談カードID")
    goal_text: Mapped[str] = mapped_column(Text, comment="目標テキスト")
    target_metric: Mapped[str | None] = mapped_column(String(50), comment="対象指標")
    target_value: Mapped[float | None] = mapped_column(Float, comment="目標値")
    status: Mapped[str] = mapped_column(String(20), default="pending", comment="pending/achieved/missed")
    achieved_at: Mapped[datetime | None] = mapped_column(DateTime)

    coaching_card: Mapped["DriverCoachingCard"] = relationship(back_populates="goals")
