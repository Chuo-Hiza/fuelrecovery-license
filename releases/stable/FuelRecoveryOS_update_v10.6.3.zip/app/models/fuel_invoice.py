"""給油請求書明細 — ベンダー横断の正規化テーブル。

各ベンダー(燃料カード会社・SS等)の請求書フォーマットは異なるが、
本テーブルは共通スキーマで保存し、source_format でどのフォーマット由来か
識別する。新フォーマット対応時は app/importers/fuel_invoice/ にアダプタを
追加し、共通スキーマへ正規化して投入する。
"""
from datetime import date, datetime

from sqlalchemy import (
    Date, DateTime, Float, Index, Integer, JSON, String, UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class FuelInvoice(Base):
    """請求書明細 1 行 = 1 レコード。"""
    __tablename__ = "fuel_invoices"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # ── ソース情報 ──
    source_format: Mapped[str] = mapped_column(String(30), index=True,
        comment="フォーマット識別子(例: kawamura)")
    source_filename: Mapped[str | None] = mapped_column(String(200), comment="元ファイル名")

    # ── 顧客 ──
    customer_code: Mapped[str | None] = mapped_column(String(40),
        comment="顧客コード(複合の場合は '-' 連結)")
    customer_name: Mapped[str | None] = mapped_column(String(100))

    # ── 日付 ──
    billing_date: Mapped[date | None] = mapped_column(Date, index=True, comment="請求年月日")
    transaction_date: Mapped[date | None] = mapped_column(Date, index=True, comment="取引年月日")

    # ── 車両 ──
    vehicle_no: Mapped[str | None] = mapped_column(String(16), index=True,
        comment="車番(末尾4桁等、フォーマット依存)")

    # ── 伝票 ──
    slip_number: Mapped[str | None] = mapped_column(String(32), comment="伝票番号")
    line_number: Mapped[int | None] = mapped_column(Integer, comment="行番号")

    # ── 商品 ──
    product_code: Mapped[str | None] = mapped_column(String(32), comment="商品コード")
    product_name: Mapped[str | None] = mapped_column(String(100), comment="商品名")
    product_category: Mapped[str | None] = mapped_column(String(20), index=True,
        comment="diesel / gasoline / additive / oil / other")

    # ── 数量・金額 ──
    quantity: Mapped[float | None] = mapped_column(Float, comment="数量")
    unit_price: Mapped[float | None] = mapped_column(Float, comment="単価")
    amount_excl_tax: Mapped[int | None] = mapped_column(Integer, comment="金額(税抜き)")
    consumption_tax: Mapped[int | None] = mapped_column(Integer, comment="消費税")
    diesel_tax: Mapped[int | None] = mapped_column(Integer, comment="軽油引取税")
    amount_total: Mapped[int | None] = mapped_column(Integer, comment="金額(合計)")

    # ── スタンド ──
    station_name: Mapped[str | None] = mapped_column(String(100), comment="スタンド名")

    # ── 監査用 raw データ ──
    raw_row: Mapped[dict | None] = mapped_column(JSON, comment="元 CSV の生データ(オブジェクト)")
    imported_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.now)

    __table_args__ = (
        Index("ix_fi_vehicle_tx", "vehicle_no", "transaction_date"),
        Index("ix_fi_billing", "billing_date"),
        # 同一フォーマットで(請求年月日+車番+取引日+伝票+行+商品)が完全一致するものは重複
        UniqueConstraint(
            "source_format", "billing_date", "vehicle_no",
            "transaction_date", "slip_number", "line_number", "product_code",
            name="uq_fuel_invoice_unique",
        ),
    )


class FuelInvoiceVehicleMapping(Base):
    """請求書の車番(4桁等) → システム上の車両コード のマッピング。

    請求書ベンダー側の車番表記がシステムの車両コードと異なる場合、
    本テーブルで紐付け管理する。vehicle_code が NULL の場合は
    「紐付け対象外(orphan)」として保持(非表示・同期スキップ)。
    """
    __tablename__ = "fuel_invoice_vehicle_mappings"

    invoice_vehicle_no: Mapped[str] = mapped_column(String(16), primary_key=True,
        comment="請求書側の車番表記")
    vehicle_code: Mapped[str | None] = mapped_column(String(8), index=True,
        comment="システム車両コード(NULL=未紐付け/対象外)")
    vehicle_name: Mapped[str | None] = mapped_column(String(50),
        comment="登録時点の車両名(参考表示用)")
    note: Mapped[str | None] = mapped_column(String(200), comment="備考")
    updated_at: Mapped[datetime | None] = mapped_column(DateTime,
        default=datetime.now, onupdate=datetime.now)
