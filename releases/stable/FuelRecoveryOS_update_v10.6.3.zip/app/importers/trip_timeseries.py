"""1分時系列データ CSV インポーター (_tc ファイル)。

列仕様 (ESTRA-Web2操作マニュアル第14版 p.237 準拠):
  ヘッダーレコード（1行目、位置固定）:
    col 0: 日報番号
    col 1: 運行日
    col 2: 乗務員コード
    col 3: 車両コード
    col 4: 乗務員営業所コード
    col 5: 運行開始日時
    col 6: 運行開始累積走行距離(m)
    col 7: 運行開始速度(km/h)
    col 8: 運行開始回転数(rpm)
    col 9: 運行開始緯度
    col10: 運行開始経度
    col11: 運行開始進行方向
    col12: 運行開始外部Ch状態
    col13-16: 運行開始アナログCh1-4
    col17: 運行終了日時 ... (以降、終了時情報)

  データレコード（2行目以降、位置固定）:
    col 0: 日付 (yyyy/MM/dd)
    col 1: 時刻 (hh:mm:ss)
    col 2: 最高速度 (km/h)
    col 3: 最低速度 (km/h)
    col 4: 最高回転数 (rpm)
    col 5: 最低回転数 (rpm)
    col 6: 距離 (m) - 1分間の距離
    col 7: 緯度 (小数点形式、世界測地系)
    col 8: 経度 (小数点形式、世界測地系)
    col 9: 進行方向 (0-360度)
    col10: 外部ch状態
    col11-14: アナログch1-4
"""
import csv
import io
import logging
from datetime import datetime
from pathlib import Path

from sqlalchemy import text
from sqlalchemy.orm import Session

from app.models.csv_import import TripTimeseries

logger = logging.getLogger(__name__)

# 位置インデックス定数（データレコード用）
_COL_DATE = 0
_COL_TIME = 1
_COL_MAX_SPEED = 2
_COL_MIN_SPEED = 3
_COL_MAX_RPM = 4
_COL_MIN_RPM = 5
_COL_DISTANCE_M = 6
_COL_LAT = 7
_COL_LON = 8
_COL_HEADING = 9
_COL_EXT_CH = 10


def _parse_int(val: str) -> int | None:
    if not val or not val.strip():
        return None
    try:
        return int(val.strip())
    except (ValueError, TypeError):
        return None


def _parse_float(val: str) -> float | None:
    if not val or not val.strip():
        return None
    try:
        return float(val.strip())
    except (ValueError, TypeError):
        return None


def _parse_gps(val: str) -> int | None:
    """GPS座標(小数)を整数×10^5に変換。例: 35.6812831 → 3568128"""
    f = _parse_float(val)
    if f is None:
        return None
    return int(round(f * 100000))


def import_trip_timeseries(filepath: Path, db: Session) -> dict:
    """1分時系列CSVを読み込み TripTimeseries テーブルに投入する。

    Returns:
        dict with keys: status, imported, updated, errors
    """
    try:
        raw = filepath.read_bytes()
        text_data = raw.decode("cp932", errors="replace")
    except Exception as e:
        return {"status": "error", "detail": str(e)}

    lines = text_data.splitlines()
    if not lines:
        return {"status": "error", "detail": "Empty file"}

    # ── ヘッダー行からメタ情報を取得 ──────────────────────────────────────
    header_cols = list(csv.reader([lines[0]]))[0]
    if not header_cols:
        return {"status": "error", "detail": "Invalid header row"}

    report_number = header_cols[0].strip() if header_cols[0].strip() else None
    if not report_number:
        return {"status": "error", "detail": "Missing report_number in header"}

    # ── 既存レコード削除（再インポートは洗い替え方式）────────────────────
    existing_count = db.query(TripTimeseries).filter_by(report_number=report_number).count()
    if existing_count > 0:
        db.query(TripTimeseries).filter_by(report_number=report_number).delete()
        db.flush()

    # ── データ行を解析 ────────────────────────────────────────────────────
    imported = 0
    errors = []
    batch: list[TripTimeseries] = []
    BATCH_SIZE = 500

    for line_no, line in enumerate(lines[1:], start=2):
        line = line.strip()
        if not line:
            continue

        cols = list(csv.reader([line]))[0]
        if len(cols) < 7:
            errors.append(f"Line {line_no}: too few columns ({len(cols)})")
            continue

        def col(idx: int) -> str:
            return cols[idx].strip() if idx < len(cols) else ""

        # 記録日時の組立
        date_str = col(_COL_DATE)
        time_str = col(_COL_TIME)
        if not date_str or not time_str:
            errors.append(f"Line {line_no}: missing date/time")
            continue

        try:
            recorded_at = datetime.strptime(f"{date_str} {time_str}", "%Y/%m/%d %H:%M:%S")
        except ValueError:
            try:
                recorded_at = datetime.strptime(f"{date_str} {time_str}", "%Y/%m/%d %H:%M")
            except ValueError:
                errors.append(f"Line {line_no}: invalid datetime '{date_str} {time_str}'")
                continue

        max_speed = _parse_int(col(_COL_MAX_SPEED))
        min_speed = _parse_int(col(_COL_MIN_SPEED))
        max_rpm = _parse_int(col(_COL_MAX_RPM))
        min_rpm = _parse_int(col(_COL_MIN_RPM))
        distance_m = _parse_int(col(_COL_DISTANCE_M))
        gps_lat = _parse_gps(col(_COL_LAT))
        gps_lon = _parse_gps(col(_COL_LON))
        heading = _parse_int(col(_COL_HEADING))

        # extra_fields: 最低速度・最低回転数・距離・進行方向・外部ch等
        extra: dict = {}
        if min_speed is not None:
            extra["min_speed_kmh"] = min_speed
        if min_rpm is not None:
            extra["min_rpm"] = min_rpm
        if distance_m is not None:
            extra["distance_m"] = distance_m
        if heading is not None:
            extra["heading_deg"] = heading
        ext_ch = col(_COL_EXT_CH)
        if ext_ch:
            extra["ext_ch"] = ext_ch

        record = TripTimeseries(
            report_number=report_number,
            recorded_at=recorded_at,
            speed_kmh=max_speed,
            engine_rpm=max_rpm,
            gps_lat=gps_lat,
            gps_lon=gps_lon,
            altitude_m=None,  # _tc CSV に標高情報なし（進行方向は extra_fields へ）
            extra_fields=extra if extra else None,
        )
        batch.append(record)
        imported += 1

        if len(batch) >= BATCH_SIZE:
            db.bulk_save_objects(batch)
            db.flush()
            batch.clear()

    if batch:
        db.bulk_save_objects(batch)

    db.commit()

    return {
        "status": "success",
        "imported": imported,
        "updated": existing_count,  # 洗い替え前の件数
        "errors": errors,
        "report_number": report_number,
    }
