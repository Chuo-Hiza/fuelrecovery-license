"""通行料明細 CSV インポーター (_etc ファイル)。"""
import logging
from pathlib import Path

from sqlalchemy.orm import Session

from app.importers.base import read_csv_shift_jis, parse_int
from app.models.csv_import import TollRecord

logger = logging.getLogger(__name__)


def import_toll_record(filepath: Path, db: Session) -> dict:
    """_etc.csv を読み込み TollRecord テーブルに投入する。

    Returns:
        dict with keys: status, imported, updated, errors
    """
    rows = read_csv_shift_jis(filepath)
    if not rows:
        return {"status": "success", "imported": 0, "updated": 0, "errors": []}

    first_rn = (rows[0].get("日報番号") or "").strip()
    if not first_rn:
        return {"status": "error", "imported": 0, "updated": 0,
                "errors": ["Missing 日報番号 in first row"]}

    # 洗い替え
    existing = db.query(TollRecord).filter_by(report_number=first_rn).count()
    if existing > 0:
        db.query(TollRecord).filter_by(report_number=first_rn).delete()
        db.flush()

    imported = 0
    errors = []

    for i, row in enumerate(rows, start=2):
        report_number = (row.get("日報番号") or "").strip() or None
        if not report_number:
            continue

        try:
            cost = parse_int(row.get("金額"))
            if not cost:
                continue

            record = TollRecord(
                report_number=report_number,
                entry_ic=row.get("入口IC", "").strip() or None,
                exit_ic=row.get("出口IC", "").strip() or None,
                cost_yen=cost,
                toll_type=row.get("区分名", "").strip() or None,
            )
            db.add(record)
            imported += 1
        except Exception as e:
            errors.append(f"Row {i}: {e}")

    db.commit()
    return {
        "status": "success",
        "imported": imported,
        "updated": existing,
        "errors": errors,
    }
