"""Trip report CSV importer — 日報CSV取込。
Column names verified against real Estra-WEB2 CSV (2026-01 data).
"""
from pathlib import Path

from sqlalchemy.orm import Session

from app.importers.base import (
    read_csv_shift_jis, parse_int, parse_float, parse_km_to_m,
    parse_time_to_sec, parse_datetime, parse_date, parse_meter_to_m,
)
from app.models.csv_import import TripReport
from app.models.master import Vehicle

# Mapping: CSV column name (Japanese) → (TripReport field, converter)
# Verified against real CSV from 中央矢崎サービス 2026年1月-3月
FIELD_MAP = {
    # ── 基本情報 (No.1-22) ──
    "日報番号": ("report_number", str),
    "運行日": ("operation_date", parse_date),
    "乗務員コード": ("driver_code", str),
    "乗務員": ("driver_name", str),
    "車両コード": ("vehicle_code", str),
    "車両": ("vehicle_name", str),
    "乗務員：事業所コード": ("driver_office_code", str),
    "乗務員：事業所": ("driver_office_name", str),
    "乗務員：組織コード": ("driver_org_code", str),
    "乗務員：組織": ("driver_org_name", str),
    "車両：事業所コード": ("vehicle_office_code", str),
    "車両：事業所": ("vehicle_office_name", str),
    "車両：組織コード": ("vehicle_org_code", str),
    "車両：組織": ("vehicle_org_name", str),
    "設定グループコード": ("setting_group_code", parse_int),
    "設定グループ": ("setting_group_name", str),
    "2マン日報番号": ("two_man_report_number", parse_int),
    "天候": ("weather", str),
    "コースコード": ("course_code", str),
    "コース名称": ("course_name", str),
    # ── 出庫/入庫 (No.24-31) ──
    "出庫日時": ("departure_datetime", parse_datetime),
    "入庫日時": ("arrival_datetime", parse_datetime),
    "出庫メータ": ("departure_meter", parse_meter_to_m),
    "入庫メータ": ("arrival_meter", parse_meter_to_m),
    # ── 走行距離 (No.32-44) ──
    "走行距離": ("distance_m", parse_km_to_m),
    "一般・実車走行距離": ("general_loaded_m", parse_km_to_m),
    "一般・空車走行距離": ("general_empty_m", parse_km_to_m),
    "高速・実車走行距離": ("highway_loaded_m", parse_km_to_m),
    "高速・空車走行距離": ("highway_empty_m", parse_km_to_m),
    "専用道・実車走行距離": ("dedicated_loaded_m", parse_km_to_m),
    "専用道・空車走行距離": ("dedicated_empty_m", parse_km_to_m),
    # ── 時間 (No.37-48) ──
    "空車時間": ("empty_time_sec", parse_time_to_sec),
    "実車時間": ("loaded_time_sec", parse_time_to_sec),
    "空車走行時間": ("empty_driving_sec", parse_time_to_sec),
    "実車走行時間": ("loaded_driving_sec", parse_time_to_sec),
    "一般走行時間": ("general_driving_sec", parse_time_to_sec),
    "高速走行時間": ("highway_driving_sec", parse_time_to_sec),
    "専用道走行時間": ("dedicated_driving_sec", parse_time_to_sec),
    "稼働時間": ("working_time_sec", parse_time_to_sec),
    "アイドリング時間": ("idle_time_sec", parse_time_to_sec),
    "停止時間": ("stop_time_sec", parse_time_to_sec),
    # ── 勤務時間 (No.49-71) ──
    "就業時間": ("employment_sec", parse_time_to_sec),
    "残業時間": ("overtime_sec", parse_time_to_sec),
    "深夜時間": ("night_sec", parse_time_to_sec),
    "荷積時間": ("loading_time_sec", parse_time_to_sec),
    "荷卸時間": ("unloading_time_sec", parse_time_to_sec),
    "待機時間": ("waiting_time_sec", parse_time_to_sec),
    "点検時間": ("inspection_sec", parse_time_to_sec),
    "休憩時間": ("break_sec", parse_time_to_sec),
    "休息時間": ("rest_sec", parse_time_to_sec),
    "他3工場時間": ("other_work1_sec", parse_time_to_sec),
    "他4洗車時間": ("other_work2_sec", parse_time_to_sec),
    "PTO/DPR時間": ("pto_dpr_sec", parse_time_to_sec),
    "フェリー時間": ("ferry_sec", parse_time_to_sec),
    # ── 回数 (No.72-81) ──
    "荷積回数": ("loading_count", parse_int),
    "荷卸回数": ("unloading_count", parse_int),
    "PTO/DPR回数": ("pto_dpr_count", parse_int),
    # ── 評価 (No.82-87) — real column names use space ──
    "運転評価 安全ランク": ("safety_rank", str),
    "運転評価 経済ランク": ("economy_rank", str),
    "運転評価 総合ランク": ("overall_rank", str),
    "運転評価 安全評価点": ("safety_score", parse_float),
    "運転評価 経済評価点": ("economy_score", parse_float),
    "運転評価 総合評価点": ("overall_score", parse_float),
    # ── 燃費 (No.94-98) ──
    "燃費対象給油量": ("fuel_amount_l", parse_float),
    "前回給油量メータ値": ("prev_fuel_meter", parse_meter_to_m),
    "今回給油量メータ値": ("curr_fuel_meter", parse_meter_to_m),
    "区間距離": ("fuel_section_m", parse_km_to_m),
    "燃費": ("fuel_efficiency_kml", parse_float),
    # ── 運転イベント (No.99-170) ──
    "通行料合計": ("toll_total_yen", parse_int),
    "連続走行時間": ("max_continuous_sec", parse_time_to_sec),
    "最高速度（空車、一般）": ("max_speed_empty_general", parse_int),
    "最高速度（実車、一般）": ("max_speed_loaded_general", parse_int),
    "最高速度（空車、高速）": ("max_speed_empty_highway", parse_int),
    "最高速度（実車、高速）": ("max_speed_loaded_highway", parse_int),
    "速度オーバー回数（一般）": ("speed_over_general_count", parse_int),
    "速度オーバー回数（高速）": ("speed_over_highway_count", parse_int),
    "速度オーバー回数（専用道）": ("speed_over_dedicated_count", parse_int),
    "速度オーバー時間（一般）": ("speed_over_general_sec", parse_time_to_sec),
    "速度オーバー時間（高速）": ("speed_over_highway_sec", parse_time_to_sec),
    "急加速回数": ("sudden_accel_count", parse_int),
    "急減速回数": ("sudden_decel_count", parse_int),
    "急発進回数": ("sudden_start_count", parse_int),
    "急旋回回数": ("sudden_turn_count", parse_int),
    "車線逸脱警報回数": ("lane_departure_count", parse_int),
    "ふらつき回数": ("sway_count", parse_int),
    "急ブレーキ回数": ("sudden_brake_count", parse_int),
    "車間距離警報回数": ("following_distance_count", parse_int),
    "エンジン最高回転数（一般）[rpm]": ("max_rpm_general", parse_int),
    "エンジン最高回転数（高速）[rpm]": ("max_rpm_highway", parse_int),
    "エンジン回転オーバー回数（一般）": ("rpm_over_general_count", parse_int),
    "エンジン回転オーバー回数（高速）": ("rpm_over_highway_count", parse_int),
    "エンジン回転オーバー時間（実車，一般）": ("rpm_over_general_loaded_sec", parse_time_to_sec),
    "エンジン回転オーバー時間（空車，一般）": ("rpm_over_general_empty_sec", parse_time_to_sec),
    "エンジン回転オーバー時間（実車，高速）": ("rpm_over_highway_loaded_sec", parse_time_to_sec),
    "エンジン回転オーバー時間（空車，高速）": ("rpm_over_highway_empty_sec", parse_time_to_sec),
    "エンジンON時間": ("engine_on_sec", parse_time_to_sec),
    "エンジンON回数": ("engine_on_count", parse_int),
    "ブレーキ回数": ("brake_count", parse_int),
    "発進回数": ("start_count", parse_int),
    "平均速度（一般）[km/h]": ("avg_speed_general", parse_int),
    "平均速度（高速）[km/h]": ("avg_speed_highway", parse_int),
    "平均速度（専用道）[km/h]": ("avg_speed_dedicated", parse_int),
    "外部入力ＣＨ１回数": ("ext_ch1_count", parse_int),
    "外部入力ＣＨ２回数": ("ext_ch2_count", parse_int),
    "外部入力ＣＨ３回数": ("ext_ch3_count", parse_int),
    "外部入力ＣＨ４回数": ("ext_ch4_count", parse_int),
    "0.5秒走行時間": ("crawl_sec", parse_time_to_sec),
    "ハンドル時間": ("steering_sec", parse_time_to_sec),
    "ETC利用回数": ("etc_count", parse_int),
    "ETC利用料金": ("etc_cost_yen", parse_int),
    # ── 安全警報 (No.243-249) ──
    "居眠り警報回数": ("drowsy_count", parse_int),
    "脇見警報回数": ("distracted_count", parse_int),
    "CO2排出量": ("co2_emission", parse_float),
}


def import_trip_report(filepath: Path, db: Session) -> dict:
    """Import a single trip report CSV file.

    Returns: {"status": "success"|"error", "report_number": ..., "detail": ...}
    """
    rows = read_csv_shift_jis(filepath)
    if not rows:
        return {"status": "error", "detail": "Empty CSV file"}

    imported = 0
    updated = 0
    errors = []
    # 行毎に見つかった車両を集約し、最後にマスタへ反映する。
    # key=code, value=(name, office_code)
    seen_vehicles: dict[str, tuple[str | None, str | None]] = {}

    for row in rows:
        mapped = {}
        extra = {}

        for csv_col, csv_val in row.items():
            if csv_col in FIELD_MAP:
                field_name, converter = FIELD_MAP[csv_col]
                try:
                    if converter is str:
                        mapped[field_name] = csv_val.strip() if csv_val else None
                    else:
                        mapped[field_name] = converter(csv_val)
                except Exception as e:
                    errors.append(f"Field {csv_col}: {e}")
            else:
                if csv_val and csv_val.strip() and csv_val.strip() != "-":
                    extra[csv_col] = csv_val.strip()

        # Composite datetime fields (separate date + time columns)
        work_start = parse_datetime(row.get("始業日付"), row.get("始業時刻"))
        if work_start:
            mapped["work_start_datetime"] = work_start
        work_end = parse_datetime(row.get("終業日付"), row.get("終業時刻"))
        if work_end:
            mapped["work_end_datetime"] = work_end

        report_number = mapped.get("report_number")
        if not report_number:
            errors.append("Missing report_number")
            continue

        mapped["extra_fields"] = extra if extra else None

        existing = db.get(TripReport, report_number)
        if existing:
            for k, v in mapped.items():
                if k != "report_number":
                    setattr(existing, k, v)
            updated += 1
        else:
            trip = TripReport(**mapped)
            db.add(trip)
            imported += 1

        vc = mapped.get("vehicle_code")
        if vc:
            seen_vehicles[vc] = (
                mapped.get("vehicle_name"),
                mapped.get("vehicle_office_code"),
            )

    # 車両マスタへの自動登録 / 名称・事業所更新
    for code, (name, office) in seen_vehicles.items():
        v = db.get(Vehicle, code)
        if v is None:
            db.add(Vehicle(
                code=code,
                name=name or code,
                office_code=office,
                is_active=True,
            ))
        else:
            if name and v.name != name:
                v.name = name
            if office and v.office_code != office:
                v.office_code = office

    db.commit()
    return {
        "status": "success",
        "imported": imported,
        "updated": updated,
        "errors": errors,
    }
