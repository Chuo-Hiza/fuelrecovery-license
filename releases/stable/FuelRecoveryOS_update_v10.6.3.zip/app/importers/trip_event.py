"""イベントデータ CSV インポーター (_evn ファイル)。

列仕様（位置固定、ヘッダーなし）:
  メタレコード（1行目）:
    col 0: 日報番号
    col 1: 運行日
    col 2: 乗務員コード
    col 3: 車両コード
    col 4: 組織コード
    col 5: 出庫日時
    col 6: 入庫日時

  データレコード（2行目以降、12列固定）:
    col 0: イベント種別コード (E001=出庫, E002=入庫, E102=エンジンON/OFF, E204=急加減速, E301=到着/出発 等)
    col 1: 日付 (yyyy/MM/dd)
    col 2: 時刻 (HH:mm:ss)
    col 3: 速度 (km/h) ※空の場合あり
    col 4: 積載状態 (0=空車, 1=実車)
    col 5: 予備1
    col 6: 予備2
    col 7: 追加値（G値等）
    col 8: 累積走行距離 (m)
    col 9: GPS緯度 (小数点形式)
    col10: GPS経度 (小数点形式)
    col11: 進行方向 (0-360度)
"""
import csv
import io
import logging
from datetime import datetime
from pathlib import Path

from sqlalchemy.orm import Session

from app.models.csv_import import TripEvent

logger = logging.getLogger(__name__)

# 位置インデックス定数
_COL_EVENT_TYPE = 0
_COL_DATE = 1
_COL_TIME = 2
_COL_SPEED = 3
_COL_LOADING = 4
_COL_EXTRA1 = 5
_COL_EXTRA2 = 6
_COL_EXTRA3 = 7
_COL_DISTANCE = 8
_COL_LAT = 9
_COL_LON = 10
_COL_HEADING = 11


def _parse_int(val: str) -> int | None:
    if not val or not val.strip():
        return None
    try:
        return int(val.strip())
    except (ValueError, TypeError):
        return None


def _parse_float(val: str) -> float | None:
    if not val or not val.strip():
        return None
    try:
        return float(val.strip())
    except (ValueError, TypeError):
        return None


def _parse_gps(val: str) -> int | None:
    """GPS座標(小数)を整数x10^5に変換。例: 35.6854500 → 3568545"""
    f = _parse_float(val)
    if f is None:
        return None
    return int(round(f * 100000))


def import_trip_event(filepath: Path, db: Session) -> dict:
    """_evn.csv を読み込み TripEvent テーブルに投入する。

    Returns:
        dict with keys: status, imported, updated, errors
    """
    try:
        raw = filepath.read_bytes()
        text_data = raw.decode("cp932", errors="replace")
    except Exception as e:
        return {"status": "error", "detail": str(e)}

    lines = text_data.splitlines()
    if not lines:
        return {"status": "error", "detail": "Empty file"}

    # メタ行から日報番号を取得
    header_cols = list(csv.reader([lines[0]]))[0]
    if not header_cols:
        return {"status": "error", "detail": "Invalid header row"}

    report_number = header_cols[0].strip() if header_cols[0].strip() else None
    if not report_number:
        return {"status": "error", "detail": "Missing report_number in header"}

    # 洗い替え
    existing_count = db.query(TripEvent).filter_by(report_number=report_number).count()
    if existing_count > 0:
        db.query(TripEvent).filter_by(report_number=report_number).delete()
        db.flush()

    imported = 0
    errors = []

    for line_no, line in enumerate(lines[1:], start=2):
        line = line.strip()
        if not line:
            continue

        cols = list(csv.reader([line]))[0]
        if len(cols) < 3:
            errors.append(f"Line {line_no}: too few columns ({len(cols)})")
            continue

        def col(idx: int) -> str:
            return cols[idx].strip() if idx < len(cols) else ""

        event_type = col(_COL_EVENT_TYPE)
        if not event_type:
            errors.append(f"Line {line_no}: missing event_type")
            continue

        # イベント日時
        date_str = col(_COL_DATE)
        time_str = col(_COL_TIME)
        if not date_str or not time_str:
            errors.append(f"Line {line_no}: missing date/time")
            continue

        try:
            event_datetime = datetime.strptime(f"{date_str} {time_str}", "%Y/%m/%d %H:%M:%S")
        except ValueError:
            try:
                event_datetime = datetime.strptime(f"{date_str} {time_str}", "%Y/%m/%d %H:%M")
            except ValueError:
                errors.append(f"Line {line_no}: invalid datetime '{date_str} {time_str}'")
                continue

        speed = _parse_int(col(_COL_SPEED))
        gps_lat = _parse_gps(col(_COL_LAT))
        gps_lon = _parse_gps(col(_COL_LON))

        # extra_fields に追加情報を格納
        extra: dict = {}
        loading = col(_COL_LOADING)
        if loading:
            extra["loading_status"] = int(loading) if loading.isdigit() else loading
        distance = _parse_int(col(_COL_DISTANCE))
        if distance is not None:
            extra["cumulative_distance_m"] = distance
        heading = _parse_int(col(_COL_HEADING))
        if heading is not None:
            extra["heading_deg"] = heading
        for idx, key in [(_COL_EXTRA1, "extra1"), (_COL_EXTRA2, "extra2"), (_COL_EXTRA3, "extra3")]:
            v = col(idx)
            if v:
                extra[key] = v

        record = TripEvent(
            report_number=report_number,
            event_type=event_type,
            event_datetime=event_datetime,
            speed_kmh=speed,
            engine_rpm=None,
            gps_lat=gps_lat,
            gps_lon=gps_lon,
            g_value_x=None,
            g_value_y=None,
            extra_fields=extra if extra else None,
        )
        db.add(record)
        imported += 1

    db.commit()

    return {
        "status": "success",
        "imported": imported,
        "updated": existing_count,
        "errors": errors,
        "report_number": report_number,
    }
