"""Folder watcher — monitors auto-export folder and dispatches imports."""
import logging
import shutil
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

from sqlalchemy.orm import Session

from app.config import settings
from app.database import SessionLocal
from app.importers.base import classify_csv_file, extract_report_number, file_sha256
from app.importers.delivery_detail import import_delivery_detail
from app.importers.fuel_record import import_fuel_record
from app.importers.toll_record import import_toll_record
from app.importers.trip_event import import_trip_event
from app.importers.trip_report import import_trip_report
from app.importers.trip_timeseries import import_trip_timeseries
from app.importers import fuel_invoice as fuel_invoice_pkg
from app.models.system import CsvFileRegistry, ImportLog

logger = logging.getLogger(__name__)


def ensure_dirs():
    """Create all required directories if they don't exist."""
    for d in [
        settings.csv_auto_export_dir,
        settings.csv_daily_batch_dir,
        settings.csv_master_dir,
        settings.csv_monthly_dir,
        settings.csv_processing_dir,
        settings.csv_done_dir,
        settings.csv_error_dir,
    ]:
        Path(d).mkdir(parents=True, exist_ok=True)


def is_file_stable(filepath: Path, wait_sec: int = 2) -> bool:
    """Check if file size is stable (not being written to)."""
    size1 = filepath.stat().st_size
    time.sleep(wait_sec)
    if not filepath.exists():
        return False
    size2 = filepath.stat().st_size
    return size1 == size2


def process_file(filepath: Path, db: Session) -> None:
    """Process a single CSV file."""
    filename = filepath.name
    file_type = classify_csv_file(filename)
    report_number = extract_report_number(filename)

    # Check if already processed
    existing = db.query(CsvFileRegistry).filter_by(filepath=str(filepath)).first()
    if existing and existing.status == "done":
        logger.info(f"Already processed: {filename}")
        return

    # Register file
    file_hash = file_sha256(filepath)
    if not existing:
        registry = CsvFileRegistry(
            filepath=str(filepath),
            file_hash=file_hash,
            file_size=filepath.stat().st_size,
            status="processing",
            report_number=None,  # 日報番号が大きすぎてSQLite INTEGERに収まらない場合があるため無効化
        )
        db.add(registry)
        db.commit()
    else:
        existing.status = "processing"
        db.commit()
        registry = existing

    # Move to processing
    processing_path = Path(settings.csv_processing_dir) / filename
    shutil.move(str(filepath), str(processing_path))

    try:
        # Dispatch by file type
        if file_type == "report":
            result = import_trip_report(processing_path, db)
        elif file_type == "timeseries":
            result = import_trip_timeseries(processing_path, db)
        elif file_type == "detail":
            result = import_delivery_detail(processing_path, db)
        elif file_type == "fuel":
            result = import_fuel_record(processing_path, db)
        elif file_type == "toll":
            result = import_toll_record(processing_path, db)
        elif file_type == "event":
            result = import_trip_event(processing_path, db)
        elif file_type == "fuel_invoice":
            result = fuel_invoice_pkg.import_file(processing_path, db)
        else:
            result = {"status": "skipped", "detail": f"Unknown file type: {file_type}"}

        # Log import
        log = ImportLog(
            pipeline="A",
            filename=filename,
            file_type=file_type,
            status=result.get("status", "success"),
            records_imported=result.get("imported", 0),
            records_updated=result.get("updated", 0),
            error_detail=str(result.get("errors")) if result.get("errors") else None,
        )
        db.add(log)

        # Move to done
        today_dir = Path(settings.csv_done_dir) / datetime.now().strftime("%Y-%m-%d")
        today_dir.mkdir(parents=True, exist_ok=True)
        shutil.move(str(processing_path), str(today_dir / filename))

        registry.status = "done"
        registry.processed_at = datetime.now()
        db.commit()

        logger.info(f"Imported {filename}: {result}")

    except Exception as e:
        logger.error(f"Error importing {filename}: {e}", exc_info=True)
        db.rollback()
        # Move to error
        error_path = Path(settings.csv_error_dir) / filename
        try:
            if processing_path.exists():
                shutil.move(str(processing_path), str(error_path))
        except Exception:
            pass
        try:
            registry.status = "error"
            log = ImportLog(
                pipeline="A",
                filename=filename,
                file_type=file_type,
                status="error",
                error_detail=str(e)[:500],
            )
            db.add(log)
            db.commit()
        except Exception:
            db.rollback()


def poll_once():
    """Scan auto-export folder once and process new files."""
    export_dir = Path(settings.csv_auto_export_dir)
    if not export_dir.exists():
        return

    csv_files = sorted(export_dir.glob("*.csv"))
    if not csv_files:
        return

    logger.info(f"Found {len(csv_files)} CSV files in auto-export")

    # Wait for file stability (single sleep, then check all)
    time.sleep(settings.file_stable_wait_sec)
    stable_files = [f for f in csv_files if f.exists()]

    if not stable_files:
        return

    db = SessionLocal()
    try:
        for filepath in stable_files:
            try:
                process_file(filepath, db)
            except Exception as e:
                logger.error(f"Error processing {filepath.name}: {e}", exc_info=True)
                # Rollback any failed transaction so next file can proceed
                db.rollback()
    finally:
        db.close()


def cleanup_done_folder():
    """Delete date-folders in done directory older than retention period."""
    done_dir = Path(settings.csv_done_dir)
    if not done_dir.exists():
        return
    cutoff = datetime.now() - timedelta(days=settings.done_retention_days)
    for folder in done_dir.iterdir():
        if not folder.is_dir():
            continue
        try:
            folder_date = datetime.strptime(folder.name, "%Y-%m-%d")
            if folder_date < cutoff:
                shutil.rmtree(folder)
                logger.info(f"Cleaned up done folder: {folder.name}")
        except ValueError:
            continue


def run_watcher(stop_event: threading.Event | None = None):
    """Run the polling loop.

    Args:
        stop_event: Optional threading.Event for graceful shutdown.
    """
    ensure_dirs()
    logger.info(f"Watcher started. Polling every {settings.polling_interval_sec}s")
    logger.info(f"Watching: {settings.csv_auto_export_dir}")

    while True:
        if stop_event and stop_event.is_set():
            logger.info("Watcher stopping (stop_event set)")
            break
        try:
            poll_once()
            cleanup_done_folder()
        except Exception as e:
            logger.error(f"Watcher error: {e}")

        # Interruptible sleep
        if stop_event:
            stop_event.wait(timeout=settings.polling_interval_sec)
        else:
            time.sleep(settings.polling_interval_sec)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_watcher()
