"""給油請求書 CSV 取込のフォーマット振り分け。

新フォーマットを追加する場合:
  1. このパッケージ内に `<format_name>.py` を作成
  2. その中に以下を実装:
       FORMAT_NAME = "<format_name>"
       def matches(filepath: Path, head_text: str) -> bool: ...
       def parse_rows(filepath: Path) -> Iterable[dict]: ...
  3. _ADAPTERS リストに登録
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Iterable

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.fuel_invoice import FuelInvoice
from app.importers.fuel_invoice import kawamura

logger = logging.getLogger(__name__)

# 対応フォーマット(優先順)
_ADAPTERS = [kawamura]


def _read_head(filepath: Path, n_bytes: int = 4096) -> str:
    """エンコーディング推測のため先頭バイトを読む(CP932 fallback)。"""
    try:
        raw = filepath.read_bytes()[:n_bytes]
    except Exception:
        return ""
    for enc in ("cp932", "utf-8-sig", "utf-8"):
        try:
            return raw.decode(enc, errors="replace")
        except Exception:
            continue
    return ""


def detect_format(filepath: Path) -> object | None:
    """ファイルからフォーマットアダプタを判定。一致なしなら None。"""
    head = _read_head(filepath)
    for adapter in _ADAPTERS:
        try:
            if adapter.matches(filepath, head):
                return adapter
        except Exception as e:
            logger.warning(f"adapter {adapter.FORMAT_NAME} matches() error: {e}")
    return None


def import_file(filepath: Path, db: Session) -> dict:
    """ファイルを取込んで集計を返す。

    Returns:
        {"status": "ok"|"error"|"unknown_format",
         "format": str | None,
         "imported": int, "skipped_dup": int, "errors": int, "detail": str}
    """
    adapter = detect_format(filepath)
    if not adapter:
        logger.info(f"fuel_invoice: unknown format {filepath.name}")
        return {"status": "unknown_format", "format": None,
                "imported": 0, "skipped_dup": 0, "errors": 0,
                "detail": "対応フォーマットなし"}

    fmt = adapter.FORMAT_NAME
    imported = 0
    skipped = 0
    errors = 0
    try:
        rows: Iterable[dict] = adapter.parse_rows(filepath)
    except Exception as e:
        logger.error(f"fuel_invoice: parse failed {filepath.name}: {e}")
        return {"status": "error", "format": fmt,
                "imported": 0, "skipped_dup": 0, "errors": 1, "detail": str(e)}

    for r in rows:
        rec = FuelInvoice(
            source_format=fmt,
            source_filename=filepath.name,
            customer_code=r.get("customer_code"),
            customer_name=r.get("customer_name"),
            billing_date=r.get("billing_date"),
            transaction_date=r.get("transaction_date"),
            vehicle_no=r.get("vehicle_no"),
            slip_number=r.get("slip_number"),
            line_number=r.get("line_number"),
            product_code=r.get("product_code"),
            product_name=r.get("product_name"),
            product_category=r.get("product_category"),
            quantity=r.get("quantity"),
            unit_price=r.get("unit_price"),
            amount_excl_tax=r.get("amount_excl_tax"),
            consumption_tax=r.get("consumption_tax"),
            diesel_tax=r.get("diesel_tax"),
            amount_total=r.get("amount_total"),
            station_name=r.get("station_name"),
            raw_row=r.get("raw_row"),
        )
        try:
            db.add(rec)
            db.flush()  # ユニーク制約をすぐ判定したいので
            imported += 1
        except IntegrityError:
            db.rollback()
            skipped += 1
        except Exception as e:
            db.rollback()
            errors += 1
            logger.warning(f"fuel_invoice: row insert failed: {e}")
    db.commit()
    logger.info(f"fuel_invoice[{fmt}] {filepath.name}: "
                f"imported={imported}, skipped_dup={skipped}, errors={errors}")

    # 取込済みマッピングがあれば自動で月次給油へ同期
    sync_summary: dict | None = None
    try:
        from app.services import fuel_invoice_sync as _sync
        sync_summary = _sync.sync_to_monthly(db)
    except Exception as e:
        logger.warning(f"fuel_invoice: auto-sync failed: {e}")

    return {"status": "ok", "format": fmt,
            "imported": imported, "skipped_dup": skipped, "errors": errors,
            "sync": sync_summary, "detail": ""}
