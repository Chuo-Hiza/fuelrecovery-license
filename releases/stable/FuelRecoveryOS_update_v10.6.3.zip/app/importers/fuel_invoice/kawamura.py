"""カワムラ系 給油請求書 CSV アダプタ。

ファイル名パターン: 請求書_明細_*.csv
エンコーディング: CP932
列構成(位置固定、ヘッダー行あり):
   0: 請求顧客コード１
   1: 請求顧客コード２
   2: 顧客名称１ ２（漢字）
   3: 請求年月日 (YYYYMMDD)
   4: 車番 (4桁)
   5: 取引年月日 (YYYYMMDD)
   6: 伝票番号
   7: 行番号
   8: 商品コードＸ
   9: 商品コードＹ
  10: 商品名称（カナ）
  11: 数量
  12: 単価
  13: 金額（税抜き）
  14: 消費税
  15: 軽油税
  16: 金額（合計）
  17: スタンド名カナ
"""
from __future__ import annotations

import csv
import logging
import re
from datetime import date, datetime
from pathlib import Path
from typing import Iterable

logger = logging.getLogger(__name__)

FORMAT_NAME = "kawamura"

# 商品コード → 正規化カテゴリ
_DIESEL_CODES = {"00235", "00236", "00208"}  # 軽油R圧縮 / 軽油凍結R / 軽油R
_ADDITIVE_CODES = {"04749"}                  # 添加剤(軽油)
_GASOLINE_KEYWORDS = ("ガソリン", "ｶﾞｿﾘﾝ")
_ADDITIVE_KEYWORDS = ("添加剤", "ﾃﾝｶｻﾞｲ", "ﾃﾝｶ")
_OIL_KEYWORDS = ("OIL", "ｵｲﾙ", "オイル", "M-OIL")


def matches(filepath: Path, head_text: str) -> bool:
    """ファイル名が「請求書_明細_*.csv」パターンか判定。"""
    name = filepath.name
    return bool(re.match(r"請求書_明細_.*\.csv$", name))


def _parse_date(s: str) -> date | None:
    s = (s or "").strip()
    if len(s) != 8 or not s.isdigit():
        return None
    try:
        return datetime.strptime(s, "%Y%m%d").date()
    except ValueError:
        return None


def _parse_int(s: str) -> int | None:
    s = (s or "").strip()
    if not s:
        return None
    try:
        return int(float(s))
    except ValueError:
        return None


def _parse_float(s: str) -> float | None:
    s = (s or "").strip()
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _classify(product_code: str | None, product_name: str | None) -> str:
    code = (product_code or "").strip()
    name = (product_name or "")
    if code in _DIESEL_CODES:
        return "diesel"
    if code in _ADDITIVE_CODES:
        return "additive"
    if any(k in name for k in _GASOLINE_KEYWORDS):
        return "gasoline"
    if any(k in name for k in _ADDITIVE_KEYWORDS):
        return "additive"
    if any(k in name for k in _OIL_KEYWORDS):
        return "oil"
    return "other"


def parse_rows(filepath: Path) -> Iterable[dict]:
    """CSV を読み、正規化済み dict のイテレータを返す。"""
    raw = filepath.read_bytes()
    text = raw.decode("cp932", errors="replace")
    reader = csv.reader(text.splitlines())
    headers = None
    for i, row in enumerate(reader):
        if not row or all((c or "").strip() == "" for c in row):
            continue
        if headers is None:
            headers = row
            continue
        # 列数チェック(最低限17列必要)
        if len(row) < 17:
            logger.warning(f"kawamura: row {i} has too few columns: {len(row)}")
            continue
        product_code = (row[8] or "").strip()
        product_name = (row[10] or "").strip()
        yield {
            "customer_code": f"{(row[0] or '').strip()}-{(row[1] or '').strip()}",
            "customer_name": (row[2] or "").strip(),
            "billing_date": _parse_date(row[3]),
            "vehicle_no": (row[4] or "").strip().zfill(4),
            "transaction_date": _parse_date(row[5]),
            "slip_number": (row[6] or "").strip(),
            "line_number": _parse_int(row[7]),
            "product_code": product_code,
            "product_name": product_name,
            "product_category": _classify(product_code, product_name),
            "quantity": _parse_float(row[11]),
            "unit_price": _parse_float(row[12]),
            "amount_excl_tax": _parse_int(row[13]),
            "consumption_tax": _parse_int(row[14]),
            "diesel_tax": _parse_int(row[15]),
            "amount_total": _parse_int(row[16]),
            "station_name": (row[17] or "").strip() if len(row) > 17 else None,
            "raw_row": dict(zip(headers, row)),
        }
