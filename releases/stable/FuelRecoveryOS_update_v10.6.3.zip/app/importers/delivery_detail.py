"""配送明細 CSV インポーター (_h ファイル)。"""
import logging
from pathlib import Path

from sqlalchemy.orm import Session

from app.importers.base import (
    read_csv_shift_jis, parse_int, parse_float, parse_datetime,
    parse_time_to_sec, parse_km_to_m,
)
from app.models.csv_import import DeliveryDetail

logger = logging.getLogger(__name__)


def import_delivery_detail(filepath: Path, db: Session) -> dict:
    """_h.csv を読み込み DeliveryDetail テーブルに投入する。

    Returns:
        dict with keys: status, imported, updated, errors
    """
    rows = read_csv_shift_jis(filepath)
    if not rows:
        return {"status": "success", "imported": 0, "updated": 0, "errors": []}

    # report_number を最初の行から取得
    first_rn = (rows[0].get("日報番号") or "").strip()
    if not first_rn:
        return {"status": "error", "imported": 0, "updated": 0,
                "errors": ["Missing 日報番号 in first row"]}

    # 洗い替え: 既存レコード削除
    existing = db.query(DeliveryDetail).filter_by(report_number=first_rn).count()
    if existing > 0:
        db.query(DeliveryDetail).filter_by(report_number=first_rn).delete()
        db.flush()

    imported = 0
    errors = []

    for i, row in enumerate(rows, start=2):
        report_number = (row.get("日報番号") or "").strip() or None
        if not report_number:
            continue

        try:
            arr_dt = parse_datetime(row.get("着日付"), row.get("着時刻"))
            sch_dt = parse_datetime(row.get("着予定日付"), row.get("着予定時刻"))
            dep_dt = parse_datetime(row.get("発日付"), row.get("発時刻"))

            detail = DeliveryDetail(
                report_number=report_number,
                detail_number=parse_int(row.get("明細行番号")),
                work_type=row.get("着地作業", "").strip() or None,
                arrival_datetime=arr_dt,
                scheduled_datetime=sch_dt,
                departure_datetime=dep_dt,
                work_time_sec=parse_time_to_sec(row.get("作業時間")),
                address=row.get("住所", "").strip() or None,
                destination_code=row.get("集配先コード", "").strip() or None,
                destination_name=row.get("集配先", "").strip() or None,
                shipper_code=row.get("荷主コード", "").strip() or None,
                shipper_name=row.get("荷主", "").strip() or None,
                gps_lat=parse_int(row.get("GPS緯度")),
                gps_lon=parse_int(row.get("GPS経度")),
                travel_time_sec=parse_time_to_sec(row.get("走行時間")),
                idle_time_sec=parse_time_to_sec(row.get("アイドリング時間")),
                stop_time_sec=parse_time_to_sec(row.get("停止時間")),
                travel_distance_m=parse_km_to_m(row.get("走行距離")),
                loaded_distance_m=parse_km_to_m(row.get("実車距離")),
                empty_distance_m=parse_km_to_m(row.get("空車距離")),
                cumulative_distance_m=parse_km_to_m(row.get("累積走行距離")),
                loading_status_code=row.get("積載状況コード", "").strip() or None,
                total_quantity=parse_float(row.get("全数量")),
                total_weight=parse_float(row.get("全重量")),
            )
            db.add(detail)
            imported += 1
        except Exception as e:
            errors.append(f"Row {i}: {e}")

    db.commit()
    return {
        "status": "success",
        "imported": imported,
        "updated": existing,
        "errors": errors,
    }
