"""給油明細 CSV インポーター (_gas ファイル)。"""
import logging
from pathlib import Path

from sqlalchemy.orm import Session

from app.importers.base import (
    read_csv_shift_jis, parse_int, parse_float, parse_datetime,
)
from app.models.csv_import import FuelRecord

logger = logging.getLogger(__name__)


def import_fuel_record(filepath: Path, db: Session) -> dict:
    """_gas.csv を読み込み FuelRecord テーブルに投入する。

    Returns:
        dict with keys: status, imported, updated, errors
    """
    rows = read_csv_shift_jis(filepath)
    if not rows:
        return {"status": "success", "imported": 0, "updated": 0, "errors": []}

    first_rn = (rows[0].get("日報番号") or "").strip()
    if not first_rn:
        return {"status": "error", "imported": 0, "updated": 0,
                "errors": ["Missing 日報番号 in first row"]}

    # 洗い替え
    existing = db.query(FuelRecord).filter_by(report_number=first_rn).count()
    if existing > 0:
        db.query(FuelRecord).filter_by(report_number=first_rn).delete()
        db.flush()

    imported = 0
    errors = []

    for i, row in enumerate(rows, start=2):
        report_number = (row.get("日報番号") or "").strip() or None
        if not report_number:
            continue

        try:
            amount = parse_float(row.get("給油量"))
            if not amount or amount == 0:
                continue

            record = FuelRecord(
                report_number=report_number,
                station_name=row.get("スタンド名", "").strip() or None,
                fuel_type=row.get("区分名", "").strip() or None,
                amount_l=amount,
                cost_yen=parse_int(row.get("金額")),
                fill_date=parse_datetime(row.get("給油日付")),
                fill_time=row.get("給油時刻", "").strip() or None,
            )
            db.add(record)
            imported += 1
        except Exception as e:
            errors.append(f"Row {i}: {e}")

    db.commit()
    return {
        "status": "success",
        "imported": imported,
        "updated": existing,
        "errors": errors,
    }
