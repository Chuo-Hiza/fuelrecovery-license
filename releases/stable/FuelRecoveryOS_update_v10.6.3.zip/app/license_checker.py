"""ライセンスチェック バックグラウンドスレッド。

CSV watcher (app/importers/watcher.py) と同じパターンで、別スレッドで定期実行する。
- 起動時に1回チェック
- その後24時間ごとにチェック
- 顧客ID未設定の場合はスキップ (試用フェーズはオフライン判定)
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime

from app.database import SessionLocal
from app.license import fetch_and_apply_license, get_customer_id, should_check_now

logger = logging.getLogger(__name__)

CHECK_INTERVAL_SEC = 60 * 60  # 1時間ごとにループを回し、内部で24時間判定


def run_license_checker(stop_event: threading.Event) -> None:
    """ライセンスチェック ループ。stop_event がセットされるまで動作する。"""
    logger.info("License checker thread started (interval=%d sec)", CHECK_INTERVAL_SEC)
    # 起動直後は2秒待機 (DB初期化完了を待つ)
    if stop_event.wait(2):
        return

    while not stop_event.is_set():
        try:
            db = SessionLocal()
            try:
                if get_customer_id(db) and should_check_now(db):
                    logger.info("Performing scheduled license check")
                    fetch_and_apply_license(db)
            finally:
                db.close()
        except Exception as e:
            logger.error("License checker error: %s", e, exc_info=True)

        if stop_event.wait(CHECK_INTERVAL_SEC):
            break

    logger.info("License checker thread stopped")
