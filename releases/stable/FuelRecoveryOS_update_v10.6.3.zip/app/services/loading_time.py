"""配送先別 荷待ち/荷役時間 集計サービス。

物流二法対応。DeliveryDetail を主軸に
(集配先コード, 集配先名, 荷主名, 住所) 単位でグルーピングし、
- 訪問回数
- 荷役時間(work_time_sec): 平均/最大/合計
- 推定 荷待ち時間(stop_time_sec - work_time_sec): 平均/最大/合計
- 推定 滞在時間(stop_time_sec): 合計
を返す。
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date
from typing import Any

from sqlalchemy.orm import Session

from app.models.csv_import import DeliveryDetail, TripReport


def aggregate(db: Session, start_date: date, end_date: date) -> list[dict[str, Any]]:
    """期間内の DeliveryDetail を集配先単位で集計。

    集計キー: (destination_code, destination_name, address) — 同一名でも住所違いは別行
    荷主名は最頻値を採用(同一集配先で複数荷主が紐付くケースに備え)。
    """
    rows = (
        db.query(DeliveryDetail, TripReport.operation_date)
        .join(TripReport, DeliveryDetail.report_number == TripReport.report_number)
        .filter(
            TripReport.operation_date >= start_date,
            TripReport.operation_date <= end_date,
            DeliveryDetail.destination_code.isnot(None),
        )
        .all()
    )

    # 集計バケット
    bucket: dict[tuple, dict[str, Any]] = defaultdict(lambda: {
        "destination_code": "",
        "destination_name": "",
        "address": "",
        "shipper_names": defaultdict(int),  # 出現回数
        "visit_count": 0,
        "work_secs": [],
        "wait_secs": [],
        "stay_secs": [],
    })

    for dd, _opdate in rows:
        # 「出庫」「入庫」など作業地点ではないものを除外
        if dd.work_type in ("出庫", "入庫"):
            continue
        key = (
            dd.destination_code or "",
            dd.destination_name or "",
            dd.address or "",
        )
        b = bucket[key]
        b["destination_code"] = dd.destination_code or ""
        b["destination_name"] = dd.destination_name or ""
        b["address"] = dd.address or ""
        if dd.shipper_name:
            b["shipper_names"][dd.shipper_name] += 1

        b["visit_count"] += 1
        work = max(0, dd.work_time_sec or 0)
        stop = max(0, dd.stop_time_sec or 0)
        # 推定 荷待ち = 停止 - 作業(マイナスは0)
        wait = max(0, stop - work)
        b["work_secs"].append(work)
        b["wait_secs"].append(wait)
        b["stay_secs"].append(stop)

    results: list[dict[str, Any]] = []
    for b in bucket.values():
        # 荷主名(最頻値)
        if b["shipper_names"]:
            shipper_name = max(b["shipper_names"].items(), key=lambda x: x[1])[0]
        else:
            shipper_name = ""
        n = b["visit_count"]
        results.append({
            "destination_code": b["destination_code"],
            "destination_name": b["destination_name"] or b["destination_code"] or "(未登録)",
            "address": b["address"],
            "shipper_name": shipper_name,
            "visit_count": n,
            "work_avg_sec": int(sum(b["work_secs"]) / n) if n else 0,
            "work_max_sec": max(b["work_secs"]) if b["work_secs"] else 0,
            "work_total_sec": sum(b["work_secs"]),
            "wait_avg_sec": int(sum(b["wait_secs"]) / n) if n else 0,
            "wait_max_sec": max(b["wait_secs"]) if b["wait_secs"] else 0,
            "wait_total_sec": sum(b["wait_secs"]),
            "stay_total_sec": sum(b["stay_secs"]),
        })

    # 合計荷役時間 降順
    results.sort(key=lambda x: -x["work_total_sec"])
    return results
