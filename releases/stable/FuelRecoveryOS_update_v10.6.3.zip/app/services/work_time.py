"""車両/乗務員別 作業時間 集計サービス。

物流二法対応。TripReport を主軸に、乗務員 or 車両単位で
- 運行回数 / 運行日数
- 拘束時間(employment_sec)/稼働時間(working_time_sec)
- 実車/空車時間
- 荷積/荷卸/待機/休憩/休息/アイドリング 時間
を合計・平均で集計。
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date
from typing import Any, Literal

from sqlalchemy.orm import Session

from app.models.csv_import import TripReport


def aggregate(
    db: Session,
    start_date: date,
    end_date: date,
    by: Literal["driver", "vehicle"] = "driver",
) -> list[dict[str, Any]]:
    """期間内の TripReport を乗務員/車両で集計。

    by="driver"  : (driver_code, driver_name, driver_office_name) でグルーピング
    by="vehicle" : (vehicle_code, vehicle_name) でグルーピング
    """
    trips = (
        db.query(TripReport)
        .filter(
            TripReport.operation_date >= start_date,
            TripReport.operation_date <= end_date,
        )
        .all()
    )

    bucket: dict[tuple, dict[str, Any]] = defaultdict(lambda: {
        "code": "",
        "name": "",
        "office": "",
        "trip_count": 0,
        "operation_dates": set(),
        "employment_sec": 0,
        "working_sec": 0,
        "loaded_sec": 0,
        "empty_sec": 0,
        "loading_sec": 0,
        "unloading_sec": 0,
        "waiting_sec": 0,
        "break_sec": 0,
        "rest_sec": 0,
        "idle_sec": 0,
    })

    for t in trips:
        if by == "driver":
            key = (t.driver_code or "", t.driver_name or "")
            name = t.driver_name or t.driver_code or "(未登録)"
            office = t.driver_office_name or ""
            code = t.driver_code or ""
        else:
            key = (t.vehicle_code or "", t.vehicle_name or "")
            name = t.vehicle_name or t.vehicle_code or "(未登録)"
            office = t.vehicle_office_name or ""
            code = t.vehicle_code or ""

        b = bucket[key]
        b["code"] = code
        b["name"] = name
        b["office"] = office
        b["trip_count"] += 1
        if t.operation_date:
            b["operation_dates"].add(t.operation_date)
        b["employment_sec"] += t.employment_sec or 0
        b["working_sec"]    += t.working_time_sec or 0
        b["loaded_sec"]     += t.loaded_time_sec or 0
        b["empty_sec"]      += t.empty_time_sec or 0
        b["loading_sec"]    += t.loading_time_sec or 0
        b["unloading_sec"]  += t.unloading_time_sec or 0
        b["waiting_sec"]    += t.waiting_time_sec or 0
        b["break_sec"]      += t.break_sec or 0
        b["rest_sec"]       += t.rest_sec or 0
        b["idle_sec"]       += t.idle_time_sec or 0

    results: list[dict[str, Any]] = []
    for b in bucket.values():
        n = b["trip_count"]
        results.append({
            "code": b["code"],
            "name": b["name"],
            "office": b["office"],
            "trip_count": n,
            "day_count": len(b["operation_dates"]),
            "employment_total_sec": b["employment_sec"],
            "employment_avg_sec": int(b["employment_sec"] / n) if n else 0,
            "working_total_sec": b["working_sec"],
            "loaded_total_sec": b["loaded_sec"],
            "empty_total_sec": b["empty_sec"],
            "loading_total_sec": b["loading_sec"],
            "unloading_total_sec": b["unloading_sec"],
            "waiting_total_sec": b["waiting_sec"],
            "break_total_sec": b["break_sec"],
            "rest_total_sec": b["rest_sec"],
            "idle_total_sec": b["idle_sec"],
        })

    # 拘束時間合計 降順(時間負担の重い順)
    results.sort(key=lambda x: -x["employment_total_sec"])
    return results
