"""ライセンス関連ルーター。

- /license_locked: ロックダウン画面（middleware からリダイレクトされる先）
- /settings/license: ライセンス管理画面（顧客ID表示・編集、状態確認、手動チェック）
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.license import (
    compute_status,
    fetch_and_apply_license,
    get_customer_id,
    set_customer_id,
)

logger = logging.getLogger(__name__)
router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@router.get("/license_locked")
async def license_locked(request: Request, db: Session = Depends(get_db)):
    """ロック画面。middleware からリダイレクトされる。"""
    status = compute_status(db)
    return templates.TemplateResponse("license_locked.html", {
        "request": request,
        "status": status,
    })


@router.get("/settings/license")
async def settings_license_get(request: Request, db: Session = Depends(get_db)):
    """ライセンス管理画面 (設定タブ内)"""
    status = compute_status(db)
    return templates.TemplateResponse("settings_license.html", {
        "request": request,
        "current_page": "settings",
        "status": status,
        "saved": request.query_params.get("saved"),
        "checked": request.query_params.get("checked"),
        "error": request.query_params.get("error"),
    })


@router.post("/settings/license")
async def settings_license_post(
    request: Request,
    db: Session = Depends(get_db),
    customer_id: str = Form(...),
):
    """顧客ID 設定 (TeamViewer越しにベンダーが入力)"""
    cid = customer_id.strip()
    if not cid:
        return RedirectResponse(url="/settings/license?error=empty", status_code=303)
    if not all(c.isalnum() or c in "_-" for c in cid):
        return RedirectResponse(url="/settings/license?error=invalid", status_code=303)
    set_customer_id(db, cid)
    logger.info("Customer ID set: %s", cid)
    # 即座にライセンスチェックを実行
    fetch_and_apply_license(db)
    return RedirectResponse(url="/settings/license?saved=1", status_code=303)


@router.post("/settings/license/check_now")
async def settings_license_check_now(
    request: Request,
    db: Session = Depends(get_db),
):
    """手動でライセンスチェックを実行（ベンダー作業のためのデバッグ用途）"""
    if not get_customer_id(db):
        return RedirectResponse(url="/settings/license?error=no_customer_id", status_code=303)
    success = fetch_and_apply_license(db)
    return RedirectResponse(
        url=f"/settings/license?checked={'1' if success else '0'}",
        status_code=303,
    )
