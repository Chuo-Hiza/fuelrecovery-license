"""車両/乗務員別 作業時間 ルーター。"""
from __future__ import annotations

import csv
import io
from datetime import date, datetime
from typing import Literal

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.routers.month_utils import resolve_base_month, month_last_day, month_context
from app.services import work_time as work_time_svc

router = APIRouter(prefix="/analysis")
templates = Jinja2Templates(directory="app/templates")


def _resolve_period(
    db: Session, request: Request, start: str | None, end: str | None
) -> tuple[date, date]:
    if start and end:
        try:
            s = datetime.strptime(start, "%Y-%m-%d").date()
            e = datetime.strptime(end, "%Y-%m-%d").date()
            if s <= e:
                return s, e
        except ValueError:
            pass
    base = resolve_base_month(db, request.cookies.get("base_month"))
    return base, month_last_day(base)


def _normalize_by(by: str | None) -> Literal["driver", "vehicle"]:
    return "vehicle" if by == "vehicle" else "driver"


@router.get("/work-time")
async def work_time_page(
    request: Request,
    db: Session = Depends(get_db),
    by: str | None = Query(None),
    start: str | None = Query(None),
    end: str | None = Query(None),
):
    s, e = _resolve_period(db, request, start, end)
    by_kind = _normalize_by(by)
    rows = work_time_svc.aggregate(db, s, e, by=by_kind)
    return templates.TemplateResponse("analysis_work_time.html", {
        "request": request,
        "current_page": "work_time",
        "period_start": s,
        "period_end": e,
        "custom_period": bool(start and end),
        "by_kind": by_kind,
        "rows": rows,
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("/work-time.csv")
async def work_time_csv(
    request: Request,
    db: Session = Depends(get_db),
    by: str | None = Query(None),
    start: str | None = Query(None),
    end: str | None = Query(None),
):
    s, e = _resolve_period(db, request, start, end)
    by_kind = _normalize_by(by)
    rows = work_time_svc.aggregate(db, s, e, by=by_kind)

    label = "乗務員" if by_kind == "driver" else "車両"
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow([
        f"{label}コード", f"{label}名", "所属",
        "運行回数", "運行日数",
        "拘束時間 合計(時:分)", "拘束時間 平均(時:分)",
        "稼働時間 合計(時:分)",
        "実車時間 合計(時:分)", "空車時間 合計(時:分)",
        "荷積時間 合計(時:分)", "荷卸時間 合計(時:分)",
        "待機時間 合計(時:分)",
        "休憩時間 合計(時:分)", "休息時間 合計(時:分)",
        "アイドリング時間 合計(時:分)",
    ])

    def hm(sec: int) -> str:
        h, m = sec // 3600, (sec % 3600) // 60
        return f"{h}:{m:02d}"

    for r in rows:
        w.writerow([
            r["code"], r["name"], r["office"],
            r["trip_count"], r["day_count"],
            hm(r["employment_total_sec"]), hm(r["employment_avg_sec"]),
            hm(r["working_total_sec"]),
            hm(r["loaded_total_sec"]), hm(r["empty_total_sec"]),
            hm(r["loading_total_sec"]), hm(r["unloading_total_sec"]),
            hm(r["waiting_total_sec"]),
            hm(r["break_total_sec"]), hm(r["rest_total_sec"]),
            hm(r["idle_total_sec"]),
        ])
    body = "\ufeff" + buf.getvalue()
    filename = f"work_time_{by_kind}_{s:%Y%m%d}_{e:%Y%m%d}.csv"
    return StreamingResponse(
        iter([body.encode("utf-8")]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
