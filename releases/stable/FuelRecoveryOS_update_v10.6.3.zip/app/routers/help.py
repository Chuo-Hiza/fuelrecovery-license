"""Help page router."""
from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@router.get("/help")
async def help_page(request: Request):
    return templates.TemplateResponse("help.html", {"request": request, "current_page": "help"})
