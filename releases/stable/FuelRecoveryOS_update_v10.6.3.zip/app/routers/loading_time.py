"""配送先別 荷待ち/荷役時間 ルーター。"""
from __future__ import annotations

import csv
import io
from datetime import date, datetime

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.routers.month_utils import resolve_base_month, month_last_day, month_context
from app.services import loading_time as loading_time_svc

router = APIRouter(prefix="/analysis")
templates = Jinja2Templates(directory="app/templates")


def _resolve_period(
    db: Session, request: Request, start: str | None, end: str | None
) -> tuple[date, date]:
    """カスタム期間 (start, end) があればそれを使用、無ければ基軸月の月初〜月末。"""
    if start and end:
        try:
            s = datetime.strptime(start, "%Y-%m-%d").date()
            e = datetime.strptime(end, "%Y-%m-%d").date()
            if s <= e:
                return s, e
        except ValueError:
            pass
    base = resolve_base_month(db, request.cookies.get("base_month"))
    return base, month_last_day(base)


@router.get("/loading-time")
async def loading_time_page(
    request: Request,
    db: Session = Depends(get_db),
    start: str | None = Query(None),
    end: str | None = Query(None),
):
    s, e = _resolve_period(db, request, start, end)
    rows = loading_time_svc.aggregate(db, s, e)
    return templates.TemplateResponse("analysis_loading_time.html", {
        "request": request,
        "current_page": "loading_time",
        "period_start": s,
        "period_end": e,
        "custom_period": bool(start and end),
        "rows": rows,
        "totals": {
            "visit_count": sum(r["visit_count"] for r in rows),
            "work_total_sec": sum(r["work_total_sec"] for r in rows),
            "wait_total_sec": sum(r["wait_total_sec"] for r in rows),
            "stay_total_sec": sum(r["stay_total_sec"] for r in rows),
        },
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("/loading-time.csv")
async def loading_time_csv(
    request: Request,
    db: Session = Depends(get_db),
    start: str | None = Query(None),
    end: str | None = Query(None),
):
    s, e = _resolve_period(db, request, start, end)
    rows = loading_time_svc.aggregate(db, s, e)

    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow([
        "集配先コード", "集配先名", "住所", "荷主名", "訪問回数",
        "荷役時間 平均(分)", "荷役時間 最大(分)", "荷役時間 合計(分)",
        "推定 荷待ち時間 平均(分)", "推定 荷待ち時間 最大(分)", "推定 荷待ち時間 合計(分)",
        "推定 滞在時間 合計(分)",
    ])
    for r in rows:
        w.writerow([
            r["destination_code"], r["destination_name"], r["address"], r["shipper_name"],
            r["visit_count"],
            r["work_avg_sec"] // 60, r["work_max_sec"] // 60, r["work_total_sec"] // 60,
            r["wait_avg_sec"] // 60, r["wait_max_sec"] // 60, r["wait_total_sec"] // 60,
            r["stay_total_sec"] // 60,
        ])
    body = "\ufeff" + buf.getvalue()  # UTF-8 BOM (Excel で文字化け防止)
    filename = f"loading_time_{s:%Y%m%d}_{e:%Y%m%d}.csv"
    return StreamingResponse(
        iter([body.encode("utf-8")]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
