"""CSV取込ステータス — 取込ログ表示・一括取込。"""
import logging
import re
from pathlib import Path

from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, desc
from sqlalchemy.orm import Session

from app.config import settings
from app.dependencies import get_db
from app.importers.base import classify_csv_file, extract_report_number
from app.importers.watcher import process_file, ensure_dirs
from app.models.system import ImportLog

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/import", tags=["import"])
templates = Jinja2Templates(directory="app/templates")

# File type processing order: parent first, then children
_TYPE_ORDER = {"report": 0, "detail": 1, "fuel": 2, "toll": 3, "event": 4, "timeseries": 5}

FILE_TYPE_LABELS = {
    "report": "日報",
    "detail": "配送明細",
    "fuel": "給油",
    "toll": "通行料",
    "event": "イベント",
    "timeseries": "時系列",
}


@router.get("/status")
async def import_status_page(
    request: Request,
    file_type: str = "",
    status: str = "",
    db: Session = Depends(get_db),
):
    """CSV取込ステータスダッシュボード。"""
    # Recent logs
    q = db.query(ImportLog).order_by(desc(ImportLog.imported_at))
    if file_type:
        q = q.filter(ImportLog.file_type == file_type)
    if status:
        q = q.filter(ImportLog.status == status)
    logs = q.limit(100).all()

    # Summary stats
    from datetime import date, datetime
    today_start = datetime.combine(date.today(), datetime.min.time())
    today_stats = db.query(
        ImportLog.status,
        func.count(ImportLog.id),
    ).filter(ImportLog.imported_at >= today_start).group_by(ImportLog.status).all()

    today_success = sum(c for s, c in today_stats if s == "success")
    today_error = sum(c for s, c in today_stats if s == "error")
    today_total = sum(c for _, c in today_stats)

    total_all = db.query(func.count(ImportLog.id)).scalar() or 0

    # Files in error folder
    error_dir = Path(settings.csv_error_dir)
    error_files = sorted(error_dir.glob("*.csv")) if error_dir.exists() else []

    # Current export folder status
    export_dir = Path(settings.csv_auto_export_dir)
    pending_files = sorted(export_dir.glob("*.csv")) if export_dir.exists() else []

    return templates.TemplateResponse("import_status.html", {
        "request": request,
        "current_page": "import_status",
        "logs": logs,
        "today_success": today_success,
        "today_error": today_error,
        "today_total": today_total,
        "total_all": total_all,
        "error_files": [f.name for f in error_files],
        "pending_files": [f.name for f in pending_files],
        "selected_file_type": file_type,
        "selected_status": status,
        "file_type_labels": FILE_TYPE_LABELS,
        "csv_auto_export_dir": settings.csv_auto_export_dir,
        "polling_interval_sec": settings.polling_interval_sec,
    })


@router.post("/bulk")
async def bulk_import(
    request: Request,
    folder_path: str = Form(...),
    db: Session = Depends(get_db),
):
    """指定フォルダからCSVを一括取込。"""
    ensure_dirs()
    folder = Path(folder_path)
    if not folder.exists() or not folder.is_dir():
        return RedirectResponse(
            url=f"/import/status?error=folder_not_found",
            status_code=303,
        )

    csv_files = sorted(folder.glob("*.csv"))
    if not csv_files:
        return RedirectResponse(
            url=f"/import/status?error=no_csv_files",
            status_code=303,
        )

    # Group by report number, process in order: report first, then children
    groups: dict[str, list[tuple[int, Path]]] = {}
    for f in csv_files:
        rn = extract_report_number(f.name) or "unknown"
        ftype = classify_csv_file(f.name)
        order = _TYPE_ORDER.get(ftype, 99)
        groups.setdefault(rn, []).append((order, f))

    processed = 0
    for rn in sorted(groups.keys()):
        files = sorted(groups[rn], key=lambda x: x[0])
        for _, filepath in files:
            try:
                process_file(filepath, db)
                processed += 1
            except Exception as e:
                logger.error(f"Bulk import error for {filepath.name}: {e}")

    return RedirectResponse(
        url=f"/import/status?bulk_done={processed}",
        status_code=303,
    )
