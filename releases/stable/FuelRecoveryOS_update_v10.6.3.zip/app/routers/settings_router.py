"""Settings router — 指導書自動判別条件などシステム設定管理。"""
import json
from datetime import datetime

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.master import Vehicle
from app.models.system import SystemSetting

DEFAULT_BASELINE_EFFICIENCY = 5.0  # km/L — 車両別基準燃費の未設定時デフォルト

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# 判別条件の定義（field, label, op, unit, default_threshold, default_enabled）
CRITERIA_META = [
    {"field": "avg_score",        "label": "総合評価点",     "op": "lte", "unit": "点", "default": 70,  "enabled": True},
    {"field": "avg_safety",       "label": "安全評価",       "op": "lte", "unit": "点", "default": 70,  "enabled": False},
    {"field": "avg_economy",      "label": "経済評価",       "op": "lte", "unit": "点", "default": 70,  "enabled": False},
    {"field": "idle_rate",        "label": "アイドリング率",  "op": "gte", "unit": "%",  "default": 15,  "enabled": True},
    {"field": "events_per_100km", "label": "急操作/100km",   "op": "gte", "unit": "回", "default": 3.0, "enabled": True},
    {"field": "speed_over",       "label": "速度超過",       "op": "gte", "unit": "回", "default": 5,   "enabled": False},
]

SETTING_KEY = "coaching_auto_criteria"
FUEL_PRICE_KEY = "fuel_price"
FUEL_PRICE_DEFAULT = 162  # yen/L


def get_fuel_price(db: Session) -> float:
    """DBから軽油単価を取得。未設定の場合はデフォルト値を返す。"""
    row = db.query(SystemSetting).filter(SystemSetting.key == FUEL_PRICE_KEY).first()
    if row:
        try:
            return float(row.value)
        except (ValueError, TypeError):
            pass
    return float(FUEL_PRICE_DEFAULT)


def get_criteria(db: Session) -> list:
    """DBから判別条件を取得。未設定の場合はデフォルト値を返す。"""
    row = db.query(SystemSetting).filter(SystemSetting.key == SETTING_KEY).first()
    if row:
        saved = {c["field"]: c for c in json.loads(row.value)}
        result = []
        for m in CRITERIA_META:
            c = saved.get(m["field"], {})
            result.append({
                "field":     m["field"],
                "label":     m["label"],
                "op":        m["op"],
                "unit":      m["unit"],
                "threshold": c.get("threshold", m["default"]),
                "enabled":   c.get("enabled", m["enabled"]),
            })
        return result
    # 初回: デフォルト
    return [
        {"field": m["field"], "label": m["label"], "op": m["op"],
         "unit": m["unit"], "threshold": m["default"], "enabled": m["enabled"]}
        for m in CRITERIA_META
    ]


def get_vehicle_baseline(db: Session, vehicle_code: str) -> float:
    """車両の基準燃費を取得。未設定時はデフォルト値を返す。"""
    v = db.query(Vehicle).filter(Vehicle.code == vehicle_code).first()
    if v and v.baseline_efficiency_kml is not None:
        return v.baseline_efficiency_kml
    return DEFAULT_BASELINE_EFFICIENCY


@router.get("/settings")
async def settings_page(request: Request, db: Session = Depends(get_db)):
    criteria = get_criteria(db)
    saved = db.query(SystemSetting).filter(SystemSetting.key == SETTING_KEY).first()
    updated_at = saved.updated_at.strftime("%Y/%m/%d %H:%M") if saved and saved.updated_at else None
    fuel_price = get_fuel_price(db)

    # 車両プロファイル
    vehicles = db.query(Vehicle).filter(Vehicle.is_active == 1).order_by(Vehicle.code).all()

    return templates.TemplateResponse("settings.html", {
        "request": request,
        "current_page": "settings",
        "criteria": criteria,
        "updated_at": updated_at,
        "fuel_price": fuel_price,
        "fuel_price_default": FUEL_PRICE_DEFAULT,
        "vehicles": vehicles,
        "default_efficiency": DEFAULT_BASELINE_EFFICIENCY,
        "profile_saved": request.query_params.get("profile_saved"),
    })


@router.post("/settings")
async def save_settings(request: Request, db: Session = Depends(get_db)):
    form = await request.form()
    criteria = []
    for m in CRITERIA_META:
        f = m["field"]
        raw = form.get(f"threshold_{f}", str(m["default"]))
        try:
            threshold = float(raw)
        except ValueError:
            threshold = float(m["default"])
        criteria.append({
            "field":     f,
            "label":     m["label"],
            "op":        m["op"],
            "unit":      m["unit"],
            "threshold": threshold,
            "enabled":   form.get(f"enabled_{f}") == "on",
        })

    row = db.query(SystemSetting).filter(SystemSetting.key == SETTING_KEY).first()
    value = json.dumps(criteria, ensure_ascii=False)
    if row:
        row.value = value
        row.updated_at = datetime.now()
    else:
        db.add(SystemSetting(
            key=SETTING_KEY,
            value=value,
            description="指導書自動判別条件",
            updated_at=datetime.now(),
        ))

    # 軽油単価の保存
    raw_price = form.get("fuel_price", "")
    try:
        fuel_price_val = float(raw_price)
        if fuel_price_val <= 0:
            raise ValueError
    except (ValueError, TypeError):
        fuel_price_val = float(FUEL_PRICE_DEFAULT)
    fp_row = db.query(SystemSetting).filter(SystemSetting.key == FUEL_PRICE_KEY).first()
    if fp_row:
        fp_row.value = str(fuel_price_val)
        fp_row.updated_at = datetime.now()
    else:
        db.add(SystemSetting(
            key=FUEL_PRICE_KEY,
            value=str(fuel_price_val),
            description="軽油単価（円/L）",
            updated_at=datetime.now(),
        ))

    db.commit()
    return RedirectResponse(url="/settings?saved=1", status_code=303)


@router.post("/settings/vehicle-profile")
async def save_vehicle_profile(request: Request, db: Session = Depends(get_db)):
    """車両別基準燃費を一括保存。"""
    form = await request.form()
    vehicles = db.query(Vehicle).filter(Vehicle.is_active == 1).all()
    updated = 0
    for v in vehicles:
        raw = form.get(f"eff_{v.code}", "")
        if raw.strip():
            try:
                val = float(raw)
                if 0 < val < 100:
                    v.baseline_efficiency_kml = val
                    updated += 1
            except (ValueError, TypeError):
                pass
        else:
            # 空欄 → Noneに戻す（デフォルト値を使用）
            v.baseline_efficiency_kml = None
    db.commit()
    return RedirectResponse(url=f"/settings?profile_saved={updated}", status_code=303)
