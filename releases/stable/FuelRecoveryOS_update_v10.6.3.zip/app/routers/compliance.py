"""物流関連二法 統合ページ。

荷待/荷役時間 (loading_time) と 作業時間 (work_time) を1画面のタブUIに集約する。
データ集計は既存の app.services.{loading_time, work_time} をそのまま再利用。
"""
from __future__ import annotations

from datetime import date, datetime

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.routers.month_utils import resolve_base_month, month_last_day, month_context
from app.services import loading_time as loading_time_svc
from app.services import work_time as work_time_svc

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


def _resolve_period(
    db: Session, request: Request, start: str | None, end: str | None
) -> tuple[date, date]:
    if start and end:
        try:
            s = datetime.strptime(start, "%Y-%m-%d").date()
            e = datetime.strptime(end, "%Y-%m-%d").date()
            if s <= e:
                return s, e
        except ValueError:
            pass
    base = resolve_base_month(db, request.cookies.get("base_month"))
    return base, month_last_day(base)


@router.get("/compliance")
async def compliance_index():
    """デフォルトで荷待ち/荷役タブを開く。"""
    return RedirectResponse(url="/compliance/loading-time", status_code=302)


@router.get("/compliance/loading-time")
async def compliance_loading_time(
    request: Request,
    db: Session = Depends(get_db),
    start: str | None = Query(None),
    end: str | None = Query(None),
):
    s, e = _resolve_period(db, request, start, end)
    rows = loading_time_svc.aggregate(db, s, e)
    return templates.TemplateResponse("compliance.html", {
        "request": request,
        "current_page": "compliance",
        "active_tab": "loading",
        "period_start": s,
        "period_end": e,
        "custom_period": bool(start and end),
        "rows": rows,
        "totals": {
            "visit_count": sum(r["visit_count"] for r in rows),
            "work_total_sec": sum(r["work_total_sec"] for r in rows),
            "wait_total_sec": sum(r["wait_total_sec"] for r in rows),
            "stay_total_sec": sum(r["stay_total_sec"] for r in rows),
        },
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("/compliance/work-time")
async def compliance_work_time(
    request: Request,
    db: Session = Depends(get_db),
    by: str | None = Query(None),
    start: str | None = Query(None),
    end: str | None = Query(None),
):
    s, e = _resolve_period(db, request, start, end)
    by_kind = "vehicle" if by == "vehicle" else "driver"
    rows = work_time_svc.aggregate(db, s, e, by=by_kind)
    return templates.TemplateResponse("compliance.html", {
        "request": request,
        "current_page": "compliance",
        "active_tab": "work",
        "period_start": s,
        "period_end": e,
        "custom_period": bool(start and end),
        "by_kind": by_kind,
        "rows": rows,
        **month_context(db, request.cookies.get("base_month")),
    })
