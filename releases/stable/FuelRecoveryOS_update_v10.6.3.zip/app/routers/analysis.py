"""Analysis router — 詳細分析ページ群（Ver.3.0）
Phase 1: 急操作詳細分析
Phase 2: 速度・回転数・省エネ分析
Phase 3: 積載率・実車率分析
"""
from datetime import date, timedelta
from collections import defaultdict
from dateutil.relativedelta import relativedelta

from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from fastapi import Query
from app.dependencies import get_db
from app.models.csv_import import TripReport, DeliveryDetail, TripTimeseries
from app.models.system import SystemSetting
from app.routers.month_utils import resolve_base_month, month_last_day, month_context

router = APIRouter(prefix="/analysis")
templates = Jinja2Templates(directory="app/templates")


def _month_range(base: date, months_back: int = 0):
    """Return (start, end) for a month relative to base month."""
    d = base.replace(day=1) - relativedelta(months=months_back)
    if months_back == 0:
        return d, month_last_day(base)
    end = (d + relativedelta(months=1)) - timedelta(days=1)
    return d, end


# ═══════════════════════════════════════════════════
# Phase 1: 急操作詳細分析
# ═══════════════════════════════════════════════════
@router.get("/operations")
async def operations_analysis(request: Request, db: Session = Depends(get_db)):
    """急操作詳細分析ページ"""
    base = resolve_base_month(db, request.cookies.get("base_month"))
    # Current month data by driver
    m_start, m_end = _month_range(base, 0)
    trips = db.query(TripReport).filter(
        TripReport.operation_date >= m_start,
        TripReport.operation_date <= m_end,
    ).all()

    driver_data = defaultdict(lambda: {
        "name": "", "trips": 0, "dist_km": 0,
        "accel": 0, "decel": 0, "start": 0, "brake": 0, "turn": 0,
    })
    for t in trips:
        d = driver_data[t.driver_code]
        d["name"] = t.driver_name or t.driver_code
        d["trips"] += 1
        d["dist_km"] += (t.distance_m or 0) / 1000
        d["accel"] += t.sudden_accel_count or 0
        d["decel"] += t.sudden_decel_count or 0
        d["start"] += t.sudden_start_count or 0
        d["brake"] += t.sudden_brake_count or 0
        d["turn"] += t.sudden_turn_count or 0

    drivers = []
    for code, d in driver_data.items():
        dist = max(d["dist_km"], 0.1)
        total_ops = d["accel"] + d["decel"] + d["start"] + d["brake"] + d["turn"]
        drivers.append({
            "code": code, "name": d["name"], "trips": d["trips"],
            "dist_km": round(d["dist_km"], 1),
            "accel": d["accel"], "decel": d["decel"], "start": d["start"],
            "brake": d["brake"], "turn": d["turn"],
            "total": total_ops,
            "per_100km": round(total_ops / (dist / 100), 1),
            "accel_per_100km": round(d["accel"] / (dist / 100), 1),
            "decel_per_100km": round(d["decel"] / (dist / 100), 1),
            "start_per_100km": round(d["start"] / (dist / 100), 1),
            "brake_per_100km": round(d["brake"] / (dist / 100), 1),
            "turn_per_100km": round(d["turn"] / (dist / 100), 1),
        })
    drivers.sort(key=lambda x: x["per_100km"], reverse=True)

    # Monthly trend (6 months, company-wide)
    monthly_ops = []
    for i in range(5, -1, -1):
        ms, me = _month_range(base, i)
        mtrips = db.query(TripReport).filter(
            TripReport.operation_date >= ms, TripReport.operation_date <= me
        ).all()
        total_dist = sum((t.distance_m or 0) / 1000 for t in mtrips)
        total_accel = sum(t.sudden_accel_count or 0 for t in mtrips)
        total_decel = sum(t.sudden_decel_count or 0 for t in mtrips)
        total_start = sum(t.sudden_start_count or 0 for t in mtrips)
        total_brake = sum(t.sudden_brake_count or 0 for t in mtrips)
        total_turn = sum(t.sudden_turn_count or 0 for t in mtrips)
        d100 = max(total_dist / 100, 0.1)
        monthly_ops.append({
            "label": f"{ms.month}\u6708",
            "accel": round(total_accel / d100, 1),
            "decel": round(total_decel / d100, 1),
            "start": round(total_start / d100, 1),
            "brake": round(total_brake / d100, 1),
            "turn": round(total_turn / d100, 1),
            "total": round((total_accel + total_decel + total_start + total_brake + total_turn) / d100, 1),
        })

    # Company averages
    all_dist = sum(d["dist_km"] for d in driver_data.values())
    all_ops = sum(d["accel"] + d["decel"] + d["start"] + d["brake"] + d["turn"] for d in driver_data.values())
    avg_per_100km = round(all_ops / max(all_dist / 100, 0.1), 1)

    return templates.TemplateResponse("analysis_operations.html", {
        "request": request, "current_page": "operations", "today": base, "drivers": drivers,
        "monthly_ops": monthly_ops, "avg_per_100km": avg_per_100km,
        **month_context(db, request.cookies.get("base_month")),
    })


# ═══════════════════════════════════════════════════
# Phase 2: 速度・回転数・省エネ分析
# ═══════════════════════════════════════════════════
@router.get("/speed-rpm")
async def speed_rpm_analysis(request: Request, db: Session = Depends(get_db)):
    """速度・回転数・省エネ運転分析ページ"""
    base = resolve_base_month(db, request.cookies.get("base_month"))
    m_start, m_end = _month_range(base, 0)
    trips = db.query(TripReport).filter(
        TripReport.operation_date >= m_start, TripReport.operation_date <= m_end
    ).all()

    driver_data = defaultdict(lambda: {
        "name": "", "trips": 0, "dist_km": 0,
        "avg_speed_gen_sum": 0, "avg_speed_gen_cnt": 0,
        "avg_speed_hwy_sum": 0, "avg_speed_hwy_cnt": 0,
        "avg_speed_ded_sum": 0, "avg_speed_ded_cnt": 0,
        "max_rpm_gen_max": 0, "max_rpm_hwy_max": 0,
        "rpm_over_gen_count": 0, "rpm_over_hwy_count": 0,
        "rpm_over_total_sec": 0,
        "speed_over_gen_sec": 0, "speed_over_hwy_sec": 0,
        "crawl_sec": 0,
        "general_driving_sec": 0, "highway_driving_sec": 0,
        "economy_score_sum": 0, "economy_score_cnt": 0,
        "idle_sec": 0, "working_sec": 0,
    })

    for t in trips:
        d = driver_data[t.driver_code]
        d["name"] = t.driver_name or t.driver_code
        d["trips"] += 1
        d["dist_km"] += (t.distance_m or 0) / 1000
        if t.avg_speed_general and t.avg_speed_general > 0:
            d["avg_speed_gen_sum"] += t.avg_speed_general
            d["avg_speed_gen_cnt"] += 1
        if t.avg_speed_highway and t.avg_speed_highway > 0:
            d["avg_speed_hwy_sum"] += t.avg_speed_highway
            d["avg_speed_hwy_cnt"] += 1
        if t.avg_speed_dedicated and t.avg_speed_dedicated > 0:
            d["avg_speed_ded_sum"] += t.avg_speed_dedicated
            d["avg_speed_ded_cnt"] += 1
        d["max_rpm_gen_max"] = max(d["max_rpm_gen_max"], t.max_rpm_general or 0)
        d["max_rpm_hwy_max"] = max(d["max_rpm_hwy_max"], t.max_rpm_highway or 0)
        d["rpm_over_gen_count"] += t.rpm_over_general_count or 0
        d["rpm_over_hwy_count"] += t.rpm_over_highway_count or 0
        d["rpm_over_total_sec"] += (t.rpm_over_general_loaded_sec or 0) + (t.rpm_over_general_empty_sec or 0) + \
                                   (t.rpm_over_highway_loaded_sec or 0) + (t.rpm_over_highway_empty_sec or 0)
        d["speed_over_gen_sec"] += t.speed_over_general_sec or 0
        d["speed_over_hwy_sec"] += t.speed_over_highway_sec or 0
        d["crawl_sec"] += t.crawl_sec or 0
        d["general_driving_sec"] += t.general_driving_sec or 0
        d["highway_driving_sec"] += t.highway_driving_sec or 0
        if t.economy_score is not None:
            d["economy_score_sum"] += t.economy_score
            d["economy_score_cnt"] += 1
        d["idle_sec"] += t.idle_time_sec or 0
        d["working_sec"] += t.working_time_sec or 0

    drivers = []
    for code, d in driver_data.items():
        avg_gen = round(d["avg_speed_gen_sum"] / max(d["avg_speed_gen_cnt"], 1), 1)
        avg_hwy = round(d["avg_speed_hwy_sum"] / max(d["avg_speed_hwy_cnt"], 1), 1)
        avg_ded = round(d["avg_speed_ded_sum"] / max(d["avg_speed_ded_cnt"], 1), 1)
        total_driving = d["general_driving_sec"] + d["highway_driving_sec"]
        speed_over_total = d["speed_over_gen_sec"] + d["speed_over_hwy_sec"]
        # Constant speed rate estimate: driving - speed_over - crawl
        steady_sec = max(total_driving - speed_over_total - d["crawl_sec"], 0)
        steady_rate = round(steady_sec / max(total_driving, 1) * 100, 1)
        # General steady rate
        gen_over = d["speed_over_gen_sec"]
        gen_driving = max(d["general_driving_sec"], 1)
        gen_steady = round((gen_driving - gen_over) / gen_driving * 100, 1)
        # Highway steady rate
        hwy_over = d["speed_over_hwy_sec"]
        hwy_driving = max(d["highway_driving_sec"], 1)
        hwy_steady = round((hwy_driving - hwy_over) / hwy_driving * 100, 1)
        eco_score = round(d["economy_score_sum"] / max(d["economy_score_cnt"], 1), 1)
        idle_rate = round(d["idle_sec"] / max(d["working_sec"], 1) * 100, 1)

        drivers.append({
            "code": code, "name": d["name"], "trips": d["trips"],
            "dist_km": round(d["dist_km"], 1),
            "avg_speed_general": avg_gen, "avg_speed_highway": avg_hwy, "avg_speed_dedicated": avg_ded,
            "max_rpm_general": d["max_rpm_gen_max"], "max_rpm_highway": d["max_rpm_hwy_max"],
            "rpm_over_count": d["rpm_over_gen_count"] + d["rpm_over_hwy_count"],
            "rpm_over_min": round(d["rpm_over_total_sec"] / 60, 1),
            "steady_rate": steady_rate,
            "gen_steady_rate": gen_steady, "hwy_steady_rate": hwy_steady,
            "economy_score": eco_score, "idle_rate": idle_rate,
        })
    drivers.sort(key=lambda x: x["economy_score"])

    return templates.TemplateResponse("analysis_speed_rpm.html", {
        "request": request, "current_page": "speed_rpm", "today": base, "drivers": drivers,
        **month_context(db, request.cookies.get("base_month")),
    })


# ═══════════════════════════════════════════════════
# Phase 3: 積載率・実車率分析
# ═══════════════════════════════════════════════════
@router.get("/efficiency")
async def efficiency_analysis(request: Request, db: Session = Depends(get_db)):
    """積載率・実車率分析ページ"""
    base = resolve_base_month(db, request.cookies.get("base_month"))
    m_start, m_end = _month_range(base, 0)
    trips = db.query(TripReport).filter(
        TripReport.operation_date >= m_start, TripReport.operation_date <= m_end
    ).all()

    # Get delivery details for weight data
    report_numbers = [t.report_number for t in trips]
    details = []
    if report_numbers:
        # Query in batches to avoid SQLite limits
        for i in range(0, len(report_numbers), 500):
            batch = report_numbers[i:i+500]
            details.extend(
                db.query(DeliveryDetail).filter(
                    DeliveryDetail.report_number.in_(batch)
                ).all()
            )

    # Aggregate weight by report
    report_weights = defaultdict(float)
    for det in details:
        if det.total_weight and det.total_weight > 0:
            report_weights[det.report_number] = max(report_weights[det.report_number], det.total_weight)

    driver_data = defaultdict(lambda: {
        "name": "", "trips": 0,
        "loaded_dist_m": 0, "empty_dist_m": 0, "total_dist_m": 0,
        "loaded_time_sec": 0, "empty_time_sec": 0,
        "working_sec": 0, "ton_km": 0, "trips_with_weight": 0,
        "total_weight": 0,
    })

    for t in trips:
        d = driver_data[t.driver_code]
        d["name"] = t.driver_name or t.driver_code
        d["trips"] += 1
        loaded_m = (t.general_loaded_m or 0) + (t.highway_loaded_m or 0) + (t.dedicated_loaded_m or 0)
        empty_m = (t.general_empty_m or 0) + (t.highway_empty_m or 0) + (t.dedicated_empty_m or 0)
        d["loaded_dist_m"] += loaded_m
        d["empty_dist_m"] += empty_m
        d["total_dist_m"] += t.distance_m or 0
        d["loaded_time_sec"] += t.loaded_time_sec or 0
        d["empty_time_sec"] += t.empty_time_sec or 0
        d["working_sec"] += t.working_time_sec or 0
        # Ton-km calculation
        weight = report_weights.get(t.report_number, 0)
        if weight > 0:
            d["ton_km"] += weight * (loaded_m / 1000)  # ton * km
            d["trips_with_weight"] += 1
            d["total_weight"] += weight

    drivers = []
    for code, d in driver_data.items():
        total_dist = max(d["total_dist_m"], 1)
        total_time = max(d["loaded_time_sec"] + d["empty_time_sec"], 1)
        # Distance-based loaded rate
        loaded_rate_dist = round(d["loaded_dist_m"] / total_dist * 100, 1)
        # Time-based loaded rate
        loaded_rate_time = round(d["loaded_time_sec"] / total_time * 100, 1)
        # Empty return ratio
        empty_ratio = round(d["empty_dist_m"] / total_dist * 100, 1)

        drivers.append({
            "code": code, "name": d["name"], "trips": d["trips"],
            "dist_km": round(d["total_dist_m"] / 1000, 1),
            "loaded_km": round(d["loaded_dist_m"] / 1000, 1),
            "empty_km": round(d["empty_dist_m"] / 1000, 1),
            "loaded_rate_dist": loaded_rate_dist,
            "loaded_rate_time": loaded_rate_time,
            "empty_ratio": empty_ratio,
            "ton_km": round(d["ton_km"], 1),
            "trips_with_weight": d["trips_with_weight"],
            "avg_weight": round(d["total_weight"] / max(d["trips_with_weight"], 1), 2),
        })
    drivers.sort(key=lambda x: x["loaded_rate_dist"])

    # Company totals
    total_loaded = sum(d["loaded_dist_m"] for d in driver_data.values())
    total_empty = sum(d["empty_dist_m"] for d in driver_data.values())
    total_all = max(total_loaded + total_empty, 1)
    total_ton_km = sum(d["ton_km"] for d in driver_data.values())
    company_loaded_rate = round(total_loaded / total_all * 100, 1)
    company_empty_ratio = round(total_empty / total_all * 100, 1)

    return templates.TemplateResponse("analysis_efficiency.html", {
        "request": request, "current_page": "efficiency", "today": base, "drivers": drivers,
        "company_loaded_rate": company_loaded_rate,
        "company_empty_ratio": company_empty_ratio,
        "total_ton_km": round(total_ton_km, 1),
        **month_context(db, request.cookies.get("base_month")),
    })


# ═══════════════════════════════════════════════════
# Phase 4: 速度×回転数 散布図（ギヤ効率マップ）
# ═══════════════════════════════════════════════════
_MAX_SCATTER_POINTS = 3000   # 散布図の最大プロット点数
_RPM_ECO_MAX = 1600          # エコゾーン上限 rpm
_RPM_WARN_MAX = 2000         # 警戒ゾーン上限 rpm


@router.get("/gear-map")
async def gear_map_analysis(
    request: Request,
    db: Session = Depends(get_db),
    driver_code: str = Query(default=""),
    vehicle_code: str = Query(default=""),
):
    """速度×回転数 散布図（ギヤ効率マップ）ページ"""
    base = resolve_base_month(db, request.cookies.get("base_month"))
    m_start, m_end = _month_range(base, 0)

    # ── フィルタ対象の日報番号を取得 ──────────────────────────────────────
    trip_q = db.query(TripReport.report_number, TripReport.driver_code,
                      TripReport.driver_name, TripReport.vehicle_code,
                      TripReport.vehicle_name).filter(
        TripReport.operation_date >= m_start,
        TripReport.operation_date <= m_end,
    )
    if driver_code:
        trip_q = trip_q.filter(TripReport.driver_code == driver_code)
    if vehicle_code:
        trip_q = trip_q.filter(TripReport.vehicle_code == vehicle_code)

    trip_rows = trip_q.all()

    # 絞り込み用マスタ（月内の全ドライバー・車両）
    all_trips_q = db.query(TripReport.driver_code, TripReport.driver_name,
                           TripReport.vehicle_code, TripReport.vehicle_name).filter(
        TripReport.operation_date >= m_start,
        TripReport.operation_date <= m_end,
    ).distinct().all()
    all_drivers = sorted(
        {(r.driver_code, r.driver_name or r.driver_code) for r in all_trips_q},
        key=lambda x: x[1],
    )
    all_vehicles = sorted(
        {(r.vehicle_code, r.vehicle_name or r.vehicle_code) for r in all_trips_q},
        key=lambda x: x[1],
    )

    # report_number → driver/vehicle メタ
    meta = {r.report_number: {
        "driver_code": r.driver_code,
        "driver_name": r.driver_name or r.driver_code,
        "vehicle_code": r.vehicle_code,
        "vehicle_name": r.vehicle_name or r.vehicle_code,
    } for r in trip_rows}

    report_numbers = list(meta.keys())

    # ── TripTimeseries を取得 ────────────────────────────────────────────
    ts_points: list[tuple[int, int, str, str]] = []  # (speed, rpm, driver_name, vehicle_name)
    if report_numbers:
        for i in range(0, len(report_numbers), 500):
            batch = report_numbers[i:i+500]
            rows = db.query(
                TripTimeseries.speed_kmh,
                TripTimeseries.engine_rpm,
                TripTimeseries.report_number,
            ).filter(
                TripTimeseries.report_number.in_(batch),
                TripTimeseries.speed_kmh > 0,
            ).all()
            for r in rows:
                m = meta.get(r.report_number, {})
                ts_points.append((
                    r.speed_kmh,
                    r.engine_rpm or 0,
                    m.get("driver_name", ""),
                    m.get("vehicle_name", ""),
                ))

    # ── rpm=0 のデータ（RPM未対応車両）を除いて散布図用データ生成 ─────────
    rpm_points = [(s, r, dn, vn) for s, r, dn, vn in ts_points if r > 0]
    has_rpm_data = len(rpm_points) > 0

    # サンプリング（多すぎる場合は間引き）
    if len(rpm_points) > _MAX_SCATTER_POINTS:
        step = len(rpm_points) // _MAX_SCATTER_POINTS
        rpm_points = rpm_points[::step]

    # RPMゾーン別に分類
    eco, warn, danger = [], [], []
    for speed, rpm, driver_name, vehicle_name in rpm_points:
        point = {"x": speed, "y": rpm, "label": driver_name or vehicle_name}
        if rpm <= _RPM_ECO_MAX:
            eco.append(point)
        elif rpm <= _RPM_WARN_MAX:
            warn.append(point)
        else:
            danger.append(point)

    # ── 統計 ────────────────────────────────────────────────────────────
    total_rpm_pts = len(eco) + len(warn) + len(danger)
    eco_rate = round(len(eco) / max(total_rpm_pts, 1) * 100, 1)
    warn_rate = round(len(warn) / max(total_rpm_pts, 1) * 100, 1)
    danger_rate = round(len(danger) / max(total_rpm_pts, 1) * 100, 1)

    # 速度データの統計（RPM非対応車両も含む全データ）
    total_pts = len(ts_points)
    avg_speed = round(sum(s for s, *_ in ts_points) / max(total_pts, 1), 1)
    avg_rpm = round(sum(r for _, r, *_ in ts_points if r > 0) / max(len(rpm_points), 1), 1) if rpm_points else 0

    return templates.TemplateResponse("analysis_gear_map.html", {
        "request": request,
        "current_page": "gear_map",
        "today": base,
        "selected_driver": driver_code,
        "selected_vehicle": vehicle_code,
        "all_drivers": all_drivers,
        "all_vehicles": all_vehicles,
        "eco_points": eco,
        "warn_points": warn,
        "danger_points": danger,
        "has_rpm_data": has_rpm_data,
        "total_points": total_pts,
        "total_rpm_points": total_rpm_pts,
        "eco_rate": eco_rate,
        "warn_rate": warn_rate,
        "danger_rate": danger_rate,
        "avg_speed": avg_speed,
        "avg_rpm": avg_rpm,
        "rpm_eco_max": _RPM_ECO_MAX,
        "rpm_warn_max": _RPM_WARN_MAX,
        **month_context(db, request.cookies.get("base_month")),
    })
