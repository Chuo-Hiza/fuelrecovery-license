"""Shipper evidence router — 荷主交渉エビデンス。"""
from datetime import date

from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.operations import ShipperWaitSummary
from app.routers.month_utils import month_context

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@router.get("/shipper")
async def shipper_list(request: Request, db: Session = Depends(get_db)):
    month_str = "2026-03"
    shippers = db.query(ShipperWaitSummary).filter(
        ShipperWaitSummary.month == month_str,
    ).order_by(ShipperWaitSummary.total_impact_yen.desc()).all()

    return templates.TemplateResponse("shipper.html", {
        "request": request,
        "current_page": "shipper",
        "month_str": "2026年3月",
        "shippers": shippers,
        **month_context(db, request.cookies.get("base_month")),
    })
