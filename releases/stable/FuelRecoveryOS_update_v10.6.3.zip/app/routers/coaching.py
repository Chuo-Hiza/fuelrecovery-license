"""Driver coaching card router — ドライバー面談カード。
月次トレンド分析 + 改善目標管理機能付き（Ver2.0）。
Estra-WEB2 データベース対応。
"""
from datetime import date, datetime, timedelta
from collections import defaultdict
from dateutil.relativedelta import relativedelta

from fastapi import APIRouter, Depends, Request, Form
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.dependencies import get_db
from app.models.csv_import import TripReport
from app.models.operations import ImprovementGoal, DriverCoachingCard
from app.routers.month_utils import resolve_base_month, month_last_day, prev_month_range, month_context

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# Default improvement target rate
DEFAULT_TARGET_RATE = 20  # 20% improvement


def get_driver_stats(trips):
    if not trips:
        return None
    total_dist_km = sum((t.distance_m or 0) / 1000 for t in trips)
    total_idle_sec = sum(t.idle_time_sec or 0 for t in trips)
    total_working_sec = sum(t.working_time_sec or 0 for t in trips)
    total_accel = sum(t.sudden_accel_count or 0 for t in trips)
    total_decel = sum(t.sudden_decel_count or 0 for t in trips)
    total_start = sum(t.sudden_start_count or 0 for t in trips)
    total_speed_over = sum((t.speed_over_general_count or 0) + (t.speed_over_highway_count or 0) for t in trips)
    total_rpm_over = sum((t.rpm_over_general_count or 0) + (t.rpm_over_highway_count or 0) for t in trips)
    scores = [t.overall_score for t in trips if t.overall_score is not None]
    safety_scores = [t.safety_score for t in trips if t.safety_score is not None]
    economy_scores = [t.economy_score for t in trips if t.economy_score is not None]
    avg_score = sum(scores) / len(scores) if scores else 0
    avg_safety = sum(safety_scores) / len(safety_scores) if safety_scores else 0
    avg_economy = sum(economy_scores) / len(economy_scores) if economy_scores else 0
    idle_rate = round(total_idle_sec / max(total_working_sec, 1) * 100, 1)
    return {
        "trips": len(trips), "dist_km": round(total_dist_km, 1),
        "avg_score": round(avg_score, 1), "avg_safety": round(avg_safety, 1),
        "avg_economy": round(avg_economy, 1), "idle_rate": idle_rate,
        "sudden_accel": total_accel, "sudden_decel": total_decel,
        "sudden_start": total_start, "speed_over": total_speed_over,
        "rpm_over": total_rpm_over,
        "events_per_100km": round((total_accel + total_decel + total_start) / max(total_dist_km / 100, 0.1), 1),
    }


def get_monthly_trend(db: Session, driver_code: str, months: int = 6, base_date: date = None):
    """Get monthly trend data for the past N months."""
    if base_date is None:
        base_date = date(2026, 3, 1)
    today = month_last_day(base_date)
    trend = []
    for i in range(months - 1, -1, -1):
        m_start = (base_date.replace(day=1) - relativedelta(months=i))
        if i == 0:
            m_end = today
        else:
            m_end = (m_start + relativedelta(months=1)) - timedelta(days=1)
        trips = db.query(TripReport).filter(
            TripReport.driver_code == driver_code,
            TripReport.operation_date >= m_start,
            TripReport.operation_date <= m_end,
        ).all()
        stats = get_driver_stats(trips)
        if stats and stats["trips"] > 0:
            trend.append({
                "month": m_start.strftime("%Y-%m"),
                "month_label": f"{m_start.month}\u6708",
                **stats
            })
        else:
            trend.append({
                "month": m_start.strftime("%Y-%m"),
                "month_label": f"{m_start.month}\u6708",
                "trips": 0, "dist_km": 0,
                "avg_score": None, "avg_safety": None, "avg_economy": None,
                "idle_rate": None, "events_per_100km": None,
                "sudden_accel": 0, "sudden_decel": 0, "sudden_start": 0,
                "speed_over": 0, "rpm_over": 0,
            })
    return trend


def calc_trend_direction(values):
    """Determine trend direction from recent values: up/down/flat."""
    valid = [v for v in values if v is not None]
    if len(valid) < 2:
        return "flat"
    recent = valid[-1]
    prev = valid[-2]
    diff_pct = ((recent - prev) / max(abs(prev), 0.01)) * 100
    if diff_pct > 3:
        return "up"
    elif diff_pct < -3:
        return "down"
    return "flat"


def build_goal_metrics(this_stats, peer_stats, target_rate_pct):
    """Build goal metrics with current values, targets, and peer averages."""
    rate = target_rate_pct / 100.0
    metrics = []

    current = this_stats["avg_score"]
    target_val = round(min(current * (1 + rate), 100), 1)
    metrics.append({
        "key": "avg_score", "name": "\u7dcf\u5408\u8a55\u4fa1\u70b9",
        "current": current, "target": target_val,
        "peer": peer_stats["avg_score"] if peer_stats else None,
        "unit": "\u70b9", "direction": "higher_better",
    })

    current = this_stats["avg_safety"]
    target_val = round(min(current * (1 + rate), 100), 1)
    metrics.append({
        "key": "avg_safety", "name": "\u5b89\u5168\u8a55\u4fa1\u70b9",
        "current": current, "target": target_val,
        "peer": peer_stats["avg_safety"] if peer_stats else None,
        "unit": "\u70b9", "direction": "higher_better",
    })

    current = this_stats["avg_economy"]
    target_val = round(min(current * (1 + rate), 100), 1)
    metrics.append({
        "key": "avg_economy", "name": "\u7d4c\u6e08\u8a55\u4fa1\u70b9",
        "current": current, "target": target_val,
        "peer": peer_stats["avg_economy"] if peer_stats else None,
        "unit": "\u70b9", "direction": "higher_better",
    })

    current = this_stats["idle_rate"]
    target_val = round(max(current * (1 - rate), 0), 1)
    metrics.append({
        "key": "idle_rate", "name": "\u30a2\u30a4\u30c9\u30ea\u30f3\u30b0\u7387",
        "current": current, "target": target_val,
        "peer": peer_stats["idle_rate"] if peer_stats else None,
        "unit": "%", "direction": "lower_better",
    })

    current = this_stats["events_per_100km"]
    target_val = round(max(current * (1 - rate), 0), 1)
    metrics.append({
        "key": "events_per_100km", "name": "\u6025\u64cd\u4f5c/100km",
        "current": current, "target": target_val,
        "peer": peer_stats["events_per_100km"] if peer_stats else None,
        "unit": "\u56de", "direction": "lower_better",
    })

    current = this_stats["speed_over"]
    target_val = max(round(current * (1 - rate)), 0)
    metrics.append({
        "key": "speed_over", "name": "\u901f\u5ea6\u8d85\u904e",
        "current": current, "target": target_val,
        "peer": peer_stats.get("speed_over", None) if peer_stats else None,
        "unit": "\u56de", "direction": "lower_better",
    })

    return metrics


@router.get("/coaching")
async def coaching_list(request: Request, db: Session = Depends(get_db)):
    base = resolve_base_month(db, request.cookies.get("base_month"))
    today = month_last_day(base)
    month_start = base
    prev_start, prev_end = prev_month_range(base)
    trips = db.query(TripReport).filter(
        TripReport.operation_date >= month_start,
        TripReport.operation_date <= today,
    ).all()
    driver_trips = defaultdict(list)
    for t in trips:
        driver_trips[t.driver_code].append(t)
    drivers = []
    for code, dtrips in sorted(driver_trips.items()):
        stats = get_driver_stats(dtrips)
        if stats:
            # Get previous month for trend arrow
            prev_trips = db.query(TripReport).filter(
                TripReport.driver_code == code,
                TripReport.operation_date >= prev_start,
                TripReport.operation_date <= prev_end,
            ).all()
            prev_stats = get_driver_stats(prev_trips)
            score_trend = "flat"
            if prev_stats and prev_stats["avg_score"] > 0:
                diff = stats["avg_score"] - prev_stats["avg_score"]
                if diff > 2:
                    score_trend = "up"
                elif diff < -2:
                    score_trend = "down"
            drivers.append({"code": code, "name": dtrips[0].driver_name,
                            "org": dtrips[0].driver_org_name or "",
                            "score_trend": score_trend, **stats})
    drivers.sort(key=lambda d: d["avg_score"])

    from app.routers.settings_router import get_criteria
    criteria = get_criteria(db)

    return templates.TemplateResponse("coaching_list.html", {
        "request": request, "current_page": "coaching", "today": today,
        "drivers": drivers, "criteria": criteria,
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("/coaching/batch_print")
async def coaching_batch_print(request: Request, codes: str = "", db: Session = Depends(get_db)):
    """複数ドライバーの指導書を1ファイルにまとめて印刷。"""
    from app.models.csv_import import DeliveryDetail
    base = resolve_base_month(db, request.cookies.get("base_month"))
    today = month_last_day(base)
    prev_start, prev_end = prev_month_range(base)
    code_list = [c.strip() for c in codes.split(",") if c.strip()]
    drivers_data = []

    for driver_code in code_list:
        # ── Card data ──
        this_month_start = base
        this_trips = db.query(TripReport).filter(
            TripReport.driver_code == driver_code,
            TripReport.operation_date >= this_month_start,
            TripReport.operation_date <= today,
        ).order_by(TripReport.operation_date).all()
        last_trips = db.query(TripReport).filter(
            TripReport.driver_code == driver_code,
            TripReport.operation_date >= prev_start,
            TripReport.operation_date <= prev_end,
        ).all()
        all_this_month = db.query(TripReport).filter(
            TripReport.operation_date >= this_month_start,
            TripReport.operation_date <= today,
        ).all()
        peer_stats = get_driver_stats(all_this_month)
        this_stats = get_driver_stats(this_trips) or {
            "trips": 0, "dist_km": 0, "avg_score": 0, "avg_safety": 0,
            "avg_economy": 0, "idle_rate": 0, "sudden_accel": 0, "sudden_decel": 0,
            "sudden_start": 0, "speed_over": 0, "rpm_over": 0, "events_per_100km": 0}
        last_stats = get_driver_stats(last_trips) or dict(this_stats)
        driver_name = this_trips[0].driver_name if this_trips else driver_code
        vehicle_name = this_trips[0].vehicle_name if this_trips else ""

        good_points, improve_points = [], []
        if last_stats["idle_rate"] > 0 and this_stats["idle_rate"] < last_stats["idle_rate"]:
            good_points.append(f"アイドリング率が先月比 ▲{round(last_stats['idle_rate'] - this_stats['idle_rate'], 1)}pt 改善")
        if last_stats["sudden_accel"] > 0 and this_stats["sudden_accel"] < last_stats["sudden_accel"]:
            good_points.append(f"急加速回数が先月比 ▲{round((1 - this_stats['sudden_accel'] / max(last_stats['sudden_accel'], 1)) * 100)}% 減少")
        if this_stats["avg_score"] > last_stats["avg_score"]:
            good_points.append(f"総合評価点が先月比 +{round(this_stats['avg_score'] - last_stats['avg_score'], 1)}pt 向上")
        if this_stats["speed_over"] == 0 and this_stats["trips"] > 0:
            good_points.append("速度超過ゼロを維持")
        if not good_points:
            good_points.append("安定した運行を継続中")
        if peer_stats:
            if this_stats["events_per_100km"] > peer_stats["events_per_100km"] * 1.2:
                improve_points.append(f"急操作回数が全社平均の {round(this_stats['events_per_100km'] / max(peer_stats['events_per_100km'], 0.1), 1)}倍")
            if this_stats["idle_rate"] > peer_stats["idle_rate"] + 3:
                improve_points.append(f"アイドリング率 {this_stats['idle_rate']}%（全社平均 {peer_stats['idle_rate']}%）")
            if this_stats["speed_over"] > 5:
                improve_points.append(f"速度超過 {this_stats['speed_over']}回 → 巡航速度改善が必要")
        if not improve_points:
            improve_points.append("特記事項なし — 良好")

        # ── Map data (3ヶ月) ──
        months = 3
        range_start = today.replace(day=1) - relativedelta(months=months - 1)
        stops_q = (
            db.query(DeliveryDetail, TripReport)
            .join(TripReport, DeliveryDetail.report_number == TripReport.report_number)
            .filter(
                TripReport.driver_code == driver_code,
                TripReport.operation_date >= range_start,
                TripReport.operation_date <= today,
                DeliveryDetail.gps_lat.isnot(None),
                DeliveryDetail.gps_lat != 0,
            ).all()
        )
        location_stats = defaultdict(lambda: {
            "lat": 0, "lon": 0, "idle_total_sec": 0, "stop_total_sec": 0,
            "visit_count": 0, "address": "", "work_types": set(), "dates": set(),
        })
        for dd, tr in stops_q:
            lat = dd.gps_lat / 100000.0
            lon = dd.gps_lon / 100000.0
            grid_key = (round(lat, 3), round(lon, 3))
            ls = location_stats[grid_key]
            ls["lat"] = lat; ls["lon"] = lon
            ls["idle_total_sec"] += dd.idle_time_sec or 0
            ls["stop_total_sec"] += dd.stop_time_sec or 0
            ls["visit_count"] += 1
            if dd.address: ls["address"] = dd.address
            if dd.work_type: ls["work_types"].add(dd.work_type)
            ls["dates"].add(tr.operation_date.strftime("%m/%d"))

        trip_events_map = defaultdict(lambda: {"accel": 0, "decel": 0, "start": 0, "speed_over": 0})
        trips_q = db.query(TripReport).filter(
            TripReport.driver_code == driver_code,
            TripReport.operation_date >= range_start,
            TripReport.operation_date <= today,
        ).all()
        for tr in trips_q:
            te = trip_events_map[tr.report_number]
            te["accel"] += tr.sudden_accel_count or 0
            te["decel"] += tr.sudden_decel_count or 0
            te["start"] += tr.sudden_start_count or 0
            te["speed_over"] += (tr.speed_over_general_count or 0) + (tr.speed_over_highway_count or 0)

        trip_reports_with_stops = defaultdict(list)
        for dd, tr in stops_q:
            trip_reports_with_stops[tr.report_number].append({
                "lat": dd.gps_lat / 100000.0, "lon": dd.gps_lon / 100000.0,
                "seq": dd.detail_number or 0,
            })
        routes = []
        for rn, points in trip_reports_with_stops.items():
            points.sort(key=lambda p: p["seq"])
            te = trip_events_map.get(rn, {})
            total_events = te.get("accel", 0) + te.get("decel", 0) + te.get("start", 0)
            routes.append({
                "points": [{"lat": p["lat"], "lon": p["lon"]} for p in points],
                "events": total_events, "speed_over": te.get("speed_over", 0),
            })

        markers = []
        for grid_key, ls in location_stats.items():
            avg_idle = ls["idle_total_sec"] / max(ls["visit_count"], 1)
            if avg_idle > 300: marker_type, color = "idle_high", "red"
            elif avg_idle > 120: marker_type, color = "idle_mid", "orange"
            elif ls["stop_total_sec"] / max(ls["visit_count"], 1) > 3600: marker_type, color = "long_stop", "blue"
            else: marker_type, color = "normal", "green"
            markers.append({
                "lat": ls["lat"], "lon": ls["lon"], "address": ls["address"],
                "visit_count": ls["visit_count"],
                "avg_idle_min": round(avg_idle / 60, 1),
                "total_idle_min": round(ls["idle_total_sec"] / 60, 1),
                "avg_stop_min": round(ls["stop_total_sec"] / max(ls["visit_count"], 1) / 60, 1),
                "work_types": list(ls["work_types"]),
                "dates_sample": sorted(ls["dates"])[:5],
                "marker_type": marker_type, "color": color,
            })
        markers.sort(key=lambda m: m["avg_idle_min"], reverse=True)

        high_idle_count = len([m for m in markers if m["marker_type"] == "idle_high"])
        total_events_sum = sum(te["accel"] + te["decel"] + te["start"] for te in trip_events_map.values())
        summary = {
            "trip_count": len(trips_q), "total_stops": len(markers),
            "high_idle_count": high_idle_count,
            "total_idle_min": round(sum(m["total_idle_min"] for m in markers), 1),
            "total_events": total_events_sum, "months": months,
        }
        if markers:
            center_lat = sum(m["lat"] for m in markers) / len(markers)
            center_lon = sum(m["lon"] for m in markers) / len(markers)
        else:
            center_lat, center_lon = 35.68, 139.76

        drivers_data.append({
            "driver_code": driver_code,
            "driver_name": driver_name,
            "vehicle_name": vehicle_name,
            "today": today,
            "this_stats": this_stats,
            "last_stats": last_stats,
            "peer_stats": peer_stats,
            "good_points": good_points[:3],
            "improve_points": improve_points[:3],
            "markers": markers,
            "routes": routes,
            "center_lat": center_lat,
            "center_lon": center_lon,
            "summary": summary,
            "months": months,
        })

    return templates.TemplateResponse("coaching_batch_print.html", {
        "request": request,
        "drivers_data": drivers_data,
        "today": today,
    })


@router.get("/coaching/{driver_code}")
async def coaching_card(request: Request, driver_code: str,
                        target_rate: int = DEFAULT_TARGET_RATE,
                        db: Session = Depends(get_db)):
    base = resolve_base_month(db, request.cookies.get("base_month"))
    today = month_last_day(base)
    this_month_start = base
    prev_start, prev_end = prev_month_range(base)
    this_trips = db.query(TripReport).filter(
        TripReport.driver_code == driver_code,
        TripReport.operation_date >= this_month_start,
        TripReport.operation_date <= today,
    ).order_by(TripReport.operation_date).all()
    last_trips = db.query(TripReport).filter(
        TripReport.driver_code == driver_code,
        TripReport.operation_date >= prev_start,
        TripReport.operation_date <= prev_end,
    ).all()
    all_this_month = db.query(TripReport).filter(
        TripReport.operation_date >= this_month_start,
        TripReport.operation_date <= today,
    ).all()
    peer_stats = get_driver_stats(all_this_month)
    this_stats = get_driver_stats(this_trips) or {
        "trips": 0, "dist_km": 0, "avg_score": 0, "avg_safety": 0,
        "avg_economy": 0, "idle_rate": 0, "sudden_accel": 0, "sudden_decel": 0,
        "sudden_start": 0, "speed_over": 0, "rpm_over": 0, "events_per_100km": 0}
    last_stats = get_driver_stats(last_trips) or dict(this_stats)
    driver_name = this_trips[0].driver_name if this_trips else driver_code
    vehicle_name = this_trips[0].vehicle_name if this_trips else ""

    # === Monthly trend (6 months) ===
    monthly_trend = get_monthly_trend(db, driver_code, 6, base_date=base)

    # Trend directions
    trends = {
        "score": calc_trend_direction([m["avg_score"] for m in monthly_trend]),
        "safety": calc_trend_direction([m["avg_safety"] for m in monthly_trend]),
        "economy": calc_trend_direction([m["avg_economy"] for m in monthly_trend]),
        "idle": calc_trend_direction([m["idle_rate"] for m in monthly_trend]),
        "events": calc_trend_direction([m["events_per_100km"] for m in monthly_trend]),
    }
    # For idle and events, "down" is good
    for key in ["idle", "events"]:
        if trends[key] == "up":
            trends[key] = "bad_up"
        elif trends[key] == "down":
            trends[key] = "good_down"

    # === Good/Improve points ===
    good_points, improve_points = [], []
    if last_stats["idle_rate"] > 0 and this_stats["idle_rate"] < last_stats["idle_rate"]:
        good_points.append(f"\u30a2\u30a4\u30c9\u30ea\u30f3\u30b0\u7387\u304c\u5148\u6708\u6bd4 \u25b2{round(last_stats['idle_rate'] - this_stats['idle_rate'], 1)}pt \u6539\u5584")
    if last_stats["sudden_accel"] > 0 and this_stats["sudden_accel"] < last_stats["sudden_accel"]:
        good_points.append(f"\u6025\u52a0\u901f\u56de\u6570\u304c\u5148\u6708\u6bd4 \u25b2{round((1 - this_stats['sudden_accel'] / max(last_stats['sudden_accel'], 1)) * 100)}% \u6e1b\u5c11")
    if this_stats["avg_score"] > last_stats["avg_score"]:
        good_points.append(f"\u7dcf\u5408\u8a55\u4fa1\u70b9\u304c\u5148\u6708\u6bd4 +{round(this_stats['avg_score'] - last_stats['avg_score'], 1)}pt \u5411\u4e0a")
    if this_stats["speed_over"] == 0 and this_stats["trips"] > 0:
        good_points.append("\u901f\u5ea6\u8d85\u904e\u30bc\u30ed\u3092\u7dad\u6301")
    if not good_points:
        good_points.append("\u5b89\u5b9a\u3057\u305f\u904b\u884c\u3092\u7d99\u7d9a\u4e2d")

    if peer_stats:
        if this_stats["events_per_100km"] > peer_stats["events_per_100km"] * 1.2:
            improve_points.append(f"\u6025\u64cd\u4f5c\u56de\u6570\u304c\u5168\u793e\u5e73\u5747\u306e {round(this_stats['events_per_100km'] / max(peer_stats['events_per_100km'], 0.1), 1)}\u500d")
        if this_stats["idle_rate"] > peer_stats["idle_rate"] + 3:
            improve_points.append(f"\u30a2\u30a4\u30c9\u30ea\u30f3\u30b0\u7387 {this_stats['idle_rate']}%\uff08\u5168\u793e\u5e73\u5747 {peer_stats['idle_rate']}%\uff09")
        if this_stats["speed_over"] > 5:
            improve_points.append(f"\u901f\u5ea6\u8d85\u904e {this_stats['speed_over']}\u56de \u2192 \u5de1\u822a\u901f\u5ea6\u6539\u5584\u304c\u5fc5\u8981")
    if not improve_points:
        improve_points.append("\u7279\u8a18\u4e8b\u9805\u306a\u3057 \u2014 \u826f\u597d")

    trip_scores = [{"date": t.operation_date.strftime("%m/%d"), "score": t.overall_score or 0,
                     "dist_km": round((t.distance_m or 0) / 1000, 1)} for t in this_trips]

    # === Goal metrics ===
    goal_metrics = build_goal_metrics(this_stats, peer_stats, target_rate)

    # === Saved goals from DB ===
    saved_goals = db.query(ImprovementGoal).join(DriverCoachingCard).filter(
        DriverCoachingCard.driver_code == driver_code,
        DriverCoachingCard.month == today.strftime("%Y-%m"),
    ).all()
    saved_goal_map = {g.target_metric: {"target": g.target_value, "status": g.status} for g in saved_goals}

    return templates.TemplateResponse("coaching_card.html", {
        "request": request, "current_page": "coaching", "today": today, "driver_code": driver_code,
        "driver_name": driver_name, "vehicle_name": vehicle_name,
        "this_stats": this_stats, "last_stats": last_stats, "peer_stats": peer_stats,
        "good_points": good_points[:3], "improve_points": improve_points[:3],
        "trip_scores": trip_scores,
        "monthly_trend": monthly_trend,
        "trends": trends,
        "goal_metrics": goal_metrics,
        "target_rate": target_rate,
        "saved_goals": saved_goal_map,
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("/coaching/{driver_code}/map")
async def coaching_map(request: Request, driver_code: str,
                       months: int = 3, db: Session = Depends(get_db)):
    """ドライバー別 燃費改善マップ — 危険ポイント・アイドリングポイントをプロット."""
    base = resolve_base_month(db, request.cookies.get("base_month"))
    today = month_last_day(base)

    # Date range
    from dateutil.relativedelta import relativedelta
    range_start = base.replace(day=1) - relativedelta(months=months - 1)

    # Get driver name
    sample = db.query(TripReport).filter(
        TripReport.driver_code == driver_code
    ).first()
    driver_name = sample.driver_name if sample else driver_code

    # --- Delivery stop points with GPS ---
    from app.models.csv_import import DeliveryDetail
    stops_q = (
        db.query(DeliveryDetail, TripReport)
        .join(TripReport, DeliveryDetail.report_number == TripReport.report_number)
        .filter(
            TripReport.driver_code == driver_code,
            TripReport.operation_date >= range_start,
            TripReport.operation_date <= today,
            DeliveryDetail.gps_lat.isnot(None),
            DeliveryDetail.gps_lat != 0,
        )
        .all()
    )

    # Build map points
    map_points = []
    # Also aggregate location clusters for heatmap-like display
    location_stats = defaultdict(lambda: {
        "lat": 0, "lon": 0, "idle_total_sec": 0, "stop_total_sec": 0,
        "visit_count": 0, "address": "", "work_types": set(),
        "dates": set(),
    })

    for dd, tr in stops_q:
        lat = dd.gps_lat / 100000.0
        lon = dd.gps_lon / 100000.0

        # Cluster key: round to ~100m grid
        grid_key = (round(lat, 3), round(lon, 3))
        ls = location_stats[grid_key]
        ls["lat"] = lat
        ls["lon"] = lon
        ls["idle_total_sec"] += dd.idle_time_sec or 0
        ls["stop_total_sec"] += dd.stop_time_sec or 0
        ls["visit_count"] += 1
        if dd.address:
            ls["address"] = dd.address
        if dd.work_type:
            ls["work_types"].add(dd.work_type)
        ls["dates"].add(tr.operation_date.strftime("%m/%d"))

    # Build per-trip event info (events happen on routes between stops)
    trip_events_map = defaultdict(lambda: {
        "accel": 0, "decel": 0, "start": 0, "speed_over": 0,
        "rpm_over": 0, "idle_sec": 0, "stops": [],
    })
    trips_q = db.query(TripReport).filter(
        TripReport.driver_code == driver_code,
        TripReport.operation_date >= range_start,
        TripReport.operation_date <= today,
    ).all()

    for tr in trips_q:
        te = trip_events_map[tr.report_number]
        te["accel"] += tr.sudden_accel_count or 0
        te["decel"] += tr.sudden_decel_count or 0
        te["start"] += tr.sudden_start_count or 0
        te["speed_over"] += (tr.speed_over_general_count or 0) + (tr.speed_over_highway_count or 0)
        te["rpm_over"] += (tr.rpm_over_general_count or 0) + (tr.rpm_over_highway_count or 0)
        te["idle_sec"] += tr.idle_time_sec or 0

    # Get trip stops in order for route lines
    routes = []
    trip_reports_with_stops = defaultdict(list)
    for dd, tr in stops_q:
        lat = dd.gps_lat / 100000.0
        lon = dd.gps_lon / 100000.0
        trip_reports_with_stops[tr.report_number].append({
            "lat": lat, "lon": lon, "seq": dd.detail_number or 0,
            "work_type": dd.work_type or "",
        })

    for rn, points in trip_reports_with_stops.items():
        points.sort(key=lambda p: p["seq"])
        te = trip_events_map.get(rn, {})
        total_events = te.get("accel", 0) + te.get("decel", 0) + te.get("start", 0)
        routes.append({
            "report_number": rn,
            "points": [{"lat": p["lat"], "lon": p["lon"]} for p in points],
            "events": total_events,
            "speed_over": te.get("speed_over", 0),
        })

    # Build clustered markers
    markers = []
    for grid_key, ls in location_stats.items():
        avg_idle = ls["idle_total_sec"] / max(ls["visit_count"], 1)
        # Marker type
        if avg_idle > 300:  # 5min+ idle average
            marker_type = "idle_high"
            color = "red"
        elif avg_idle > 120:
            marker_type = "idle_mid"
            color = "orange"
        elif ls["stop_total_sec"] / max(ls["visit_count"], 1) > 3600:
            marker_type = "long_stop"
            color = "blue"
        else:
            marker_type = "normal"
            color = "green"

        markers.append({
            "lat": ls["lat"],
            "lon": ls["lon"],
            "address": ls["address"],
            "visit_count": ls["visit_count"],
            "avg_idle_min": round(avg_idle / 60, 1),
            "total_idle_min": round(ls["idle_total_sec"] / 60, 1),
            "avg_stop_min": round(ls["stop_total_sec"] / max(ls["visit_count"], 1) / 60, 1),
            "work_types": list(ls["work_types"]),
            "dates_sample": sorted(ls["dates"])[:5],
            "marker_type": marker_type,
            "color": color,
        })

    markers.sort(key=lambda m: m["avg_idle_min"], reverse=True)

    # Summary stats
    total_idle_min = sum(m["total_idle_min"] for m in markers)
    high_idle_count = len([m for m in markers if m["marker_type"] == "idle_high"])
    total_events = sum(te["accel"] + te["decel"] + te["start"] for te in trip_events_map.values())
    total_speed_over = sum(te["speed_over"] for te in trip_events_map.values())

    summary = {
        "total_stops": len(markers),
        "high_idle_count": high_idle_count,
        "total_idle_min": round(total_idle_min, 1),
        "total_events": total_events,
        "total_speed_over": total_speed_over,
        "trip_count": len(trips_q),
        "months": months,
    }

    # Center point
    if markers:
        center_lat = sum(m["lat"] for m in markers) / len(markers)
        center_lon = sum(m["lon"] for m in markers) / len(markers)
    else:
        center_lat, center_lon = 35.68, 139.76  # Tokyo default

    return templates.TemplateResponse("coaching_map.html", {
        "request": request,
        "current_page": "coaching",
        "driver_code": driver_code,
        "driver_name": driver_name,
        "today": today,
        "markers": markers,
        "routes": routes,
        "summary": summary,
        "center_lat": center_lat,
        "center_lon": center_lon,
        "months": months,
    })


@router.get("/coaching/{driver_code}/print_guide")
async def coaching_print_guide(request: Request, driver_code: str, db: Session = Depends(get_db)):
    """A4指導書印刷用ページ — 面談カード左側 + 燃費改善マップ右側。"""
    from app.models.csv_import import DeliveryDetail
    base = resolve_base_month(db, request.cookies.get("base_month"))
    today = month_last_day(base)
    prev_start, prev_end = prev_month_range(base)

    # ── Card data ──────────────────────────────────────────────────────────
    this_month_start = base
    this_trips = db.query(TripReport).filter(
        TripReport.driver_code == driver_code,
        TripReport.operation_date >= this_month_start,
        TripReport.operation_date <= today,
    ).order_by(TripReport.operation_date).all()
    last_trips = db.query(TripReport).filter(
        TripReport.driver_code == driver_code,
        TripReport.operation_date >= prev_start,
        TripReport.operation_date <= prev_end,
    ).all()
    all_this_month = db.query(TripReport).filter(
        TripReport.operation_date >= this_month_start,
        TripReport.operation_date <= today,
    ).all()
    peer_stats = get_driver_stats(all_this_month)
    this_stats = get_driver_stats(this_trips) or {
        "trips": 0, "dist_km": 0, "avg_score": 0, "avg_safety": 0,
        "avg_economy": 0, "idle_rate": 0, "sudden_accel": 0, "sudden_decel": 0,
        "sudden_start": 0, "speed_over": 0, "rpm_over": 0, "events_per_100km": 0}
    last_stats = get_driver_stats(last_trips) or dict(this_stats)
    driver_name = this_trips[0].driver_name if this_trips else driver_code
    vehicle_name = this_trips[0].vehicle_name if this_trips else ""

    good_points, improve_points = [], []
    if last_stats["idle_rate"] > 0 and this_stats["idle_rate"] < last_stats["idle_rate"]:
        good_points.append(f"アイドリング率が先月比 ▲{round(last_stats['idle_rate'] - this_stats['idle_rate'], 1)}pt 改善")
    if last_stats["sudden_accel"] > 0 and this_stats["sudden_accel"] < last_stats["sudden_accel"]:
        good_points.append(f"急加速回数が先月比 ▲{round((1 - this_stats['sudden_accel'] / max(last_stats['sudden_accel'], 1)) * 100)}% 減少")
    if this_stats["avg_score"] > last_stats["avg_score"]:
        good_points.append(f"総合評価点が先月比 +{round(this_stats['avg_score'] - last_stats['avg_score'], 1)}pt 向上")
    if this_stats["speed_over"] == 0 and this_stats["trips"] > 0:
        good_points.append("速度超過ゼロを維持")
    if not good_points:
        good_points.append("安定した運行を継続中")

    if peer_stats:
        if this_stats["events_per_100km"] > peer_stats["events_per_100km"] * 1.2:
            improve_points.append(f"急操作回数が全社平均の {round(this_stats['events_per_100km'] / max(peer_stats['events_per_100km'], 0.1), 1)}倍")
        if this_stats["idle_rate"] > peer_stats["idle_rate"] + 3:
            improve_points.append(f"アイドリング率 {this_stats['idle_rate']}%（全社平均 {peer_stats['idle_rate']}%）")
        if this_stats["speed_over"] > 5:
            improve_points.append(f"速度超過 {this_stats['speed_over']}回 → 巡航速度改善が必要")
    if not improve_points:
        improve_points.append("特記事項なし — 良好")

    # ── Map data (3ヶ月) ────────────────────────────────────────────────────
    months = 3
    range_start = base.replace(day=1) - relativedelta(months=months - 1)
    stops_q = (
        db.query(DeliveryDetail, TripReport)
        .join(TripReport, DeliveryDetail.report_number == TripReport.report_number)
        .filter(
            TripReport.driver_code == driver_code,
            TripReport.operation_date >= range_start,
            TripReport.operation_date <= today,
            DeliveryDetail.gps_lat.isnot(None),
            DeliveryDetail.gps_lat != 0,
        ).all()
    )
    location_stats = defaultdict(lambda: {
        "lat": 0, "lon": 0, "idle_total_sec": 0, "stop_total_sec": 0,
        "visit_count": 0, "address": "", "work_types": set(), "dates": set(),
    })
    for dd, tr in stops_q:
        lat = dd.gps_lat / 100000.0
        lon = dd.gps_lon / 100000.0
        grid_key = (round(lat, 3), round(lon, 3))
        ls = location_stats[grid_key]
        ls["lat"] = lat; ls["lon"] = lon
        ls["idle_total_sec"] += dd.idle_time_sec or 0
        ls["stop_total_sec"] += dd.stop_time_sec or 0
        ls["visit_count"] += 1
        if dd.address: ls["address"] = dd.address
        if dd.work_type: ls["work_types"].add(dd.work_type)
        ls["dates"].add(tr.operation_date.strftime("%m/%d"))

    trip_events_map = defaultdict(lambda: {"accel": 0, "decel": 0, "start": 0, "speed_over": 0, "stops": []})
    trips_q = db.query(TripReport).filter(
        TripReport.driver_code == driver_code,
        TripReport.operation_date >= range_start,
        TripReport.operation_date <= today,
    ).all()
    for tr in trips_q:
        te = trip_events_map[tr.report_number]
        te["accel"] += tr.sudden_accel_count or 0
        te["decel"] += tr.sudden_decel_count or 0
        te["start"] += tr.sudden_start_count or 0
        te["speed_over"] += (tr.speed_over_general_count or 0) + (tr.speed_over_highway_count or 0)

    trip_reports_with_stops = defaultdict(list)
    for dd, tr in stops_q:
        trip_reports_with_stops[tr.report_number].append({
            "lat": dd.gps_lat / 100000.0, "lon": dd.gps_lon / 100000.0,
            "seq": dd.detail_number or 0,
        })
    routes = []
    for rn, points in trip_reports_with_stops.items():
        points.sort(key=lambda p: p["seq"])
        te = trip_events_map.get(rn, {})
        total_events = te.get("accel", 0) + te.get("decel", 0) + te.get("start", 0)
        routes.append({
            "points": [{"lat": p["lat"], "lon": p["lon"]} for p in points],
            "events": total_events,
            "speed_over": te.get("speed_over", 0),
        })

    markers = []
    for grid_key, ls in location_stats.items():
        avg_idle = ls["idle_total_sec"] / max(ls["visit_count"], 1)
        if avg_idle > 300: marker_type, color = "idle_high", "red"
        elif avg_idle > 120: marker_type, color = "idle_mid", "orange"
        elif ls["stop_total_sec"] / max(ls["visit_count"], 1) > 3600: marker_type, color = "long_stop", "blue"
        else: marker_type, color = "normal", "green"
        markers.append({
            "lat": ls["lat"], "lon": ls["lon"], "address": ls["address"],
            "visit_count": ls["visit_count"],
            "avg_idle_min": round(avg_idle / 60, 1),
            "total_idle_min": round(ls["idle_total_sec"] / 60, 1),
            "avg_stop_min": round(ls["stop_total_sec"] / max(ls["visit_count"], 1) / 60, 1),
            "work_types": list(ls["work_types"]),
            "dates_sample": sorted(ls["dates"])[:5],
            "marker_type": marker_type, "color": color,
        })
    markers.sort(key=lambda m: m["avg_idle_min"], reverse=True)

    total_events = sum(te["accel"] + te["decel"] + te["start"] for te in trip_events_map.values())
    high_idle_count = len([m for m in markers if m["marker_type"] == "idle_high"])
    summary = {
        "trip_count": len(trips_q), "total_stops": len(markers),
        "high_idle_count": high_idle_count,
        "total_idle_min": round(sum(m["total_idle_min"] for m in markers), 1),
        "total_events": total_events, "months": months,
    }
    if markers:
        center_lat = sum(m["lat"] for m in markers) / len(markers)
        center_lon = sum(m["lon"] for m in markers) / len(markers)
    else:
        center_lat, center_lon = 35.68, 139.76

    return templates.TemplateResponse("coaching_print_guide.html", {
        "request": request,
        "driver_code": driver_code,
        "driver_name": driver_name,
        "vehicle_name": vehicle_name,
        "today": today,
        "this_stats": this_stats,
        "last_stats": last_stats,
        "peer_stats": peer_stats,
        "good_points": good_points[:3],
        "improve_points": improve_points[:3],
        "markers": markers,
        "routes": routes,
        "center_lat": center_lat,
        "center_lon": center_lon,
        "summary": summary,
        "months": months,
    })


@router.post("/coaching/{driver_code}/goals")
async def save_goals(request: Request, driver_code: str, db: Session = Depends(get_db)):
    """Save improvement goals."""
    form = await request.form()
    today = date(2026, 3, 23)
    month_str = today.strftime("%Y-%m")
    target_rate = int(form.get("target_rate", DEFAULT_TARGET_RATE))

    card = db.query(DriverCoachingCard).filter(
        DriverCoachingCard.driver_code == driver_code,
        DriverCoachingCard.month == month_str,
    ).first()
    if not card:
        card = DriverCoachingCard(
            driver_code=driver_code,
            month=month_str,
            created_at=datetime.now(),
        )
        db.add(card)
        db.flush()

    db.query(ImprovementGoal).filter(
        ImprovementGoal.coaching_card_id == card.id
    ).delete()

    metric_keys = ["avg_score", "avg_safety", "avg_economy", "idle_rate", "events_per_100km", "speed_over"]
    for key in metric_keys:
        target_val = form.get(f"target_{key}")
        if target_val:
            goal = ImprovementGoal(
                coaching_card_id=card.id,
                goal_text=f"{key} improvement target",
                target_metric=key,
                target_value=float(target_val),
                status="pending",
            )
            db.add(goal)

    interviewer = form.get("interviewer", "")
    interview_date_str = form.get("interview_date", "")
    if interviewer:
        card.interviewer = interviewer
    if interview_date_str:
        try:
            card.interview_date = datetime.strptime(interview_date_str, "%Y-%m-%d").date()
        except ValueError:
            pass

    db.commit()
    return RedirectResponse(f"/coaching/{driver_code}?target_rate={target_rate}", status_code=303)
