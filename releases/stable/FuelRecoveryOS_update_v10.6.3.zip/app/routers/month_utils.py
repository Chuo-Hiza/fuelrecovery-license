"""共通月次ユーティリティ — 基軸月の解決・利用可能月リスト取得。"""
import calendar
from datetime import date
from sqlalchemy.orm import Session
from sqlalchemy import func
from dateutil.relativedelta import relativedelta

from app.models.csv_import import TripReport


def get_available_months(db: Session) -> list:
    """DBに運行データが存在する月のリスト（新しい順）。"""
    rows = db.query(
        func.strftime('%Y-%m', TripReport.operation_date).label('ym')
    ).distinct().order_by(
        func.strftime('%Y-%m', TripReport.operation_date).desc()
    ).all()
    result = []
    for (ym,) in rows:
        if ym:
            y, m = int(ym[:4]), int(ym[5:7])
            result.append(date(y, m, 1))
    return result


def resolve_base_month(db: Session, cookie_val) -> date:
    """Cookie値をバリデートして有効な基軸月（月初日）を返す。
    未設定・無効の場合はDBの最新月を返す。"""
    available = get_available_months(db)
    if not available:
        today = date.today()
        return today.replace(day=1)
    if cookie_val:
        try:
            y, m = int(str(cookie_val)[:4]), int(str(cookie_val)[5:7])
            candidate = date(y, m, 1)
            if candidate in available:
                return candidate
        except Exception:
            pass
    return available[0]


def month_last_day(base: date) -> date:
    """その月の最終日を返す。"""
    return base.replace(day=calendar.monthrange(base.year, base.month)[1])


def prev_month_range(base: date):
    """基軸月の前月の (start, end) を返す。"""
    prev_start = (base - relativedelta(months=1)).replace(day=1)
    prev_end = base.replace(day=1) - __import__('datetime').timedelta(days=1)
    return prev_start, prev_end


def month_context(db: Session, cookie_val) -> dict:
    """全ルーターが TemplateResponse context にマージする月情報 + ナビバッジ件数。"""
    available = get_available_months(db)
    base = resolve_base_month(db, cookie_val)

    # ナビバッジ用の件数 (要確認案件) — 失敗しても他のページ表示に影響を出さない
    nav_alert_counts = {"cases": 0, "cases_high": 0}
    try:
        # 循環インポート回避のため遅延インポート
        from app.routers.cases import count_pending_cases
        c = count_pending_cases(db, base)
        nav_alert_counts = {"cases": c["total"], "cases_high": c["high"]}
    except Exception:
        pass

    return {
        "available_months": available,
        "base_month": base,
        "nav_alert_counts": nav_alert_counts,
    }
