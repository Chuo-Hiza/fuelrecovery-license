"""Ver3 Executive Dashboard — 5案統合ダッシュボード."""
from datetime import date, timedelta
from collections import defaultdict

from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.csv_import import TripReport
from app.models.fuel_input import MonthlyFuelInput
from app.models.master import Vehicle
from app.routers.settings_router import get_fuel_price, DEFAULT_BASELINE_EFFICIENCY
from app.routers.month_utils import resolve_base_month, month_last_day, month_context
from app.services import mode_review as mode_review_svc

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


def _month_range(d: date):
    """Return (first_day, last_day) of the month containing d."""
    first = date(d.year, d.month, 1)
    if d.month == 12:
        last = date(d.year + 1, 1, 1) - timedelta(days=1)
    else:
        last = date(d.year, d.month + 1, 1) - timedelta(days=1)
    return first, last


def _prev_month(d: date):
    """Return a date in the previous month."""
    if d.month == 1:
        return date(d.year - 1, 12, 1)
    return date(d.year, d.month - 1, 1)


def _calc_fuel(trips, actual_by_vehicle: dict, vehicle_eff_map: dict,
               default_eff: float, fuel_price: int) -> tuple[float, int]:
    """車両ごとに「実給油あれば実値、なければ走行距離÷基準燃費」で集計。

    actual_by_vehicle: {vehicle_code: (fuel_amount_l, fuel_cost_yen)}
    Returns (total_fuel_l, total_fuel_yen)
    """
    estimated_by_vehicle: dict[str, float] = defaultdict(float)
    for t in trips:
        estimated_by_vehicle[t.vehicle_code] += (
            (t.distance_m or 0) / 1000
            / vehicle_eff_map.get(t.vehicle_code, default_eff)
        )
    total_l = 0.0
    total_yen = 0
    for vc, est_l in estimated_by_vehicle.items():
        if vc in actual_by_vehicle:
            actual_l, actual_yen = actual_by_vehicle[vc]
            total_l += actual_l
            total_yen += actual_yen if actual_yen > 0 else int(actual_l * fuel_price)
        else:
            total_l += est_l
            total_yen += int(est_l * fuel_price)
    return total_l, total_yen


def _loss_for_trip(t):
    """Estimate 4-layer losses for a single trip."""
    # Driving loss
    events = (
        (t.sudden_accel_count or 0) + (t.sudden_decel_count or 0) +
        (t.sudden_start_count or 0) + (t.speed_over_general_count or 0) +
        (t.speed_over_highway_count or 0) + (t.rpm_over_general_count or 0) +
        (t.rpm_over_highway_count or 0)
    )
    driving_l = events * 0.15

    # Dispatch loss (excess idle)
    excess_idle = max((t.idle_time_sec or 0) - 300, 0)
    dispatch_l = (excess_idle / 3600) * 1.5

    # Shipper loss (waiting)
    shipper_l = ((t.waiting_time_sec or 0) / 3600) * 1.5

    return driving_l, dispatch_l, shipper_l


@router.get("/")
async def dashboard(request: Request, db: Session = Depends(get_db)):
    FUEL_PRICE = get_fuel_price(db)
    # ── Resolve base month from cookie (fallback: latest data month) ──
    base = resolve_base_month(db, request.cookies.get("base_month"))
    if not db.query(func.max(TripReport.operation_date)).scalar():
        return templates.TemplateResponse("dashboard.html", {
            "request": request, "no_data": True, "current_page": "dashboard",
            "mode_review_summary": {"trip_count": 0, "driver_count": 0},
            **month_context(db, request.cookies.get("base_month")),
        })

    today = month_last_day(base)
    m_start, m_end = _month_range(today)
    prev_m = _prev_month(today)
    pm_start, pm_end = _month_range(prev_m)

    # ── Load trips ──
    trips = db.query(TripReport).filter(
        TripReport.operation_date >= m_start,
        TripReport.operation_date <= m_end,
    ).all()

    prev_trips = db.query(TripReport).filter(
        TripReport.operation_date >= pm_start,
        TripReport.operation_date <= pm_end,
    ).all()

    all_trips = db.query(TripReport).all()

    # ══════════════════════════════════════════════
    # 案5: 損失回収ファネル
    # ══════════════════════════════════════════════
    # 車両別基準燃費マップを構築
    vehicle_eff_map = {}
    for v in db.query(Vehicle).all():
        vehicle_eff_map[v.code] = v.baseline_efficiency_kml or DEFAULT_BASELINE_EFFICIENCY

    total_dist_km = sum((t.distance_m or 0) / 1000 for t in trips)

    # 月別 月次給油(MonthlyFuelInput) を一括取得 — 当月 + 過去6ヶ月分
    ym_strs = set()
    ym_strs.add(today.strftime("%Y-%m"))
    for i in range(1, 6):
        y, mn = today.year, today.month - i
        while mn <= 0:
            mn += 12
            y -= 1
        ym_strs.add(f"{y:04d}-{mn:02d}")
    monthly_fuel = (
        db.query(MonthlyFuelInput)
        .filter(MonthlyFuelInput.year_month.in_(ym_strs))
        .all()
    )
    actual_by_ym_vehicle: dict[tuple[str, str], tuple[float, int]] = {
        (m.year_month, m.vehicle_code): (m.fuel_amount_l or 0.0, m.fuel_cost_yen or 0)
        for m in monthly_fuel
    }

    # 当月の集計
    ym_now = today.strftime("%Y-%m")
    actual_now = {
        vc: lyen for (ym, vc), lyen in actual_by_ym_vehicle.items() if ym == ym_now
    }
    total_fuel_l, total_fuel_yen = _calc_fuel(
        trips, actual_now, vehicle_eff_map, DEFAULT_BASELINE_EFFICIENCY, FUEL_PRICE,
    )

    # 4-layer totals
    tot_driving_l = tot_dispatch_l = tot_shipper_l = 0.0
    for t in trips:
        d, di, s = _loss_for_trip(t)
        tot_driving_l += d
        tot_dispatch_l += di
        tot_shipper_l += s

    # Vehicle loss (aggregate)
    vehicle_stats = {}
    for t in all_trips:
        if t.distance_m and t.distance_m > 5000:
            code = t.vehicle_code
            if code not in vehicle_stats:
                vehicle_stats[code] = {"dist": 0, "events": 0}
            vehicle_stats[code]["dist"] += t.distance_m or 0
            vehicle_stats[code]["events"] += (
                (t.sudden_accel_count or 0) + (t.sudden_decel_count or 0) +
                (t.speed_over_general_count or 0) + (t.speed_over_highway_count or 0)
            )
    tot_vehicle_l = 0.0
    if vehicle_stats:
        avg_rate = sum(v["events"] / max(v["dist"] / 1000, 1) for v in vehicle_stats.values()) / len(vehicle_stats)
        for v in vehicle_stats.values():
            rate = v["events"] / max(v["dist"] / 1000, 1)
            if rate > avg_rate * 1.15:
                tot_vehicle_l += (rate - avg_rate) * v["dist"] / 1000 * 0.05

    total_loss_l = tot_driving_l + tot_dispatch_l + tot_shipper_l + tot_vehicle_l
    avoidable_l = total_loss_l * 0.7
    # Assume 30% of avoidable has been "recovered" by coaching actions
    good_trips = len([t for t in trips if (t.overall_score or 0) >= 80])
    recovery_rate = good_trips / max(len(trips), 1)
    recovered_l = avoidable_l * recovery_rate * 0.5

    funnel = {
        "total_fuel_l": round(total_fuel_l),
        "total_fuel_yen": total_fuel_yen,
        "total_loss_l": round(total_loss_l, 1),
        "total_loss_yen": int(total_loss_l * FUEL_PRICE),
        "avoidable_l": round(avoidable_l, 1),
        "avoidable_yen": int(avoidable_l * FUEL_PRICE),
        "recovered_l": round(recovered_l, 1),
        "recovered_yen": int(recovered_l * FUEL_PRICE),
        "remaining_l": round(avoidable_l - recovered_l, 1),
        "remaining_yen": int((avoidable_l - recovered_l) * FUEL_PRICE),
    }

    # 4-layer breakdown
    layer_total = max(total_loss_l, 0.1)
    layers = [
        {"name": "運転", "l": tot_driving_l, "yen": int(tot_driving_l * FUEL_PRICE),
         "pct": round(tot_driving_l / layer_total * 100), "color": "#E8652D"},
        {"name": "配車", "l": tot_dispatch_l, "yen": int(tot_dispatch_l * FUEL_PRICE),
         "pct": round(tot_dispatch_l / layer_total * 100), "color": "#3B82F6"},
        {"name": "荷主", "l": tot_shipper_l, "yen": int(tot_shipper_l * FUEL_PRICE),
         "pct": round(tot_shipper_l / layer_total * 100), "color": "#F5A623"},
        {"name": "車両", "l": tot_vehicle_l, "yen": int(tot_vehicle_l * FUEL_PRICE),
         "pct": round(tot_vehicle_l / layer_total * 100), "color": "#6B7280"},
    ]

    # ══════════════════════════════════════════════
    # 案3: 6ヶ月トレンド
    # ══════════════════════════════════════════════
    trend_months = []
    for i in range(5, -1, -1):
        y, m = today.year, today.month - i
        while m <= 0:
            m += 12
            y -= 1
        ms, me = _month_range(date(y, m, 1))
        mt = [t for t in all_trips if ms <= t.operation_date <= me]
        dist = sum((t.distance_m or 0) / 1000 for t in mt)
        ym_key = f"{y:04d}-{m:02d}"
        actual_this_month = {
            vc: lyen for (ym, vc), lyen in actual_by_ym_vehicle.items() if ym == ym_key
        }
        _fuel_l, fuel_yen = _calc_fuel(
            mt, actual_this_month, vehicle_eff_map, DEFAULT_BASELINE_EFFICIENCY, FUEL_PRICE,
        )
        loss = 0.0
        events = 0
        for t in mt:
            d, di, s = _loss_for_trip(t)
            loss += d + di + s
            events += (
                (t.sudden_accel_count or 0) + (t.sudden_decel_count or 0) +
                (t.sudden_start_count or 0) + (t.sudden_brake_count or 0) +
                (t.sudden_turn_count or 0)
            )
        trend_months.append({
            "label": f"{m}月",
            "fuel_yen": fuel_yen,
            "loss_yen": int(loss * FUEL_PRICE),
            "events": events,
            "trips": len(mt),
        })

    # ══════════════════════════════════════════════
    # 案3b: 日別トレンド（当月）
    # ══════════════════════════════════════════════
    daily_trend = []
    for d in sorted(set(t.operation_date for t in trips)):
        day_trips = [t for t in trips if t.operation_date == d]
        loss = 0.0
        events = 0
        for t in day_trips:
            dl, di, s = _loss_for_trip(t)
            loss += dl + di + s
            events += (
                (t.sudden_accel_count or 0) + (t.sudden_decel_count or 0) +
                (t.sudden_start_count or 0) + (t.sudden_brake_count or 0) +
                (t.sudden_turn_count or 0)
            )
        daily_trend.append({
            "label": f"{d.month}/{d.day}",
            "loss_yen": int(loss * FUEL_PRICE),
            "events": events,
            "trips": len(day_trips),
        })

    # ══════════════════════════════════════════════
    # 案4: 本日のスコアボード
    # ══════════════════════════════════════════════
    # Latest operation day's data
    latest_day_trips = [t for t in trips if t.operation_date == today]
    if not latest_day_trips:
        # Try the most recent day with data
        dates_in_month = sorted(set(t.operation_date for t in trips), reverse=True)
        if dates_in_month:
            latest_day = dates_in_month[0]
            latest_day_trips = [t for t in trips if t.operation_date == latest_day]
        else:
            latest_day = today
    else:
        latest_day = today

    day_dist = sum((t.distance_m or 0) / 1000 for t in latest_day_trips)
    day_events = sum(
        (t.sudden_accel_count or 0) + (t.sudden_decel_count or 0) +
        (t.sudden_start_count or 0) + (t.sudden_brake_count or 0) +
        (t.sudden_turn_count or 0)
        for t in latest_day_trips
    )
    day_avg_score = (
        sum(t.overall_score or 0 for t in latest_day_trips) / max(len(latest_day_trips), 1)
    )

    # TOP/WORST 3 by economy score — aggregate per driver first
    driver_eco = defaultdict(lambda: {"name": "", "eco_sum": 0.0, "eco_cnt": 0, "ovr_sum": 0.0, "ovr_cnt": 0})
    for t in latest_day_trips:
        if t.economy_score:
            dc = t.driver_code
            de = driver_eco[dc]
            de["name"] = t.driver_name or dc
            de["eco_sum"] += t.economy_score
            de["eco_cnt"] += 1
            de["ovr_sum"] += t.overall_score or 0
            de["ovr_cnt"] += 1
    scored_drivers = [
        (de["name"], de["eco_sum"] / de["eco_cnt"], de["ovr_sum"] / max(de["ovr_cnt"], 1))
        for de in driver_eco.values() if de["eco_cnt"] > 0
    ]
    scored_sorted = sorted(scored_drivers, key=lambda x: x[1], reverse=True)
    top3 = scored_sorted[:3]
    top3_names = {n for n, _, _ in top3}
    worst_candidates = [x for x in reversed(scored_sorted) if x[0] not in top3_names]
    worst3 = worst_candidates[:3]

    scoreboard = {
        "date": latest_day,
        "trips": len(latest_day_trips),
        "drivers": len(set(t.driver_code for t in latest_day_trips)),
        "dist_km": round(day_dist),
        "events": day_events,
        "avg_score": round(day_avg_score, 1),
        "top3": [{"name": n, "score": round(s, 1)} for n, s, _ in top3],
        "worst3": [{"name": n, "score": round(s, 1)} for n, s, _ in worst3],
    }

    # ══════════════════════════════════════════════
    # 案1: ドライバー燃費ヘルスマップ
    # ══════════════════════════════════════════════
    driver_cur = defaultdict(lambda: {
        "name": "", "trips": 0, "dist_km": 0.0,
        "events": 0, "score_sum": 0.0, "score_cnt": 0,
        "idle_sec": 0, "eco_score_sum": 0.0, "eco_cnt": 0,
    })
    for t in trips:
        dc = t.driver_code
        d = driver_cur[dc]
        d["name"] = t.driver_name or dc
        d["trips"] += 1
        d["dist_km"] += (t.distance_m or 0) / 1000
        d["events"] += (
            (t.sudden_accel_count or 0) + (t.sudden_decel_count or 0) +
            (t.sudden_start_count or 0) + (t.sudden_brake_count or 0) +
            (t.sudden_turn_count or 0)
        )
        d["idle_sec"] += t.idle_time_sec or 0
        if t.overall_score:
            d["score_sum"] += t.overall_score
            d["score_cnt"] += 1
        if t.economy_score:
            d["eco_score_sum"] += t.economy_score
            d["eco_cnt"] += 1

    # Previous month per driver
    driver_prev = defaultdict(lambda: {"events": 0, "dist_km": 0.0, "eco_score_sum": 0.0, "eco_cnt": 0})
    for t in prev_trips:
        dc = t.driver_code
        d = driver_prev[dc]
        d["dist_km"] += (t.distance_m or 0) / 1000
        d["events"] += (
            (t.sudden_accel_count or 0) + (t.sudden_decel_count or 0) +
            (t.sudden_start_count or 0) + (t.sudden_brake_count or 0) +
            (t.sudden_turn_count or 0)
        )
        if t.economy_score:
            d["eco_score_sum"] += t.economy_score
            d["eco_cnt"] += 1

    # Build driver tiles
    driver_tiles = []
    for dc, d in driver_cur.items():
        eco_avg = d["eco_score_sum"] / d["eco_cnt"] if d["eco_cnt"] > 0 else 0
        events_per100 = d["events"] / max(d["dist_km"], 1) * 100
        prev = driver_prev.get(dc)
        prev_eco = prev["eco_score_sum"] / prev["eco_cnt"] if prev and prev["eco_cnt"] > 0 else None
        prev_ev100 = prev["events"] / max(prev["dist_km"], 1) * 100 if prev and prev["dist_km"] > 0 else None

        # Health color: green(good) / yellow(watch) / red(alert)
        if eco_avg >= 80 and events_per100 < 5:
            health = "green"
        elif eco_avg >= 60 or events_per100 < 10:
            health = "yellow"
        else:
            health = "red"

        # Trend arrow
        if prev_eco is not None:
            eco_diff = eco_avg - prev_eco
            if eco_diff > 3:
                trend = "up"
            elif eco_diff < -3:
                trend = "down"
            else:
                trend = "flat"
        else:
            trend = "none"

        driver_tiles.append({
            "code": dc,
            "name": d["name"],
            "trips": d["trips"],
            "eco_score": round(eco_avg, 1),
            "events_per100": round(events_per100, 1),
            "health": health,
            "trend": trend,
            "eco_diff": round(eco_avg - prev_eco, 1) if prev_eco is not None else None,
        })

    # Sort: red first, then yellow, then green
    health_order = {"red": 0, "yellow": 1, "green": 2}
    driver_tiles.sort(key=lambda x: (health_order.get(x["health"], 3), -x["events_per100"]))

    # ══════════════════════════════════════════════
    # 案2: 車両コンディションカード
    # ══════════════════════════════════════════════
    # 3-month vehicle data
    three_months_ago = date(today.year, today.month, 1)
    for _ in range(2):
        three_months_ago = _prev_month(three_months_ago)
    tma_start, _ = _month_range(three_months_ago)

    recent_trips = [t for t in all_trips if t.operation_date >= tma_start]
    veh_data = defaultdict(lambda: {"name": "", "months": defaultdict(lambda: {
        "dist": 0.0, "events": 0, "trips": 0, "drivers": set(),
        "eco_sum": 0.0, "eco_cnt": 0,
    })})

    for t in recent_trips:
        vc = t.vehicle_code
        vd = veh_data[vc]
        vd["name"] = t.vehicle_name or vc
        m_key = f"{t.operation_date.month}月"
        md = vd["months"][m_key]
        md["dist"] += (t.distance_m or 0) / 1000
        md["events"] += (
            (t.sudden_accel_count or 0) + (t.sudden_decel_count or 0) +
            (t.sudden_start_count or 0)
        )
        md["trips"] += 1
        md["drivers"].add(t.driver_code)
        if t.economy_score:
            md["eco_sum"] += t.economy_score
            md["eco_cnt"] += 1

    # Build vehicle cards
    # Compute peer average for deviation
    all_veh_eco = []
    for vc, vd in veh_data.items():
        for mk, md in vd["months"].items():
            if md["eco_cnt"] > 0:
                all_veh_eco.append(md["eco_sum"] / md["eco_cnt"])
    peer_avg_eco = sum(all_veh_eco) / len(all_veh_eco) if all_veh_eco else 70

    vehicle_cards = []
    # Build month labels (last 3 months)
    veh_month_labels = []
    for i in range(2, -1, -1):
        y2, m2 = today.year, today.month - i
        while m2 <= 0:
            m2 += 12
            y2 -= 1
        veh_month_labels.append(f"{m2}月")

    for vc, vd in veh_data.items():
        monthly_eco = []
        monthly_ev100 = []
        total_drivers = set()
        total_dist = 0
        alert = None

        for ml in veh_month_labels:
            md = vd["months"].get(ml)
            if md and md["eco_cnt"] > 0:
                eco = md["eco_sum"] / md["eco_cnt"]
                monthly_eco.append(round(eco, 1))
            else:
                monthly_eco.append(None)
            if md and md["dist"] > 0:
                ev100 = md["events"] / md["dist"] * 100
                monthly_ev100.append(round(ev100, 1))
            else:
                monthly_ev100.append(None)
            if md:
                total_drivers |= md["drivers"]
                total_dist += md["dist"]

        # Detect anomaly: declining eco score
        valid_eco = [e for e in monthly_eco if e is not None]
        if len(valid_eco) >= 2:
            if valid_eco[-1] < valid_eco[0] - 5:
                alert = "悪化傾向"
            cur_eco = valid_eco[-1]
            if cur_eco < peer_avg_eco * 0.85:
                alert = "同車種平均を大幅に下回る"

        vehicle_cards.append({
            "code": vc,
            "name": vd["name"],
            "month_labels": veh_month_labels,
            "eco_scores": monthly_eco,
            "ev100_scores": monthly_ev100,
            "drivers": len(total_drivers),
            "dist_km": round(total_dist),
            "alert": alert,
        })

    vehicle_cards.sort(key=lambda x: (0 if x["alert"] else 1, x["code"]))

    # ══════════════════════════════════════════════
    # 全社マップ: 危険運転・アイドリング地点プロット
    # ══════════════════════════════════════════════
    from app.models.csv_import import DeliveryDetail

    stops_q = (
        db.query(DeliveryDetail, TripReport)
        .join(TripReport, DeliveryDetail.report_number == TripReport.report_number)
        .filter(
            TripReport.operation_date >= m_start,
            TripReport.operation_date <= m_end,
            DeliveryDetail.gps_lat.isnot(None),
            DeliveryDetail.gps_lat != 0,
        )
        .all()
    )

    # Cluster stops into ~100m grid and classify
    map_clusters = defaultdict(lambda: {
        "lat": 0, "lon": 0, "idle_sec": 0, "stop_sec": 0,
        "visits": 0, "address": "", "drivers": set(),
        "accel": 0, "decel": 0, "start_ev": 0, "speed_over": 0,
    })

    for dd, tr in stops_q:
        lat = dd.gps_lat / 100000.0
        lon = dd.gps_lon / 100000.0
        gk = (round(lat, 3), round(lon, 3))
        mc = map_clusters[gk]
        mc["lat"] = lat
        mc["lon"] = lon
        mc["idle_sec"] += dd.idle_time_sec or 0
        mc["stop_sec"] += dd.stop_time_sec or 0
        mc["visits"] += 1
        if dd.address:
            mc["address"] = dd.address
        mc["drivers"].add(tr.driver_code)
        mc["accel"] += tr.sudden_accel_count or 0
        mc["decel"] += tr.sudden_decel_count or 0
        mc["start_ev"] += tr.sudden_start_count or 0
        mc["speed_over"] += (tr.speed_over_general_count or 0) + (tr.speed_over_highway_count or 0)

    map_markers = []
    for gk, mc in map_clusters.items():
        avg_idle_min = mc["idle_sec"] / max(mc["visits"], 1) / 60
        total_events = mc["accel"] + mc["decel"] + mc["start_ev"]
        events_per_visit = total_events / max(mc["visits"], 1)

        # Classify: danger > idle > long_stop > normal
        if events_per_visit > 10 or mc["speed_over"] / max(mc["visits"], 1) > 5:
            mtype = "danger"
            color = "#E03E3E"
        elif avg_idle_min > 5:
            mtype = "idle_high"
            color = "#F5A623"
        elif avg_idle_min > 2:
            mtype = "idle_mid"
            color = "#FBBF24"
        elif mc["stop_sec"] / max(mc["visits"], 1) > 3600:
            mtype = "long_stop"
            color = "#3B82F6"
        else:
            mtype = "normal"
            color = "#10B981"

        if mtype == "normal":
            continue  # 通常地点は表示しない

        map_markers.append({
            "lat": mc["lat"], "lon": mc["lon"],
            "address": mc["address"],
            "visits": mc["visits"],
            "drivers": len(mc["drivers"]),
            "avg_idle_min": round(avg_idle_min, 1),
            "total_events": total_events,
            "speed_over": mc["speed_over"],
            "mtype": mtype, "color": color,
        })

    map_markers.sort(key=lambda m: (
        0 if m["mtype"] == "danger" else 1 if m["mtype"] == "idle_high" else 2
    ))

    if map_markers:
        map_center = {
            "lat": sum(m["lat"] for m in map_markers) / len(map_markers),
            "lon": sum(m["lon"] for m in map_markers) / len(map_markers),
        }
    else:
        map_center = {"lat": 35.68, "lon": 139.76}

    map_summary = {
        "total_spots": len(map_markers),
        "danger_spots": len([m for m in map_markers if m["mtype"] == "danger"]),
        "idle_spots": len([m for m in map_markers if m["mtype"] in ("idle_high", "idle_mid")]),
    }

    # ══════════════════════════════════════════════
    # Render
    # ══════════════════════════════════════════════
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "no_data": False,
        "current_page": "dashboard",
        "today": today,
        "month_str": f"{today.year}年{today.month}月",
        "fuel_price": FUEL_PRICE,
        # 案5: ファネル
        "funnel": funnel,
        "layers": layers,
        # 案3: トレンド
        "trend_months": trend_months,
        "daily_trend": daily_trend,
        # 案4: スコアボード
        "scoreboard": scoreboard,
        # 案1: ドライバーヘルスマップ
        "driver_tiles": driver_tiles,
        "driver_count": len(driver_tiles),
        # 案2: 車両カード
        "vehicle_cards": vehicle_cards,
        "veh_month_labels": veh_month_labels if vehicle_cards else [],
        # 全社マップ
        "map_markers": map_markers,
        "map_center": map_center,
        "map_summary": map_summary,
        # モード設定の確認推奨運行 サマリー
        "mode_review_summary": mode_review_svc.get_review_summary(db, base),
        **month_context(db, request.cookies.get("base_month")),
    })
