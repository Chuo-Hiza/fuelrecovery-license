"""オンラインアップデート ルーター。

/settings/update で更新確認 / モード切替 / 適用ボタンを提供。
適用ボタンは ready/ ステージングがある場合のみ有効。
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
from pathlib import Path

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.update import (
    UpdateChannel, UpdateMode, UpdateStage, UpdateType,
    compute_status, set_channel, set_mode, set_stage,
)
from app.update_checker import check_and_stage_update, clear_staged, staging_root

logger = logging.getLogger(__name__)
router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@router.get("/settings/update")
async def settings_update_get(request: Request, db: Session = Depends(get_db)):
    status = compute_status(db)
    return templates.TemplateResponse("settings_update.html", {
        "request": request,
        "current_page": "settings",
        "status": status,
        "channels": [c.value for c in UpdateChannel],
        "modes": [m.value for m in UpdateMode],
        "checked": request.query_params.get("checked"),
        "error": request.query_params.get("error"),
        "applied_msg": request.query_params.get("applied"),
        "cleared": request.query_params.get("cleared"),
        "mode_saved": request.query_params.get("mode_saved"),
        "channel_saved": request.query_params.get("channel_saved"),
    })


@router.post("/settings/update/check_now")
async def settings_update_check_now(
    request: Request, db: Session = Depends(get_db),
):
    """手動でマニフェスト取得 → 検証 → ステージング を実行。"""
    try:
        ok = check_and_stage_update(db)
    except Exception as e:
        logger.error("Manual update check failed: %s", e, exc_info=True)
        return RedirectResponse(url="/settings/update?error=check_failed", status_code=303)
    return RedirectResponse(
        url=f"/settings/update?checked={'1' if ok else '0'}", status_code=303,
    )


@router.post("/settings/update/set_channel")
async def settings_update_set_channel(
    request: Request, db: Session = Depends(get_db),
    channel: str = Form(...),
):
    try:
        set_channel(db, channel)
    except ValueError:
        return RedirectResponse(url="/settings/update?error=invalid_channel", status_code=303)
    return RedirectResponse(url="/settings/update?channel_saved=1", status_code=303)


@router.post("/settings/update/set_mode")
async def settings_update_set_mode(
    request: Request, db: Session = Depends(get_db),
    mode: str = Form(...),
):
    try:
        set_mode(db, mode)
    except ValueError:
        return RedirectResponse(url="/settings/update?error=invalid_mode", status_code=303)
    return RedirectResponse(url="/settings/update?mode_saved=1", status_code=303)


@router.post("/settings/update/clear")
async def settings_update_clear(
    request: Request, db: Session = Depends(get_db),
):
    """ステージング済み更新を破棄。"""
    clear_staged(db)
    return RedirectResponse(url="/settings/update?cleared=1", status_code=303)


@router.post("/settings/update/apply")
async def settings_update_apply(
    request: Request, db: Session = Depends(get_db),
):
    """apply_update.bat を spawn して uvicorn を停止する。

    bat 側でポート 8007 が listen しなくなるまで待ってから robocopy を実行する。
    """
    status = compute_status(db)
    if not status.can_apply_now:
        return RedirectResponse(url="/settings/update?error=cannot_apply", status_code=303)

    ready = staging_root() / "ready"
    if not (ready / "MANIFEST.toml").exists():
        return RedirectResponse(url="/settings/update?error=no_staged", status_code=303)

    bat = Path("apply_update.bat").resolve()
    if not bat.exists():
        logger.error("apply_update.bat not found at %s", bat)
        return RedirectResponse(url="/settings/update?error=bat_missing", status_code=303)

    set_stage(db, UpdateStage.APPLYING.value)

    # Windows でデタッチして batch 起動
    #   bat 内部で timeout / python -c / robocopy を使うため、コンソール無し
    #   (DETACHED_PROCESS) だと "Input redirection is not supported" で
    #   timeout が即終了する。CREATE_NEW_CONSOLE で独立 console を与える。
    if sys.platform == "win32":
        CREATE_NEW_CONSOLE = 0x00000010
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        CREATE_BREAKAWAY_FROM_JOB = 0x01000000
        flags = (
            CREATE_NEW_CONSOLE | CREATE_NEW_PROCESS_GROUP | CREATE_BREAKAWAY_FROM_JOB
        )
        subprocess.Popen(
            ["cmd.exe", "/c", str(bat)],
            creationflags=flags,
            close_fds=True,
            cwd=str(bat.parent),
        )
    else:
        # 開発環境向け (Linux/Mac 上の動作確認用、本番は Windows のみ)
        subprocess.Popen([str(bat)], cwd=str(bat.parent), close_fds=True)

    # 応答を返してから uvicorn 終了を要求
    import threading
    def _shutdown_soon():
        import time
        time.sleep(2)  # レスポンスを返しきる時間
        logger.info("Stopping uvicorn for update apply")
        os._exit(0)  # uvicorn シグナルでは graceful 過ぎて batch の polling と整合しないため即時終了
    threading.Thread(target=_shutdown_soon, daemon=True).start()

    return RedirectResponse(url="/settings/update?applied=1", status_code=303)
