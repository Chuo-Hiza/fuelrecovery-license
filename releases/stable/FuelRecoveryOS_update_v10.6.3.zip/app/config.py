"""Application settings."""
from pathlib import Path
from pydantic_settings import BaseSettings

# Resolve app root (parent of app/ directory)
_APP_ROOT = Path(__file__).resolve().parent.parent


def _find_env_file() -> str | None:
    """Find .env file: check config/.env first, then project root .env."""
    for candidate in [_APP_ROOT / "config" / ".env", _APP_ROOT / ".env"]:
        if candidate.exists():
            return str(candidate)
    return None


class Settings(BaseSettings):
    app_name: str = "Fuel Recovery OS"
    app_version: str = "10.6.3"

    # Database
    database_url: str = "sqlite:///./fuel_recovery.db"

    # CSV import folders
    csv_auto_export_dir: str = r"C:\estra-data\auto-export"
    csv_daily_batch_dir: str = r"C:\estra-data\daily-batch"
    csv_master_dir: str = r"C:\estra-data\master"
    csv_monthly_dir: str = r"C:\estra-data\monthly"
    csv_processing_dir: str = r"C:\estra-data\processing"
    csv_done_dir: str = r"C:\estra-data\done"
    csv_error_dir: str = r"C:\estra-data\error"

    # Polling
    polling_interval_sec: int = 300  # 5 minutes
    file_stable_wait_sec: int = 2

    # Fuel price defaults
    default_fuel_price_yen: int = 162

    # Done folder retention
    done_retention_days: int = 7

    model_config = {
        "env_file": _find_env_file(),
        "env_file_encoding": "utf-8",
    }


settings = Settings()
