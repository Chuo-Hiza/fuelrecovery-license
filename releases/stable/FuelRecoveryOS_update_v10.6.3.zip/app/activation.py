"""Activation check — machine-bound license validation.

初回起動時にセットアップパスワードを要求し、マシンフィンガープリントを
DB (system_settings) に保存する。以降の起動ではフィンガープリント照合のみ。
別PCに移動した場合はフィンガープリントが変わるため再アクティベーションが必要。
"""
import hashlib
import socket
import subprocess

from sqlalchemy.orm import Session

from app.models.system import SystemSetting

# パスワードハッシュ (SHA-256)
_PASS_HASH = hashlib.sha256(b"Cys46747").hexdigest()

_ACTIVATION_KEY = "activation"


def _get_volume_serial() -> str:
    """Cドライブのボリュームシリアル番号を取得。"""
    try:
        result = subprocess.run(
            ["cmd", "/c", "vol", "C:"],
            capture_output=True, text=True, timeout=5,
        )
        for line in result.stdout.splitlines():
            # "Volume Serial Number is XXXX-XXXX" pattern
            if "Serial" in line or "シリアル" in line:
                parts = line.strip().split()
                return parts[-1]  # e.g. "A1B2-C3D4"
    except Exception:
        pass
    return "UNKNOWN"


def get_machine_fingerprint() -> str:
    """ホスト名 + Cドライブボリュームシリアルからフィンガープリント生成。"""
    hostname = socket.gethostname()
    vol_serial = _get_volume_serial()
    raw = f"{hostname}:{vol_serial}"
    return hashlib.sha256(raw.encode()).hexdigest()


def check_activation(db: Session) -> bool:
    """アクティベーション済みか検証。"""
    row = db.query(SystemSetting).filter_by(key=_ACTIVATION_KEY).first()
    if not row:
        return False
    return row.value == get_machine_fingerprint()


def activate(db: Session, password: str) -> bool:
    """パスワード検証 → 正しければフィンガープリントを保存。"""
    if hashlib.sha256(password.encode()).hexdigest() != _PASS_HASH:
        return False
    fingerprint = get_machine_fingerprint()
    row = db.query(SystemSetting).filter_by(key=_ACTIVATION_KEY).first()
    if row:
        row.value = fingerprint
    else:
        db.add(SystemSetting(
            key=_ACTIVATION_KEY,
            value=fingerprint,
            description="Machine activation fingerprint",
        ))
    db.commit()
    return True
