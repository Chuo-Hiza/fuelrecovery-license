"""起動時に社内LANからのアクセスURLをコンソール表示する。

Usage:
    python -m app.access_info [port]

start.bat から uvicorn 起動直前に呼び出す想定。
依存はPython標準ライブラリのみ。
"""
from __future__ import annotations

import socket
import sys
from contextlib import closing


def _is_private_ipv4(ip: str) -> bool:
    """RFC1918プライベートアドレス + 169.254のリンクローカル判定。"""
    if ip.startswith(("10.", "192.168.")):
        return True
    if ip.startswith("172."):
        try:
            second = int(ip.split(".")[1])
            return 16 <= second <= 31
        except (IndexError, ValueError):
            return False
    return False


def get_lan_ips() -> list[str]:
    """非ループバックなIPv4アドレスのリストを返す。重複は排除。

    Windows環境で複数NIC(Ethernet/Wi-Fi/VPN/Hyper-V等)がある場合も拾う。
    プライベートアドレスを優先し、それ以外を後ろに並べる。
    """
    ips: set[str] = set()

    # Method 1: gethostbyname_ex
    try:
        _, _, addrs = socket.gethostbyname_ex(socket.gethostname())
        for a in addrs:
            if a and not a.startswith("127.") and ":" not in a:
                ips.add(a)
    except Exception:
        pass

    # Method 2: getaddrinfo (異なるアダプタを拾うことがある)
    try:
        for fam, _, _, _, addr in socket.getaddrinfo(socket.gethostname(), None):
            if fam == socket.AF_INET and addr:
                ip = addr[0]
                if not ip.startswith("127."):
                    ips.add(ip)
    except Exception:
        pass

    # Method 3: UDP接続トリックでデフォルトルートのIPを取得
    try:
        with closing(socket.socket(socket.AF_INET, socket.SOCK_DGRAM)) as s:
            s.settimeout(0.3)
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
            if ip and not ip.startswith("127."):
                ips.add(ip)
    except Exception:
        pass

    # プライベートアドレス優先でソート
    return sorted(ips, key=lambda x: (0 if _is_private_ipv4(x) else 1, x))


def print_banner(port: int = 8007) -> None:
    """起動完了バナーを標準出力に表示する。"""
    # Windows cmd (cp932) でも崩れないようUTF-8安全な文字のみ使用
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    ips = get_lan_ips()
    bar = "=" * 66

    print()
    print(f"  {bar}")
    print(f"     Fuel Recovery OS  -  起動完了  (port {port})")
    print(f"  {bar}")
    print()
    print("   このPCから:")
    print(f"       http://127.0.0.1:{port}/")
    print()

    if ips:
        print("   社内LANから (他PC・タブレット):")
        for ip in ips:
            print(f"       http://{ip}:{port}/")
    else:
        print("   社内LAN: IPアドレスの自動取得に失敗しました")
        print("           ipconfig コマンドで確認してください")

    print()
    print("   ※ 上記URLをブラウザで開いてください")
    print("   ※ このウィンドウを閉じるとサーバーが停止します")
    print(f"  {bar}")
    print()
    sys.stdout.flush()


def main() -> int:
    port = 8007
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    print_banner(port)
    return 0


if __name__ == "__main__":
    sys.exit(main())
