@echo off
chcp 65001 >NUL
title Fuel Recovery OS - Applying Update
setlocal enabledelayedexpansion
set "INSTALL_DIR=%~dp0"
cd /d "%INSTALL_DIR%"
set PORT=8007
set "PY=%INSTALL_DIR%python\python.exe"
set "STAGING=%INSTALL_DIR%update_staging"
set "READY=%STAGING%\ready"
set "APPLIED=%STAGING%\applied"
set "ROLLBACK=%STAGING%\rollback\previous"

REM 1. Pre-checks
if not exist "%READY%\MANIFEST.toml" (
    echo [ERROR] Update files not found ^(MANIFEST.toml missing^).
    pause
    exit /b 1
)
if not exist "%READY%\app" (
    echo [ERROR] Update files not found ^(app directory missing^).
    pause
    exit /b 1
)

echo ============================================================
echo   Fuel Recovery OS - Applying Update
echo   (This window closes automatically. Do not close it.)
echo ============================================================
echo.

REM 2. Wait for uvicorn to release port (90s timeout)
echo  Waiting for server to stop...
set /a WAIT=0
:wait_loop
netstat -ano | findstr ":%PORT% " | findstr "LISTENING" >NUL 2>&1
if errorlevel 1 goto port_free
set /a WAIT+=1
if !WAIT! GEQ 90 (
    echo [ERROR] Server did not stop within 90 seconds. Aborting.
    pause
    exit /b 2
)
timeout /t 1 /nobreak >NUL
goto wait_loop
:port_free
echo  Server stopped OK.

REM 2b. Close lingering old start.bat console window(s).
REM   Old start.bat console has title "Fuel Recovery OS Ver*".
REM   This script's own title is "...- Applying Update", so it is not matched.
REM   New start.bat is not spawned yet, so killing old consoles is safe here.
for /f "tokens=2 delims=," %%P in ('tasklist /v /fi "imagename eq cmd.exe" /fo csv /nh 2^>NUL ^| findstr /c:"Fuel Recovery OS Ver"') do (
    set "OLDPID=%%~P"
    taskkill /F /PID !OLDPID! >NUL 2>&1
)

REM 3. Snapshot current files for rollback
echo  Backing up current version...
if exist "%STAGING%\rollback" rmdir /s /q "%STAGING%\rollback" 2>NUL
mkdir "%ROLLBACK%" 2>NUL
robocopy "%INSTALL_DIR%app"    "%ROLLBACK%\app"    /E /R:2 /W:2 /NFL /NDL /NJH /NJS /NP /XD __pycache__ /XF *.pyc >NUL
robocopy "%INSTALL_DIR%static" "%ROLLBACK%\static" /E /R:2 /W:2 /NFL /NDL /NJH /NJS /NP >NUL
if exist "%INSTALL_DIR%start.bat" copy /Y "%INSTALL_DIR%start.bat" "%ROLLBACK%\start.bat" >NUL

REM 4. Read target version from MANIFEST.toml (format: version = "10.6.0")
set TARGET_VER=
for /f "tokens=2 delims==" %%V in ('findstr /b /c:"version" "%READY%\MANIFEST.toml" 2^>NUL') do (
    if not defined TARGET_VER set "TARGET_VER=%%V"
)
set "TARGET_VER=!TARGET_VER:"=!"
set "TARGET_VER=!TARGET_VER: =!"
if not defined TARGET_VER set "TARGET_VER=unknown"

REM 5. Record applied marker (no trailing whitespace; '>' immediately after var)
if exist "%APPLIED%" rmdir /s /q "%APPLIED%" 2>NUL
mkdir "%APPLIED%" 2>NUL
>"%APPLIED%\applied_version" echo !TARGET_VER!

REM 6. Apply files (robocopy)
echo  Installing new files  (v!TARGET_VER!)...
robocopy "%READY%\app"    "%INSTALL_DIR%app"    /E /R:3 /W:5 /NFL /NDL /NJH /NJS /NP /XD __pycache__ /XF *.pyc
set RC1=%errorlevel%
robocopy "%READY%\static" "%INSTALL_DIR%static" /E /R:3 /W:5 /NFL /NDL /NJH /NJS /NP
set RC2=%errorlevel%
if exist "%READY%\start.bat" copy /Y "%READY%\start.bat" "%INSTALL_DIR%start.bat" >NUL

if !RC1! GEQ 8 goto fail_robocopy
if !RC2! GEQ 8 goto fail_robocopy

REM 6b. Schedule helper bat self-refresh via a temporary refresher .bat.
REM   We write a small bat to %TEMP% and spawn it; it sleeps 5s then copies the
REM   new apply_update.bat / rollback.bat from staging\ready to INSTALL_DIR.
REM   The delay lets cmd.exe finish reading this bat before the file is replaced.
if exist "%READY%\apply_update.bat" (
    set "REFRESHER=%TEMP%\fros_refresh_helpers.bat"
    (
        echo @echo off
        echo timeout /t 5 /nobreak ^>NUL
        echo copy /Y "%READY%\apply_update.bat" "%INSTALL_DIR%apply_update.bat" ^>NUL
        echo if exist "%READY%\rollback.bat" copy /Y "%READY%\rollback.bat" "%INSTALL_DIR%rollback.bat" ^>NUL
        echo del /f /q "%%~f0"
    ) > "!REFRESHER!"
    start "" /B cmd /c call "!REFRESHER!"
)

REM 7. Spawn start.bat detached
echo  Starting new version...
start "" /B cmd /c "%INSTALL_DIR%start.bat"

REM 8. Poll /health for up to 90 seconds
echo  Verifying startup...
set /a HC=0
:health_loop
timeout /t 2 /nobreak >NUL
"%PY%" -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:%PORT%/health', timeout=2)" >NUL 2>&1
if not errorlevel 1 goto health_ok
set /a HC+=2
if !HC! GEQ 90 goto fail_health
goto health_loop

:health_ok
echo.
echo ============================================================
echo   Update to v!TARGET_VER! complete.
echo ============================================================
exit /b 0

:fail_robocopy
echo [ERROR] File install failed (RC1=!RC1! RC2=!RC2!). Rolling back...
goto do_rollback

:fail_health
echo [ERROR] New version did not respond within 90 seconds. Rolling back...
goto do_rollback

:do_rollback
start "" /B cmd /c "%INSTALL_DIR%rollback.bat"
exit /b 8
