"""ユーザー向け更新履歴。

リリース毎にエントリを追加。表示順は新→旧。type は patch / minor / major。
"""
from __future__ import annotations

# このバージョン未満のエントリは /changelog で notes を伏せる
# (バージョン番号・日付・タイトルは表示する)。
# 顧客に見せたくない初期開発期間のリリースを「履歴あり/詳細非公開」扱いにする。
MIN_VERBOSE_VERSION = "10.6.6"


def _ver_tuple(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.split("."))
    except (ValueError, AttributeError):
        return (0,)


def get_entries_for_display() -> list[dict]:
    """/changelog に渡す表示用エントリ。

    MIN_VERBOSE_VERSION 未満のエントリは notes を空にし notes_hidden=True を
    立てる (テンプレ側で「詳細省略」表示)。
    """
    cutoff = _ver_tuple(MIN_VERBOSE_VERSION)
    out: list[dict] = []
    for e in CHANGELOG:
        if _ver_tuple(e.get("version", "")) < cutoff:
            out.append({**e, "notes": [], "notes_hidden": True})
        else:
            out.append(e)
    return out


CHANGELOG: list[dict] = [
    {
        "version": "10.6.11",
        "date": "2026-05-18",
        "type": "patch",
        "title": "",
        "notes": [

        ],
        "notes_hidden": True,
        "internal_title": "オンライン更新 helper bat の ASCII 化 + 自己更新機構",
        "internal_notes": [
            "apply_update.bat / rollback.bat を ASCII-only に書き直し (cmd.exe の UTF-8 multibyte 解析バグ対策)",
            "build/_write_bat_ascii_crlf() で ASCII バイト + CRLF + BOM なしを強制し Linux/WSL ビルドでも安全に",
            "build_update_pkg.py 側でも .encode('ascii') 経由でビルド時に違反検出",
            "新 apply_update.bat に self-refresh を追加: %TEMP% に refresher.bat を spawn して 5 秒後に staging\ready の bat を INSTALL_DIR へ delay-copy",
            "test PC で v10.6.9 → 10.6.10 のオンライン更新が正常完了することを実機検証",
        ],
    },
    {
        "version": "10.6.10",
        "date": "2026-05-15",
        "type": "patch",
        "title": "表示の調整",
        "notes": [],
        "notes_hidden": True,
        "internal_title": "License GUI ツール強化 + /changelog 表示マスク + リリース UI 構造改善",
        "internal_notes": [
            "license_gui.bat: ASCII-only + CRLF + port 待ちループ",
            "License GUI: /restart endpoint + ヘッダー再起動ボタン + nonce 判定の自動リロード",
            "License GUI release 画面: pending_version (CHANGELOG 追記済・未公開) を patch 候補化",
            "License GUI release 画面: 「ユーザー非表示」 (notes_hidden) チェックボックス追加",
            "License GUI release 画面: 顧客向け / 実装の真相 の 2 ブロック構造化 + internal_title / internal_notes 追加",
            "app/changelog.py: MIN_VERBOSE_VERSION で 10.6.5 以前の notes を伏せる",
            "app/templates/changelog.html: notes_hidden の時 notes セクション省略",
        ],
    },
    {
        "version": "10.6.9",
        "date": "2026-05-15",
        "type": "patch",
        "title": "UI改善・機能追加・セキュリティ強化・アップデート機能改善",
        "notes": [
            "新版を起動時に自動適用するように改善",
            "アップデート適用中の表示を日本語化",
            "アップデート後の起動確認をより堅牢に",
            "ヘッダーのバージョン番号クリックで更新履歴を表示",
            "アップデートチェックを高頻度化 (起動時 + 8 時間ごと)",
            "緊急時のセキュリティ配信を強制適用できるように",
        ],
    },
    {
        "version": "10.6.8",
        "date": "2026-05-15",
        "type": "patch",
        "title": "アップデート適用後の旧コンソールを自動で閉じる",
        "notes": [
            "アップデート適用後に前バージョンの黒い画面が残ったままになる "
            "不具合を修正 (適用処理が旧ウィンドウを検知して自動で閉じる)",
        ],
    },
    {
        "version": "10.6.7",
        "date": "2026-05-14",
        "type": "patch",
        "title": "UI改善・機能追加・セキュリティ強化・アップデート機能改善",
        "notes": [
            "新版を起動時に自動適用するように改善",
            "アップデート適用中の表示を日本語化",
            "アップデート後の起動確認をより堅牢に",
            "ヘッダーのバージョン番号クリックで更新履歴を表示",
            "アップデートチェックを高頻度化 (起動時 + 8 時間ごと)",
            "緊急時のセキュリティ配信を強制適用できるように",
        ],
    },
    {
        "version": "10.6.6",
        "date": "2026-05-13",
        "type": "patch",
        "title": "更新履歴リンクの表示修正",
        "notes": [
            "ヘッダーのバージョン番号をクリックすると更新履歴が開くように "
            "(v10.6.5 で一部の表示モードでリンクが効いていなかった不具合の修正)",
        ],
    },
    {
        "version": "10.6.5",
        "date": "2026-05-13",
        "type": "patch",
        "title": "更新履歴ページ + その他改善",
        "notes": [
            "ヘッダーのバージョン番号をクリックで更新履歴ページを表示",
            "適用モードを auto に既定化、既存 install も自動マイグレーション",
            "緊急配信用の強制適用日 (mandatory_after) 実装",
        ],
    },
    {
        "version": "10.6.4",
        "date": "2026-05-13",
        "type": "patch",
        "title": "自動アップデート機能の本格化 + セキュリティ強化",
        "notes": [
            "起動時にアップデートチェックを実行するようになりました",
            "アップデート確認の間隔を 24時間 → 8時間に短縮",
            "適用モード「auto」を既定化 — 顧客操作なしで起動時に自動適用",
            "緊急配信用に「強制適用日 (mandatory_after)」を実装",
            "アップデート パッケージの安全展開を強化 (path traversal / symlink 対策)",
            "アップデート適用と取得の競合(race)を解消",
        ],
    },
    {
        "version": "10.6.3",
        "date": "2026-05-12",
        "type": "patch",
        "title": "ヘッダーに現在バージョン表示",
        "notes": [
            "画面右上に Ver番号 を表示(クリックで本ページへ)",
        ],
    },
    {
        "version": "10.6.2",
        "date": "2026-05-12",
        "type": "patch",
        "title": "初回オンライン配信テスト",
        "notes": [
            "v10.6 系の動作確認用リリース",
        ],
    },
    {
        "version": "10.6.1",
        "date": "2026-05-12",
        "type": "minor",
        "title": "オンライン自動アップデート機能 追加",
        "notes": [
            "今後の軽微なバグ修正・機能改善は GitHub Pages 経由で自動配信",
            "受信側に Ed25519 署名検証 + ZIP sha256 検証を実装",
            "ロールバック機能 — 起動失敗時は前バージョンに自動復旧",
            "/settings/update から手動チェック / 適用モード切替が可能",
        ],
    },
    {
        "version": "10.5.5",
        "date": "2026-05-11",
        "type": "patch",
        "title": "車両マスタ自動登録 + ショートカット改善",
        "notes": [
            "日報CSV取込時に車両マスタへ自動登録するよう修正 "
            "(給油入力画面で車両ドロップダウンが空になる不具合の対処)",
            "デスクトップショートカットに極燃ロゴを設定",
            "デスクトップ上の旧 .bat ランチャー残骸を自動削除",
        ],
    },
    {
        "version": "10.5.4",
        "date": "2026-05-10",
        "type": "patch",
        "title": "操作ガイドにライセンス管理セクション",
        "notes": [
            "/help にライセンス管理の説明を追加",
        ],
    },
    {
        "version": "10.5.3",
        "date": "2026-05-09",
        "type": "patch",
        "title": "ライセンスIDのフォールバックバグ修正",
        "notes": [
            "customer_id が空文字のとき試用版モードへ正しくフォールバック",
        ],
    },
    {
        "version": "10.5.2",
        "date": "2026-05-08",
        "type": "patch",
        "title": "ライセンス状態チップ常時表示",
        "notes": [
            "ヘッダーに試用残日数 / ご契約状態を常時表示",
        ],
    },
    {
        "version": "10.5.1",
        "date": "2026-05-07",
        "type": "patch",
        "title": "ライセンス配信URL確定",
        "notes": [
            "Chuo-Hiza/fuelrecovery-license リポジトリ経由でライセンス配信",
        ],
    },
    {
        "version": "10.5.0",
        "date": "2026-05-06",
        "type": "minor",
        "title": "ライセンス期限機能",
        "notes": [
            "試用6ヶ月 + 本契約モード",
            "GitHub Pages からのオンライン期限取得",
            "期限切れ時の Grace期間(7日) → Locked への段階遷移",
        ],
    },
]
