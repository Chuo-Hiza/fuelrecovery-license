"""オンラインアップデート — 純ロジック層。

app/license.py の Ed25519 + GitHub Pages パターンを踏襲して、
配信されたマニフェスト JSON の検証と適用判定をおこなう。

設計:
- マニフェスト署名は Ed25519 / 鍵は license と別 (release_public.pem)
- 適用モード (notify/manual/auto) と update_type (patch/minor/major) を組合せて判定
- rollout_percent は customer_id (試用版は install_date) を seed にした sha256 で安定的に振り分け
"""
from __future__ import annotations

import base64
import hashlib
import logging
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Optional

from sqlalchemy.orm import Session

from app.config import settings as app_settings

logger = logging.getLogger(__name__)

# ── 設定値 ────────────────────────────────────────────────────────
DEFAULT_RELEASE_BASE_URL = (
    "https://chuo-hiza.github.io/fuelrecovery-license/releases"
)
RELEASE_PUBLIC_KEY_PATH = (
    Path(__file__).parent / "license_keys" / "release_public.pem"
)
CHECK_INTERVAL_HOURS = 24
MANIFEST_SCHEMA_VERSION = 1


class UpdateMode(str, Enum):
    NOTIFY = "notify"
    MANUAL = "manual"
    AUTO = "auto"


class UpdateChannel(str, Enum):
    STABLE = "stable"
    BETA = "beta"


class UpdateType(str, Enum):
    PATCH = "patch"
    MINOR = "minor"
    MAJOR = "major"


class UpdateStage(str, Enum):
    IDLE = "idle"           # 未取得 or 既に適用済み
    STAGED = "staged"       # ZIP 検証済み、apply 待ち
    APPLYING = "applying"   # apply_update.bat 実行中
    FAILED = "failed"       # 適用失敗 (rollback 後)


@dataclass
class ApplyDecision:
    can_apply: bool
    reason: str           # "not_newer" | "blocked_current" | "major_update" | "rollout_not_yet" | "ok"
    mandatory: bool       # mandatory_after 越え or blocked_versions ヒット


@dataclass
class UpdateStatus:
    current_version: str
    available_version: Optional[str]
    update_type: Optional[str]
    channel: str
    mode: str
    stage: str
    staged_at: Optional[datetime]
    mandatory_after: Optional[date]
    release_notes_url: Optional[str]
    last_check_date: Optional[datetime]
    last_check_success: bool
    check_failure_count: int

    @property
    def has_pending(self) -> bool:
        return self.stage == UpdateStage.STAGED.value

    @property
    def can_apply_now(self) -> bool:
        """設定画面で「いま適用」ボタンを有効化するか。"""
        if not self.has_pending:
            return False
        if self.update_type == UpdateType.MAJOR.value:
            return False  # major は TeamViewer 案内
        return self.mode in (UpdateMode.MANUAL.value, UpdateMode.AUTO.value)


# ── 署名検証 ──────────────────────────────────────────────────────
def _load_release_public_key():
    from cryptography.hazmat.primitives import serialization
    with open(RELEASE_PUBLIC_KEY_PATH, "rb") as f:
        return serialization.load_pem_public_key(f.read())


def _canonical_signed_bytes(payload: dict) -> bytes:
    """マニフェストの署名対象バイト列を組み立てる。

    schema_version=1 では、固定順序のフィールドを '|' 連結する。
    license.py の signed_message と同パターンで、JSON canonicalization
    に依存しない確実な方式。schema_version を上げた時に拡張する。
    """
    pkg = payload.get("package") or {}
    blocked = payload.get("blocked_versions") or []
    return "|".join([
        str(payload.get("schema_version", "")),
        str(payload.get("channel", "")),
        str(payload.get("version", "")),
        str(payload.get("released_at", "")),
        str(payload.get("update_type", "")),
        str(payload.get("min_from_version", "")),
        str(payload.get("min_db_version", "")),
        str(pkg.get("url", "")),
        str(pkg.get("size_bytes", "")),
        str(pkg.get("sha256", "")),
        str(payload.get("release_notes_url", "")),
        str(payload.get("mandatory_after", "")),
        str(payload.get("rollout_percent", "")),
        ",".join(blocked),
    ]).encode("utf-8")


def verify_manifest_signature(payload: dict) -> bool:
    """マニフェスト JSON の signature を Ed25519 で検証する。"""
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PublicKey,
        )
        public_key = _load_release_public_key()
        if not isinstance(public_key, Ed25519PublicKey):
            logger.error("Release public key is not Ed25519")
            return False

        sig_b64 = payload.get("signature")
        if not sig_b64:
            return False
        signed = _canonical_signed_bytes(payload)
        public_key.verify(base64.b64decode(sig_b64), signed)
        return True
    except Exception as e:
        logger.warning(f"Manifest signature verification failed: {e}")
        return False


# ── バージョン比較 ─────────────────────────────────────────────────
def parse_version(ver: str) -> tuple[int, ...]:
    """'10.5.5' → (10, 5, 5)。比較に使える tuple を返す。"""
    if not ver:
        return (0,)
    try:
        return tuple(int(p) for p in ver.split("."))
    except ValueError:
        return (0,)


def compute_current_version() -> str:
    return app_settings.app_version


# ── 適用判定 ──────────────────────────────────────────────────────
def compute_rollout_inclusion(seed: str, version: str, percent: int) -> bool:
    """customer_id (or 試用版なら install_date) を seed に、
    sha256 で 0-65535 を生成し、percent% の中に入るか判定。

    同じ seed + version では常に同じ結果 → 段階公開での「除外→包含」の
    巻き戻りなし。
    """
    if percent >= 100:
        return True
    if percent <= 0:
        return False
    h = hashlib.sha256(f"{seed}|{version}".encode("utf-8")).digest()
    score = (h[0] << 8) | h[1]  # 0-65535
    threshold = int((percent / 100) * 65536)
    return score < threshold


def should_apply(
    payload: dict,
    current_version: str,
    seed: str,
    today: Optional[date] = None,
) -> ApplyDecision:
    """マニフェスト + ローカル状態から適用可否を判定する。"""
    today = today or date.today()
    new_ver = payload.get("version", "")
    if not new_ver:
        return ApplyDecision(False, "no_version", False)

    # blocked_versions に現バージョンが入っていたら強制適用対象
    blocked = payload.get("blocked_versions") or []
    if current_version in blocked:
        return ApplyDecision(True, "blocked_current", True)

    # 単調増加
    if parse_version(new_ver) <= parse_version(current_version):
        return ApplyDecision(False, "not_newer", False)

    # min_from_version 未満 → major 扱いで apply 拒否
    min_from = payload.get("min_from_version") or "0.0.0"
    if parse_version(current_version) < parse_version(min_from):
        return ApplyDecision(False, "major_update", False)

    # update_type=major は通知のみ
    if payload.get("update_type") == UpdateType.MAJOR.value:
        return ApplyDecision(False, "major_update", False)

    # mandatory_after 越え判定
    mandatory = False
    mandatory_after_str = payload.get("mandatory_after")
    if mandatory_after_str:
        try:
            if today >= date.fromisoformat(mandatory_after_str):
                mandatory = True
        except ValueError:
            pass

    # rollout (mandatory のときは percent 無視)
    if not mandatory:
        raw_percent = payload.get("rollout_percent")
        percent = int(raw_percent if raw_percent is not None else 100)
        if not compute_rollout_inclusion(seed, new_ver, percent):
            return ApplyDecision(False, "rollout_not_yet", False)

    return ApplyDecision(True, "ok", mandatory)


# ── ZIP 安全展開 ──────────────────────────────────────────────────
def safe_extract_zip(zip_path: Path, dest_dir: Path) -> None:
    """zipfile を展開する。member.filename が dest_dir 外に向くものは拒否。

    Windows のパス区切りも考慮し、resolve() 後に dest_dir.resolve()
    の配下か確認する。
    """
    import zipfile
    dest_resolved = dest_dir.resolve()
    with zipfile.ZipFile(zip_path) as zf:
        for member in zf.infolist():
            target = (dest_dir / member.filename).resolve()
            try:
                target.relative_to(dest_resolved)
            except ValueError:
                raise ValueError(
                    f"Refused unsafe ZIP path: {member.filename}"
                )
        zf.extractall(dest_dir)


# ── DB アクセス (license.py と同パターン) ──────────────────────────
def _get_setting(db: Session, key: str) -> Optional[str]:
    from app.models.system import SystemSetting
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    return row.value if row else None


def _set_setting(db: Session, key: str, value: str) -> None:
    from app.models.system import SystemSetting
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    if row:
        row.value = value
    else:
        db.add(SystemSetting(key=key, value=value))
    db.commit()


def _del_setting(db: Session, key: str) -> None:
    from app.models.system import SystemSetting
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    if row:
        db.delete(row)
        db.commit()


def get_channel(db: Session) -> str:
    return _get_setting(db, "update_channel") or UpdateChannel.STABLE.value


def set_channel(db: Session, channel: str) -> None:
    if channel not in (UpdateChannel.STABLE.value, UpdateChannel.BETA.value):
        raise ValueError(f"Invalid channel: {channel}")
    _set_setting(db, "update_channel", channel)


def get_mode(db: Session) -> str:
    return _get_setting(db, "update_mode") or UpdateMode.NOTIFY.value


def set_mode(db: Session, mode: str) -> None:
    valid = {m.value for m in UpdateMode}
    if mode not in valid:
        raise ValueError(f"Invalid mode: {mode}")
    _set_setting(db, "update_mode", mode)


def get_stage(db: Session) -> str:
    return _get_setting(db, "update_stage") or UpdateStage.IDLE.value


def set_stage(db: Session, stage: str) -> None:
    _set_setting(db, "update_stage", stage)


def get_last_check_info(db: Session) -> tuple[Optional[datetime], bool, int]:
    iso = _get_setting(db, "update_last_check_date")
    last_dt = None
    if iso:
        try:
            last_dt = datetime.fromisoformat(iso)
        except ValueError:
            pass
    success = _get_setting(db, "update_last_check_success") == "true"
    fail_count_str = _get_setting(db, "update_check_failure_count") or "0"
    try:
        fail_count = int(fail_count_str)
    except ValueError:
        fail_count = 0
    return last_dt, success, fail_count


def record_check_result(db: Session, success: bool) -> None:
    now = datetime.now()
    _set_setting(db, "update_last_check_date", now.isoformat(timespec="seconds"))
    _set_setting(db, "update_last_check_success", "true" if success else "false")
    if success:
        _set_setting(db, "update_check_failure_count", "0")
    else:
        _, _, fail = get_last_check_info(db)
        _set_setting(db, "update_check_failure_count", str(fail + 1))


def should_check_now_update(db: Session) -> bool:
    last_dt, _, _ = get_last_check_info(db)
    if last_dt is None:
        return True
    return (datetime.now() - last_dt) > timedelta(hours=CHECK_INTERVAL_HOURS)


def get_rollout_seed(db: Session) -> str:
    """rollout 判定の seed。本契約なら customer_id、試用版なら install_date。"""
    from app.license import get_customer_id, get_install_date
    cid = get_customer_id(db)
    if cid:
        return cid
    return get_install_date(db).isoformat()


# ── 公開: 状態スナップショット (テンプレート用) ────────────────────
def compute_status(db: Session) -> UpdateStatus:
    last_dt, last_ok, fail = get_last_check_info(db)
    staged_at_iso = _get_setting(db, "update_staged_at")
    staged_at = None
    if staged_at_iso:
        try:
            staged_at = datetime.fromisoformat(staged_at_iso)
        except ValueError:
            pass
    mandatory_after = None
    ma_str = _get_setting(db, "update_mandatory_after")
    if ma_str:
        try:
            mandatory_after = date.fromisoformat(ma_str)
        except ValueError:
            pass
    return UpdateStatus(
        current_version=compute_current_version(),
        available_version=_get_setting(db, "update_available_version"),
        update_type=_get_setting(db, "update_available_type"),
        channel=get_channel(db),
        mode=get_mode(db),
        stage=get_stage(db),
        staged_at=staged_at,
        mandatory_after=mandatory_after,
        release_notes_url=_get_setting(db, "update_release_notes_url"),
        last_check_date=last_dt,
        last_check_success=last_ok,
        check_failure_count=fail,
    )


def store_manifest_summary(db: Session, payload: dict) -> None:
    """staging が成功した時点でテンプレート表示用の要約を SystemSetting に保存。"""
    _set_setting(db, "update_available_version", payload.get("version", ""))
    _set_setting(db, "update_available_type", payload.get("update_type", ""))
    notes = payload.get("release_notes_url")
    if notes:
        _set_setting(db, "update_release_notes_url", notes)
    ma = payload.get("mandatory_after")
    if ma:
        _set_setting(db, "update_mandatory_after", ma)
    _set_setting(db, "update_staged_at", datetime.now().isoformat(timespec="seconds"))


def clear_manifest_summary(db: Session) -> None:
    for k in (
        "update_available_version", "update_available_type",
        "update_release_notes_url", "update_mandatory_after",
        "update_staged_at",
    ):
        _del_setting(db, k)
