"""アップデートチェック バックグラウンドスレッド。

app/license_checker.py と同じパターンで動作する。
- 起動時1回 + 1時間ごとループ
- 24時間判定は update.should_check_now_update に委譲
- staged 状態のときは再ダウンロードしない (mode=auto+mandatory_after 越えのみ
  起動時に apply_update.bat を spawn する処理は main.py 側で実施)
"""
from __future__ import annotations

import hashlib
import logging
import shutil
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.update import (
    DEFAULT_RELEASE_BASE_URL,
    UpdateStage,
    clear_manifest_summary,
    compute_current_version,
    get_channel,
    get_rollout_seed,
    get_stage,
    record_check_result,
    safe_extract_zip,
    set_stage,
    should_apply,
    should_check_now_update,
    store_manifest_summary,
    verify_manifest_signature,
)

logger = logging.getLogger(__name__)

CHECK_LOOP_INTERVAL_SEC = 60 * 60  # 1時間ごとにループを回し、内部で24h 判定
DOWNLOAD_TIMEOUT_SEC = 60
DOWNLOAD_CHUNK_SIZE = 64 * 1024

# C:\FuelRecoveryOS\ 配下に作る (start.bat が working dir をここに置く)
_INSTALL_ROOT = Path(".").resolve()
_STAGING_ROOT = _INSTALL_ROOT / "update_staging"


def staging_root() -> Path:
    return _STAGING_ROOT


def _atomic_swap(src: Path, dst: Path) -> None:
    """src を dst にリネーム。dst が既に存在すれば先に退避。"""
    if dst.exists():
        backup = dst.with_name(dst.name + ".old")
        if backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
        dst.rename(backup)
        try:
            src.rename(dst)
            shutil.rmtree(backup, ignore_errors=True)
        except Exception:
            # ロールバック
            if backup.exists():
                backup.rename(dst)
            raise
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        src.rename(dst)


def _manifest_url(channel: str, base_url: str = DEFAULT_RELEASE_BASE_URL) -> str:
    return f"{base_url.rstrip('/')}/{channel}/manifest.json"


def fetch_manifest(channel: str, base_url: str = DEFAULT_RELEASE_BASE_URL) -> Optional[dict]:
    """マニフェスト JSON を取得する。"""
    import httpx
    url = _manifest_url(channel, base_url)
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(url)
            resp.raise_for_status()
            return resp.json()
    except Exception as e:
        logger.warning(f"Manifest fetch failed from {url}: {e}")
        return None


def _download_zip(url: str, dest: Path, expected_sha256: str,
                  expected_size: Optional[int] = None) -> bool:
    """ZIP をストリーミングで取得し、sha256 を計算しながら書き出す。

    検証 NG なら dest を削除して False を返す。
    """
    import httpx
    h = hashlib.sha256()
    written = 0
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        with httpx.stream("GET", url, timeout=DOWNLOAD_TIMEOUT_SEC) as resp:
            resp.raise_for_status()
            with open(dest, "wb") as f:
                for chunk in resp.iter_bytes(chunk_size=DOWNLOAD_CHUNK_SIZE):
                    h.update(chunk)
                    f.write(chunk)
                    written += len(chunk)
        digest = h.hexdigest()
        if digest.lower() != expected_sha256.lower():
            logger.error(
                f"ZIP sha256 mismatch: expected {expected_sha256}, got {digest}"
            )
            dest.unlink(missing_ok=True)
            return False
        if expected_size and written != expected_size:
            logger.error(
                f"ZIP size mismatch: expected {expected_size}, got {written}"
            )
            dest.unlink(missing_ok=True)
            return False
        return True
    except Exception as e:
        logger.warning(f"Download failed from {url}: {e}")
        dest.unlink(missing_ok=True)
        return False


def _stage_zip(zip_path: Path, pending_dir: Path, ready_dir: Path) -> bool:
    """pending/ に展開 → atomic rename で ready/ に切り替え。"""
    if pending_dir.exists():
        shutil.rmtree(pending_dir, ignore_errors=True)
    pending_dir.mkdir(parents=True, exist_ok=True)
    try:
        safe_extract_zip(zip_path, pending_dir)
    except Exception as e:
        logger.error(f"Unsafe ZIP rejected: {e}")
        shutil.rmtree(pending_dir, ignore_errors=True)
        return False

    # MANIFEST.toml の最低限存在チェック
    if not (pending_dir / "MANIFEST.toml").exists():
        logger.error("MANIFEST.toml missing in update ZIP")
        shutil.rmtree(pending_dir, ignore_errors=True)
        return False

    try:
        _atomic_swap(pending_dir, ready_dir)
    except Exception as e:
        logger.error(f"Staging swap failed: {e}")
        shutil.rmtree(pending_dir, ignore_errors=True)
        return False
    return True


def check_and_stage_update(db: Session, base_url: str | None = None) -> bool:
    """マニフェスト取得 → 検証 → 適用判定 → ZIP ダウンロード → ステージング。

    成功時 True (ready/ に新版が用意された) を返す。
    既に ready/ にステージング済みのバージョンと同じなら何もせず True。
    判定で除外された場合は False、ネットワーク失敗時も False。

    base_url が None の場合、SystemSetting `update_base_url_override` が
    あればそれを優先し、無ければ DEFAULT_RELEASE_BASE_URL を使う。
    """
    if base_url is None:
        from app.update import _get_setting
        override = _get_setting(db, "update_base_url_override")
        base_url = override or DEFAULT_RELEASE_BASE_URL
    channel = get_channel(db)
    payload = fetch_manifest(channel, base_url)
    if payload is None:
        record_check_result(db, success=False)
        return False

    if not verify_manifest_signature(payload):
        logger.error("Manifest signature invalid")
        record_check_result(db, success=False)
        return False

    record_check_result(db, success=True)

    current_version = compute_current_version()
    seed = get_rollout_seed(db)
    decision = should_apply(payload, current_version, seed)
    if not decision.can_apply:
        logger.info(
            f"Update available but not applied: version={payload.get('version')} "
            f"reason={decision.reason}"
        )
        # 通知のみは表示しておく (major 含む)
        if payload.get("version"):
            store_manifest_summary(db, payload)
        return False

    # 既に staged 済みかチェック
    stage = get_stage(db)
    ready_marker = _STAGING_ROOT / "ready" / "MANIFEST.toml"
    from app.update import _get_setting
    staged_ver = _get_setting(db, "update_available_version")
    if stage == UpdateStage.STAGED.value and staged_ver == payload.get("version"):
        logger.info(f"Update {staged_ver} already staged; skip re-download")
        return True

    # ダウンロード → 検証 → ステージング
    pkg = payload.get("package") or {}
    url = pkg.get("url")
    sha256 = pkg.get("sha256")
    size = pkg.get("size_bytes")
    if not url or not sha256:
        logger.error("Manifest package fields missing")
        return False

    _STAGING_ROOT.mkdir(parents=True, exist_ok=True)
    zip_path = _STAGING_ROOT / f"download_v{payload.get('version')}.zip"
    if not _download_zip(url, zip_path, sha256, size):
        return False

    pending_dir = _STAGING_ROOT / "pending"
    ready_dir = _STAGING_ROOT / "ready"
    if not _stage_zip(zip_path, pending_dir, ready_dir):
        zip_path.unlink(missing_ok=True)
        return False
    zip_path.unlink(missing_ok=True)

    store_manifest_summary(db, payload)
    set_stage(db, UpdateStage.STAGED.value)
    # マニフェスト本文をステージング横にも残す (apply_update.bat 検証用)
    import json
    (ready_dir / "_manifest.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    logger.info(
        f"Update staged: version={payload.get('version')} "
        f"type={payload.get('update_type')} mandatory={decision.mandatory}"
    )
    return True


def clear_staged(db: Session) -> None:
    """ready/ を破棄して状態を idle に戻す。"""
    ready = _STAGING_ROOT / "ready"
    if ready.exists():
        shutil.rmtree(ready, ignore_errors=True)
    set_stage(db, UpdateStage.IDLE.value)
    clear_manifest_summary(db)


def run_update_checker(stop_event: threading.Event) -> None:
    """アップデートチェック ループ。"""
    logger.info(
        "Update checker thread started (loop=%d sec)", CHECK_LOOP_INTERVAL_SEC,
    )
    # DB 初期化を待つ
    if stop_event.wait(5):
        return

    while not stop_event.is_set():
        try:
            db = SessionLocal()
            try:
                if should_check_now_update(db):
                    logger.info("Performing scheduled update check")
                    check_and_stage_update(db)
            finally:
                db.close()
        except Exception as e:
            logger.error("Update checker error: %s", e, exc_info=True)

        if stop_event.wait(CHECK_LOOP_INTERVAL_SEC):
            break

    logger.info("Update checker thread stopped")
