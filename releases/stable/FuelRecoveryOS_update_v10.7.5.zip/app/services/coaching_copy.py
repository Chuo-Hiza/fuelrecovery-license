# -*- coding: utf-8 -*-
"""声かけ文言 — 「この人に何をどう伝えればいいか」の一例を組み立てる。

文言は `app/data/coaching_copy.json` に置いてある。実行時にすることは
**穴埋めと選択だけ**で、外部への問い合わせも依存追加も発生しない
（オンプレ・ネット不要のまま動かすため）。

状態（first / streak2 / streak3plus / improving）と値は
`driver_alerts.attach_copy_context()` が用意する。ここは判定をしない。

同じ人の同じ月には同じ文言を出す。乗務員コード×月×指標から決めるため、
画面を開き直すたびに言い回しが変わることはない。翌月は別の案になる。
"""
import io
import json
import os
import zlib

DATA_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         "data", "coaching_copy.json")

_STORE: dict | None = None

# 文言が無い状態への読み替え。近い意味の状態へ落とす。
# **improving だけは落とさない。** streak2/first は「先月に続き」「今月はじめて」で、
# 前月より良くなった人に言うと**意味が逆**になる。文言が無ければ何も出さず、
# for_row が次の該当項目を試す。
_FALLBACK = {
    "improving": (),
    "streak3plus": ("streak2", "first"),
    "streak2": ("first",),
    "first": (),
}


def load(path: str = DATA_PATH) -> dict:
    """文言データ。1回読んで使い回す（ファイルは配布物に含まれる）。"""
    global _STORE
    if _STORE is None:
        try:
            _STORE = json.loads(io.open(path, encoding="utf-8").read())
        except (OSError, ValueError):
            _STORE = {"metrics": {}}       # 文言が無くても画面は出す
    return _STORE


def reload(path: str = DATA_PATH) -> dict:
    global _STORE
    _STORE = None
    return load(path)


def _fmt(v) -> str:
    if v is None:
        return "—"
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return str(v)


def _pick(variants: list, seed: str):
    """同じ人・同じ月・同じ指標なら毎回同じ案を選ぶ。翌月は別の案になる。"""
    if not variants:
        return None
    i = zlib.crc32(seed.encode("utf-8")) % len(variants)
    return variants[i]


def _fill(text: str, values: dict) -> str:
    for k, v in values.items():
        text = text.replace("{%s}" % k, _fmt(v))
    return text


def _estra_pointer(hit: dict) -> dict:
    """ESTRA-Web2 が評価している指標。助言は書かず、内訳の在り処を示す。

    安全評価・経済評価は顧客が選んだ 3〜12 項目の重み付き合計で、
    本システムは合計点しか受け取らない。どの項目が下げたのかを知らないまま
    「〜してください」と書くと当てずっぽうになる（改修提案 20260916 案A）。
    項目ごとのコメントと指導書は ESTRA-Web2 側の設定が正本。
    """
    from app.services import driver_alerts

    label = hit.get("label") or ""
    unit = hit.get("unit") or ""
    return {
        "kind": "estra",
        "field": hit.get("field"),
        "label": label,
        "state": hit.get("state"),
        "value": hit.get("value"),
        "threshold": hit.get("threshold"),
        "unit": unit,
        "prev_value": hit.get("prev_value"),
        "headline": "%s が %s%s で、目安の %s%s に届いていません。"
                    % (label, _fmt(hit.get("value")), unit,
                       _fmt(hit.get("threshold")), unit),
        "where": "ESTRA-Web2 の「%s」" % driver_alerts.ESTRA_DETAIL_HINT,
        "why": "この評価は ESTRA-Web2 が行っており、本システムは点数だけを受け取っています。"
               "どの項目が下がっているか、項目ごとのコメント、指導書は ESTRA-Web2 側でご確認ください。",
    }


def for_hit(hit: dict, driver_name: str, driver_code: str, ym: str,
            store: dict | None = None) -> dict | None:
    """1つの該当項目から、声かけの一例を組み立てる。

    hit は driver_alerts.evaluate_driver() の hits[] に
    attach_copy_context() が state / streak / prev_value を足したもの。
    文言が無ければ None（画面側は何も出さない）。
    """
    from app.services import driver_alerts

    if hit.get("field") in driver_alerts.ESTRA_SCORE_FIELDS:
        return _estra_pointer(hit)

    s = store or load()
    metric = (s.get("metrics") or {}).get(hit.get("field"))
    if not metric:
        return None

    states = metric.get("states") or {}
    state = hit.get("state") or "first"
    used = state
    for cand in (state,) + _FALLBACK.get(state, ()):
        if states.get(cand):
            used = cand
            break
    else:
        return None

    rec = _pick(states[used], "%s|%s|%s" % (driver_code, ym, hit.get("field")))
    if not rec:
        return None

    values = {
        "name": driver_name,
        "value": hit.get("value"),
        "threshold": hit.get("threshold"),
        "unit": metric.get("unit") or hit.get("unit") or "",
        "prev_value": hit.get("prev_value"),
        "streak": hit.get("streak"),
    }
    return {
        "kind": "copy",
        "id": rec["id"],
        "field": hit.get("field"),
        "label": metric.get("display") or hit.get("label"),
        "state": used,
        "state_asked": state,
        "substituted": used != state,
        "lead": _fill(rec["lead"], values),
        "asks": [_fill(a, values) for a in rec["asks"]],
        "next": _fill(rec["next"], values),
        "note": _fill(rec["note"], values),
        "warn": rec.get("warn") or [],
    }


def for_row(row: dict, ym: str, store: dict | None = None) -> dict | None:
    """1名分。**1件だけ**返す。

    あれもこれも出すと「どれを見ればよいか分からない」に戻るため 1件に絞る
    （確定設計 §0）。hits は重い順に並んでいる。

    ESTRA-Web2 が評価している指標（総合/安全/経済）は助言を書けないので、
    **助言を書ける項目を先に探し**、無いときだけ ESTRA への導線を返す。
    """
    hits = row.get("hits") or []
    name = row.get("name") or row.get("code")
    fallback = None
    for hit in hits:
        c = for_hit(hit, name, row.get("code"), ym, store)
        if not c:
            continue
        if c["kind"] == "estra":
            # 導線は最後の手段。助言を書ける項目があればそちらを先に出す。
            fallback = fallback or c
            continue
        c["other_hits"] = max(0, len(hits) - 1)
        c["ok_fields"] = row.get("ok_fields") or []
        return c
    if fallback:
        fallback["other_hits"] = max(0, len(hits) - 1)
        fallback["ok_fields"] = row.get("ok_fields") or []
    return fallback
