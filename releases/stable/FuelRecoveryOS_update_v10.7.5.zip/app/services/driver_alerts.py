"""乗務員の要注意判定 — 朝5分ビュー / ダッシュボードのヘルスマップの共通土台。

確定設計: docs/dev/改修設計_朝5分ビュー_確定_20260909.md

このモジュールが判定値(閾値)の唯一の正本(D-2 統合範囲②)。従来は
  - 指導書の自動判別  … coaching_list.html の JavaScript
  - ヘルスマップ      … dashboard.py のハードコード
  - 速度超過シート    … speed_sheet.py の独自キー
に判定が分かれていたが、いずれも本モジュールを参照する形へ寄せる。

集計は既存の coaching.get_driver_stats() と labor_check を使い、
新しい集計は書かない(数字が画面ごとに食い違わないようにするため)。

既定値は実データ(2026-01/02/03・16〜19名)で較正した値。根拠は確定設計 §2。
"""
import calendar
import json
from datetime import date

from sqlalchemy.orm import Session

from app.importers.nippo_trip import normalize_driver_code
from app.models.csv_import import TripReport
from app.models.master import Driver
from app.models.system import SystemSetting

SETTING_KEY = "coaching_auto_criteria"

# 判定条件の定義。default_warn=黄 / default_alert=赤。alert が None の条件は
# 赤を出さない(旧形式からの移行時に使う)。
CRITERIA_META = [
    {"field": "avg_score", "label": "総合評価点", "op": "lte", "unit": "点",
     "icon": "🏅",
     "how": "当月の全運行の平均",
     "default_warn": 70, "default_alert": 55, "enabled": True},
    {"field": "avg_safety", "label": "安全評価", "op": "lte", "unit": "点",
     "icon": "🛡",
     "how": "当月の全運行の平均",
     "default_warn": 70, "default_alert": 55, "enabled": True},
    {"field": "avg_economy", "label": "経済評価", "op": "lte", "unit": "点",
     "icon": "🌱",
     "how": "当月の全運行の平均",
     "default_warn": 70, "default_alert": 55, "enabled": True},
    {"field": "idle_rate", "label": "アイドリング率", "op": "gte", "unit": "%",
     "icon": "💤",
     "how": "当月の アイドリング時間 ÷ 稼働時間",
     "default_warn": 10, "default_alert": 15, "enabled": True},
    {"field": "events_per_100km", "label": "急操作/100km", "op": "gte", "unit": "回",
     "icon": "⚡",
     "how": "当月の 急加速+急減速+急発進 ÷ 走行距離",
     "default_warn": 5.0, "default_alert": 10.0, "enabled": True},
    {"field": "speed_over_100km", "label": "速度超過/100km", "op": "gte", "unit": "回",
     "icon": "🚦",
     "how": "当月の 速度超過の回数 ÷ 走行距離（速度超過シートの1日あたりの基準とは別）",
     "default_warn": 15, "default_alert": 25, "enabled": True},
]

# 旧 field 名 → 現 field 名。値ごと破棄するものは None。
# speed_over は「回/月」で、走行距離が月22km〜3494kmと開くため判定として
# 機能していなかった(確定設計 §2 発見2)。単位を回/100km に変えたので
# 旧設定値は引き継がず、新しい既定値を採用する。
LEGACY_FIELDS = {"speed_over": None}

# 旧版の既定値。保存値がこれと同じなら「顧客が決めた値」ではなく
# 「初期値のまま」とみなし、較正後の新しい既定値へ載せ替える。
# 顧客が実際に触った値(旧既定と違う値)は warn として残す。
OLD_DEFAULT_THRESHOLDS = {
    "avg_score": 70, "avg_safety": 70, "avg_economy": 70,
    "idle_rate": 15, "events_per_100km": 3.0, "speed_over": 5,
}

# 2段階化・既定ON への一回限りの移行フラグ(main.py の lifespan から実行)
MIGRATION_KEY = "migration_v1075_criteria_two_stage"

# 朝5分ビューで黄を何名まで出すか(赤は常に全員)。確定設計 §4.2。
WARN_LIMIT_KEY = "morning_warn_limit"
DEFAULT_WARN_LIMIT = 3

# ESTRA-Web2(デジタコ)が評価している指標。本システムは**合計点だけ**を受け取る。
# 評価対象項目は顧客が安全/経済にそれぞれ 3〜12 項目を選ぶ仕組みで、
# どの項目が点数を下げたのかは受け取っていない。したがって、これらの指標に
# 当システムが助言を書くと当てずっぽうになる(改修提案 20260916 案A)。
# 内訳・項目ごとのコメント・指導書は ESTRA-Web2 側が正本。
ESTRA_SCORE_FIELDS = ("avg_score", "avg_safety", "avg_economy")
ESTRA_DETAIL_HINT = "詳細分析 → レーダーチャート"

LABOR_FIELD = "labor_restrict_month"
LABOR_LABEL = "月間拘束"
LABOR_ICON = "⏱"

# labor_check.month_status() の戻り値 → 本モジュールのレベル
_LABOR_LEVEL = {"darkred": "alert", "red": "alert", "yellow": "warn", "blue": "ok"}

LEVELS = ("alert", "warn", "ok")


# ── 判定条件の読み出し ────────────────────────────────────────────

def default_criteria() -> list[dict]:
    """既定の判定条件(2段階)。"""
    return [{"field": m["field"], "label": m["label"], "op": m["op"], "unit": m["unit"],
             "warn": m["default_warn"], "alert": m["default_alert"], "enabled": m["enabled"]}
            for m in CRITERIA_META]


def normalize_criteria(saved) -> list[dict]:
    """保存値を現行形式へ正規化する。

    旧形式 {"threshold": x} は warn=x / alert=None(赤なし)として解釈し、
    既存顧客の設定を壊さない。LEGACY_FIELDS のものは読み捨てて既定値に戻す。
    """
    by_field = {}
    for c in (saved or []):
        if not isinstance(c, dict):
            continue
        f = c.get("field")
        if f in LEGACY_FIELDS:          # 単位変更などで引き継がない条件
            continue
        if f:
            by_field[f] = c

    out = []
    for m in CRITERIA_META:
        c = by_field.get(m["field"], {})
        if "warn" in c or "alert" in c:
            warn = _num(c.get("warn"), m["default_warn"])
            alert = _num(c.get("alert"), None)
        elif "threshold" in c:
            # 旧形式: 1段階しか無い。
            #  - 旧既定値のまま = 顧客の意思ではない → 較正後の新既定値へ載せ替える
            #  - 顧客が変えた値 = 尊重して黄に据え、赤は出さない(勝手に赤を作らない)
            old = _num(c.get("threshold"), None)
            if old is not None and old == OLD_DEFAULT_THRESHOLDS.get(m["field"]):
                warn, alert = m["default_warn"], m["default_alert"]
            else:
                warn, alert = _num(old, m["default_warn"]), None
        else:
            warn, alert = m["default_warn"], m["default_alert"]
        out.append({
            "field": m["field"], "label": m["label"], "op": m["op"], "unit": m["unit"],
            "warn": warn, "alert": alert,
            "enabled": bool(c.get("enabled", m["enabled"])),
        })
    return out


def load_criteria(db: Session) -> list[dict]:
    """DB の判定条件。未設定・壊れた値は既定値。"""
    row = db.query(SystemSetting).filter(SystemSetting.key == SETTING_KEY).first()
    if not row or not row.value:
        return default_criteria()
    saved = _load_json(row.value)
    if not saved:
        return default_criteria()
    return normalize_criteria(saved)


def _num(v, fallback):
    if v is None:
        return fallback
    try:
        f = float(v)
    except (TypeError, ValueError):
        return fallback
    return int(f) if f == int(f) else f


def is_default(c: dict) -> bool:
    """この条件が初期値のままか(設定画面の「変更あり」バッジ用)。"""
    for m in CRITERIA_META:
        if m["field"] == c["field"]:
            return (c.get("warn") == m["default_warn"]
                    and c.get("alert") == m["default_alert"]
                    and bool(c.get("enabled")) == m["enabled"])
    return True


def save_criteria(db: Session, criteria: list[dict]) -> None:
    """判定条件を保存する。保存形式は2段階(warn/alert)。"""
    payload = [{"field": c["field"], "label": c["label"], "op": c["op"], "unit": c["unit"],
                "warn": c["warn"], "alert": c["alert"], "enabled": bool(c["enabled"])}
               for c in criteria]
    _put(db, SETTING_KEY, json.dumps(payload, ensure_ascii=False), "指導書自動判別条件")


def get_warn_limit(db: Session) -> int:
    """朝5分ビューで黄を何名まで出すか。赤は常に全員出すので対象外。"""
    row = db.query(SystemSetting).filter(SystemSetting.key == WARN_LIMIT_KEY).first()
    try:
        v = int(float(row.value)) if row and row.value else DEFAULT_WARN_LIMIT
    except (TypeError, ValueError):
        return DEFAULT_WARN_LIMIT
    return max(1, min(50, v))


def set_warn_limit(db: Session, value) -> int:
    try:
        v = max(1, min(50, int(float(value))))
    except (TypeError, ValueError):
        v = DEFAULT_WARN_LIMIT
    _put(db, WARN_LIMIT_KEY, str(v), "朝5分ビュー: 注意(黄)の表示件数")
    return v


def _put(db: Session, key: str, value: str, description: str) -> None:
    from datetime import datetime
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    if row:
        row.value = value
        row.updated_at = datetime.now()
    else:
        db.add(SystemSetting(key=key, value=value, description=description,
                             updated_at=datetime.now()))


def migrate_criteria(db: Session) -> bool:
    """判定条件の2段階化・既定ONへの一回限りの移行(確定設計 §9)。

    - 旧形式(threshold 1段階)を warn/alert 形式へ書き換える
    - 旧既定値のままの条件は、実データで較正した新既定値へ載せ替える
    - enabled は既定(全条件ON)へ揃える。実データでは6条件すべてOFFの状態で
      保存されており、そのままでは判定が何も働かないため(確定設計 §2 発見3)

    戻り値: 実際に書き換えたら True。
    """
    if db.query(SystemSetting).filter(SystemSetting.key == MIGRATION_KEY).first():
        return False
    row = db.query(SystemSetting).filter(SystemSetting.key == SETTING_KEY).first()
    if row and row.value:
        merged = normalize_criteria(_load_json(row.value))
        for c in merged:                       # 既定ONへ揃える(挙動変更・要リリースノート)
            c["enabled"] = True
    else:
        merged = default_criteria()
    save_criteria(db, merged)
    _put(db, MIGRATION_KEY, "done", "判定条件の2段階化移行(v10.7.5)")
    db.commit()
    return True


def _load_json(value):
    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return []


# ── 1名分の判定 ──────────────────────────────────────────────────

def _hit(op: str, value, threshold) -> bool:
    if value is None or threshold is None:
        return False
    return value <= threshold if op == "lte" else value >= threshold


def _excess(op: str, value, threshold) -> float:
    """基準からの超過度(1.0 = ちょうど基準)。並び順の最終キーに使う。"""
    if value is None or not threshold:
        return 1.0
    try:
        return threshold / value if op == "lte" else value / threshold
    except ZeroDivisionError:
        return 1.0


def _hit_text(label, value, unit, op, threshold) -> str:
    side = "以下" if op == "lte" else "以上"
    return f"{label} {_fmt(value)}{unit}（基準 {_fmt(threshold)}{unit} {side}）"


def _fmt(v):
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return str(v)


def evaluate_driver(stats: dict, criteria: list[dict], labor: dict | None = None) -> dict:
    """1名分の判定。

    stats  : coaching.get_driver_stats() の戻り値 + speed_over_100km
    criteria: normalize_criteria() 済みの条件
    labor  : {"status": labor_check.month_status()の値, "total_h": float,
              "limit_h": int, "pct": int} or None

    戻り値: {"level": "alert"|"warn"|"ok", "hits": [...], "severity": (...)}
    """
    hits = []
    for c in criteria:
        if not c.get("enabled"):
            continue
        value = stats.get(c["field"])
        if value is None:
            continue
        if _hit(c["op"], value, c["alert"]):
            level, thr = "alert", c["alert"]
        elif _hit(c["op"], value, c["warn"]):
            level, thr = "warn", c["warn"]
        else:
            continue
        hits.append({
            "field": c["field"], "label": c["label"], "value": value, "unit": c["unit"],
            "op": c["op"], "warn": c["warn"], "alert": c["alert"],
            "threshold": thr, "level": level,
            "excess": round(_excess(c["op"], value, thr), 3),
            "text": _hit_text(c["label"], value, c["unit"], c["op"], thr),
        })

    if labor:
        level = _LABOR_LEVEL.get(labor.get("status"), "ok")
        if level != "ok":
            pct = labor.get("pct")
            limit_h = labor.get("limit_h")
            total_h = labor.get("total_h")
            hits.append({
                "field": LABOR_FIELD, "label": LABOR_LABEL, "value": total_h, "unit": "h",
                "op": "gte", "warn": None, "alert": None, "threshold": limit_h,
                "level": level, "excess": round((pct or 0) / 100.0, 3),
                "text": f"{LABOR_LABEL} {_fmt(total_h)}h（原則上限 {_fmt(limit_h)}h の {pct}%）",
            })

    n_alert = sum(1 for h in hits if h["level"] == "alert")
    n_warn = len(hits) - n_alert
    level = "alert" if n_alert else ("warn" if n_warn else "ok")
    max_excess = max([h["excess"] for h in hits], default=0.0)
    hits.sort(key=lambda h: (0 if h["level"] == "alert" else 1, -h["excess"]))
    return {
        "level": level,
        "hits": hits,
        "severity": (LEVELS.index(level), -n_alert, -n_warn, -max_excess),
    }


# ── 月次の一覧 ───────────────────────────────────────────────────

def _month_range(ym: str) -> tuple[date, date]:
    y, m = int(ym[:4]), int(ym[5:7])
    return date(y, m, 1), date(y, m, calendar.monthrange(y, m)[1])


def _office_match(office_code, office) -> bool:
    if not office or office in ("all", "ALL"):
        return True
    return (office_code or "") == office


def add_derived(stats: dict) -> dict:
    """判定に使う派生値を足す。speed_over は距離で正規化する(確定設計 §2 発見2)。"""
    dist_km = stats.get("dist_km") or 0
    stats["speed_over_100km"] = round((stats.get("speed_over") or 0)
                                      / max(dist_km / 100, 0.1), 1)
    return stats


def month_labor(db: Session, ym: str, office: str | None) -> dict[str, dict]:
    """正規化コード → 当月の拘束状況。FreeNippo確定値優先の既存経路をそのまま使う。"""
    from app.services import labor_check      # 遅延import(循環回避)
    limits = labor_check.get_labor_limits(db)
    limit_h = limits["labor_restrict_month_limit_h"]
    out = {}
    for r in labor_check.monthly_rows(db, ym, office, limits):
        total_h = round(r["total_sec"] / 3600, 1)
        out[normalize_driver_code(r["driver_code"])] = {
            "status": r["status"], "total_h": total_h, "limit_h": limit_h,
            "pct": int(round(total_h / limit_h * 100)) if limit_h else 0,
            "source": r.get("source"),
        }
    return out


def build_alert_list(db: Session, ym: str, office: str | None = None,
                     with_labor: bool = True,
                     criteria: list[dict] | None = None) -> dict:
    """当月の全乗務員を判定して赤→黄の順に返す。

    criteria を渡すと DB の設定ではなくその条件で判定する(設定画面のプレビュー用)。

    戻り値: {"alerts": [...], "warns": [...], "oks": [...],
             "ok_count": N, "total": M, "month": ym}
    表示件数の上限は掛けない(表示側の責務)。
    """
    from app.routers.coaching import get_driver_stats   # 遅延import(循環回避)

    m_start, m_end = _month_range(ym)
    trips = (db.query(TripReport)
             .filter(TripReport.operation_date >= m_start,
                     TripReport.operation_date <= m_end)
             .all())

    by_driver: dict[str, list] = {}
    fallback_name: dict[str, str] = {}
    for t in trips:
        if not _office_match(t.driver_office_code, office):
            continue
        code = t.driver_code or ""
        if not code:
            continue
        by_driver.setdefault(code, []).append(t)
        if t.driver_name and code not in fallback_name:
            fallback_name[code] = t.driver_name

    master = {d.code: d.name for d in db.query(Driver).all()}
    if criteria is None:
        criteria = load_criteria(db)
    labor_map = month_labor(db, ym, office) if with_labor else {}

    rows = []
    for code, ts in by_driver.items():
        stats = get_driver_stats(ts)
        if not stats:
            continue
        add_derived(stats)
        labor = labor_map.get(normalize_driver_code(code))
        result = evaluate_driver(stats, criteria, labor)
        rows.append({
            "code": code,
            # 氏名は drivers マスタ → 運行データの氏名 → コード の順で解決する。
            # マスタ未登録の乗務員が実データに存在する(確定設計 §2 発見4)。
            "name": master.get(code) or fallback_name.get(code) or code,
            "name_source": ("master" if master.get(code)
                            else "trip" if fallback_name.get(code) else "code"),
            "stats": stats,
            "labor": labor,
            "level": result["level"],
            "hits": result["hits"],
            "reason": result["hits"][0]["text"] if result["hits"] else "",
            "severity": result["severity"],
        })

    rows.sort(key=lambda r: (r["severity"], r["code"]))
    alerts = [r for r in rows if r["level"] == "alert"]
    warns = [r for r in rows if r["level"] == "warn"]
    oks = [r for r in rows if r["level"] == "ok"]
    return {"alerts": alerts, "warns": warns, "oks": oks,
            "ok_count": len(oks), "total": len(rows), "month": ym}


# ── 先手アラート(S-4 絞り込み版) ────────────────────────────────

# 何ヶ月連続で基準を超えたら「常習化」とみなすか。
STREAK_MONTHS = 3
STREAK_FIELD = "events_per_100km"


def _prev_ym(ym: str, back: int) -> str:
    y, m = int(ym[:4]), int(ym[5:7])
    m -= back
    while m <= 0:
        m += 12
        y -= 1
    return f"{y:04d}-{m:02d}"


def habitual_streak(db: Session, code: str, ym: str, criteria: list[dict],
                    field: str = STREAK_FIELD, months: int = STREAK_MONTHS,
                    history: dict[str, list] | None = None) -> int:
    """当月からさかのぼって、その項目が何ヶ月連続で黄基準を超えているか。

    予測はしない(確定設計 D-4)。過去の実績が続いているという事実だけを見る。
    運行の無い月は連続を切らずに読み飛ばす(休職・長期休暇で途切れないように)。
    連続月数の数え方は field_context() に一本化してある。
    history を渡すと問い合わせを1回に抑えられる(build_foresight が渡す)。
    """
    c = next((x for x in criteria if x["field"] == field and x["enabled"]), None)
    if not c:
        return 0
    hist = (history or month_stats_map(db, ym, months=months + 3)).get(code) or []
    return field_context(hist, field, c)["streak"]


# -- 声かけ文言のための文脈(段階6) ------------------------------

# さかのぼる月数。当月 + 過去3ヶ月あれば streak3plus まで判定できる。
# 運行の無い月を読み飛ばす余裕を持たせて、実際にはもう少し広く取る。
HISTORY_MONTHS = 4
HISTORY_SLACK = 3

# 文言テンプレートの状態。context/ux-copy/profile.md 6.2 と同じ4つ。
COPY_STATES = ("first", "streak2", "streak3plus", "improving")


def month_stats_map(db: Session, ym: str, office: str | None = None,
                    months: int = HISTORY_MONTHS + HISTORY_SLACK) -> dict[str, list]:
    """コード -> [当月, 先月, 先々月, ...] の stats。運行の無い月は None。

    1名ずつ月ごとに引くと 乗務員数 x 月数 回の問い合わせになるため、
    期間ぶんを1回で取ってから振り分ける。habitual_streak もこれを使う。
    """
    from app.routers.coaching import get_driver_stats   # 遅延import(循環回避)

    yms = [_prev_ym(ym, i) for i in range(months)]
    oldest, _ = _month_range(yms[-1])
    _, newest = _month_range(yms[0])
    trips = (db.query(TripReport)
             .filter(TripReport.operation_date >= oldest,
                     TripReport.operation_date <= newest)
             .all())

    idx = {m: i for i, m in enumerate(yms)}
    buckets: dict[str, list] = {}
    for t in trips:
        if not _office_match(t.driver_office_code, office):
            continue
        code = t.driver_code or ""
        if not code:
            continue
        i = idx.get(t.operation_date.strftime("%Y-%m"))
        if i is None:
            continue
        buckets.setdefault(code, [[] for _ in yms])[i].append(t)

    out: dict[str, list] = {}
    for code, per_month in buckets.items():
        row = []
        for ts in per_month:
            if not ts:
                row.append(None)
                continue
            st = get_driver_stats(ts)
            row.append(add_derived(st) if st else None)
        out[code] = row
    return out


def _direction_is_better(op: str, value, prev) -> str:
    """前月比。lte(低いほど悪い)は上がれば改善、gte は下がれば改善。"""
    if value is None or prev is None or value == prev:
        return "flat"
    better = value > prev if op == "lte" else value < prev
    return "improved" if better else "worse"


def field_context(history: list, field: str, criterion: dict) -> dict:
    """1項目分の文脈。history は month_stats_map の1名ぶん(0=当月)。

    - streak     : 当月からさかのぼって黄基準を超え続けている月数。
                   運行の無い月は連続を切らずに読み飛ばす(休職・長期休暇のため)。
    - prev_value : 直近で運行のあった前月の値(基準を超えたかは問わない)
    - trend      : improved / worse / flat
    - state      : 文言テンプレートの状態(profile 6.2)
    """
    op, warn = criterion["op"], criterion.get("warn")
    cur = (history[0] or {}).get(field) if history else None

    prev_value = None
    for st in history[1:]:
        if st is None:
            continue
        if st.get(field) is not None:
            prev_value = st.get(field)
            break

    streak = 0
    for st in history:
        if st is None:
            continue                    # 運行なし: 数えも切りもしない
        if _hit(op, st.get(field), warn):
            streak += 1
        else:
            break

    trend = _direction_is_better(op, cur, prev_value)
    if prev_value is None or streak <= 1:
        state = "first"
    elif trend == "improved":
        state = "improving"             # 前月より良いが、まだ基準を超えている
    elif streak >= 3:
        state = "streak3plus"
    else:
        state = "streak2"
    return {"state": state, "streak": streak, "prev_value": prev_value, "trend": trend}


def ok_fields(stats: dict, criteria: list[dict]) -> list[dict]:
    """基準内におさまっている項目。「ほかは問題ありません」と言うために要る。

    値の無い項目は「問題ない」とは言えないので入れない。
    """
    out = []
    for c in criteria:
        if not c.get("enabled"):
            continue
        v = stats.get(c["field"])
        if v is None:
            continue
        if not _hit(c["op"], v, c["warn"]) and not _hit(c["op"], v, c["alert"]):
            out.append({"field": c["field"], "label": c["label"],
                        "value": v, "unit": c["unit"]})
    return out


def attach_copy_context(db: Session, ym: str, rows: list[dict],
                        criteria: list[dict] | None = None,
                        office: str | None = None) -> list[dict]:
    """build_alert_list の行に、声かけ文言を選ぶための文脈を足す。

    各 hit に state / streak / prev_value / trend、各行に ok_fields を足す。
    表示のたびに過去分を引くので、**必要な画面だけが呼ぶ**(build_alert_list
    自体は重くしない)。

    月間拘束は criteria に無いため、前月の拘束実績から別途組み立てる。
    """
    if criteria is None:
        criteria = load_criteria(db)
    by_field = {c["field"]: c for c in criteria}
    hist = month_stats_map(db, ym, office)
    prev_labor = _prev_labor_map(db, ym, office)

    for r in rows:
        h = hist.get(r["code"]) or [r.get("stats")]
        for hit in r.get("hits", []):
            c = by_field.get(hit["field"])
            if c:
                hit.update(field_context(h, hit["field"], c))
            elif hit["field"] == LABOR_FIELD:
                hit.update(_labor_context(r, prev_labor))
        r["ok_fields"] = ok_fields(r.get("stats") or {}, criteria)
    return rows


def _prev_labor_map(db: Session, ym: str, office: str | None) -> dict[str, dict]:
    """先月の拘束実績。運行の無い月でも労務は付くので、月をさかのぼらない。"""
    try:
        return month_labor(db, _prev_ym(ym, 1), office)
    except Exception:                       # 労務データ未取込でも判定は続ける
        return {}


def _labor_context(row: dict, prev_labor: dict) -> dict:
    """月間拘束の文脈。連続月数は持たない(前月比だけを見る)。"""
    prev = prev_labor.get(normalize_driver_code(row["code"])) or {}
    prev_value = prev.get("total_h")
    cur = (row.get("labor") or {}).get("total_h")
    trend = _direction_is_better("gte", cur, prev_value)
    prev_over = _LABOR_LEVEL.get(prev.get("status")) in ("warn", "alert")
    if prev_value is None or not prev_over:
        state = "first"
    elif trend == "improved":
        state = "improving"
    else:
        state = "streak2"                   # 拘束は連続月数を数えていない
    return {"state": state, "streak": 2 if prev_over else 1,
            "prev_value": prev_value, "trend": trend}


def build_foresight(db: Session, ym: str, result: dict,
                    criteria: list[dict] | None = None) -> list[dict]:
    """先手アラート。今回は2系統だけ(確定設計 §6)。

      1. 急操作の常習化 … Nヶ月連続で基準超過
      2. 拘束の接近     … labor_check.month_status() の既存判定をそのまま使う

    「このペースだと月末に何時間」という外挿は次回。稼働日ベースか暦日ベースかの
    定義が未確定で、外れると労務判断を誤らせる方向に働くため。
    """
    if criteria is None:
        criteria = load_criteria(db)
    rows = result["alerts"] + result["warns"] + result["oks"]

    hist = month_stats_map(db, ym, months=STREAK_MONTHS + 3)
    habitual = []
    for r in rows:
        n = habitual_streak(db, r["code"], ym, criteria, history=hist)
        if n >= STREAK_MONTHS:
            habitual.append({"code": r["code"], "name": r["name"], "months": n,
                             "value": r["stats"].get(STREAK_FIELD)})
    habitual.sort(key=lambda x: (-x["months"], -(x["value"] or 0)))

    approaching = [{"code": r["code"], "name": r["name"],
                    "total_h": r["labor"]["total_h"], "limit_h": r["labor"]["limit_h"],
                    "pct": r["labor"]["pct"], "status": r["labor"]["status"]}
                   for r in rows if r.get("labor")
                   and _LABOR_LEVEL.get(r["labor"]["status"]) in ("warn", "alert")]
    approaching.sort(key=lambda x: -x["pct"])

    out = []
    if habitual:
        out.append({"key": "habitual", "icon": "⚡",
                    "title": "急操作が続いています",
                    "lead": f"{STREAK_MONTHS}ヶ月以上つづけて基準を超えている人が {len(habitual)}名",
                    "items": habitual,
                    "note": "1ヶ月だけの超過は出しません。連続した月数で見ています。"})
    if approaching:
        out.append({"key": "labor", "icon": "⏱",
                    "title": "拘束時間が上限に近づいています",
                    "lead": f"原則上限に近い人が {len(approaching)}名",
                    "items": approaching,
                    "note": "当月の実績値です。法令上の適合判定ではありません。"
                            "上限値・警告の割合は設定値です。"})
    return out


def preview_counts(db: Session, ym: str, criteria: list[dict] | None = None,
                   office: str | None = None) -> dict:
    """設定画面のプレビュー用。「この設定だと現在 赤N名 / 黄M名」。

    criteria 未指定なら現在の保存値で数える。保存前の値を渡せば、
    その設定にしたときの人数を保存せずに確認できる。
    """
    r = build_alert_list(db, ym, office, criteria=criteria)
    return {"alert": len(r["alerts"]), "warn": len(r["warns"]),
            "ok": r["ok_count"], "total": r["total"]}
