"""Fuel data input router — manual entry and invoice import (tabs)."""
import csv
import io
from collections import defaultdict
from datetime import date, datetime

from fastapi import APIRouter, Depends, Query, Request, UploadFile, File, Form
from fastapi.responses import RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.importers.base import normalize_year_month, parse_flexible_date
from app.models.fuel_input import MonthlyFuelInput, DailyFuelInput
from app.models.fuel_invoice import FuelInvoice
from app.models.csv_import import TripReport
from app.models.master import Vehicle
from app.routers.month_utils import resolve_base_month, month_last_day, month_context
from app.routers.settings_router import get_fuel_price, DEFAULT_BASELINE_EFFICIENCY
from app.services import fuel_invoice_sync as fis

router = APIRouter(prefix="/fuel", tags=["fuel"])
templates = Jinja2Templates(directory="app/templates")


def _opt_int(v: str | None) -> int | None:
    """フォームの空文字 ("") を None に倒し、それ以外は int 変換。
    FastAPI は Form(None) の int 直バインドだと "" を渡された時に
    int_parsing エラーで 422 を返してしまうため、空欄許容フィールドは
    一旦 str で受けてからこの helper を通す。
    """
    if v is None or not v.strip():
        return None
    return int(v)


def _opt_float(v: str | None) -> float | None:
    if v is None or not v.strip():
        return None
    return float(v)


def _resolve_period(
    db: Session, request: Request, start: str | None, end: str | None
) -> tuple[date, date, bool]:
    """カスタム期間優先、無ければ基軸月。"""
    if start and end:
        try:
            s = datetime.strptime(start, "%Y-%m-%d").date()
            e = datetime.strptime(end, "%Y-%m-%d").date()
            if s <= e:
                return s, e, True
        except ValueError:
            pass
    base = resolve_base_month(db, request.cookies.get("base_month"))
    return base, month_last_day(base), False


def _build_invoice_view(
    db: Session, period_start: date, period_end: date, category: str
) -> dict:
    """請求明細ビュー用データを集計。

    category: 'all' / 'diesel' / 'gasoline' / 'fuel_only'(diesel+gasoline) /
              'additive' / 'oil' / 'other'
    """
    q = db.query(FuelInvoice).filter(
        FuelInvoice.transaction_date >= period_start,
        FuelInvoice.transaction_date <= period_end,
    )
    if category == "fuel_only":
        q = q.filter(FuelInvoice.product_category.in_(["diesel", "gasoline"]))
    elif category != "all":
        q = q.filter(FuelInvoice.product_category == category)
    invoices = q.order_by(
        FuelInvoice.transaction_date.desc(),
        FuelInvoice.vehicle_no,
        FuelInvoice.line_number,
    ).all()

    # 車両別集計
    by_vehicle: dict[str, dict] = defaultdict(lambda: {
        "vehicle_no": "",
        "fuel_qty": 0.0,
        "fuel_cost": 0,
        "fuel_count": 0,
        "other_cost": 0,
        "other_count": 0,
        "stations": set(),
    })
    cat_totals: dict[str, dict] = defaultdict(lambda: {"qty": 0.0, "cost": 0, "count": 0})

    for inv in invoices:
        v = by_vehicle[inv.vehicle_no or ""]
        v["vehicle_no"] = inv.vehicle_no or ""
        cost = inv.amount_total or 0
        qty = inv.quantity or 0.0
        cat = inv.product_category or "other"
        if cat in ("diesel", "gasoline"):
            v["fuel_qty"] += qty
            v["fuel_cost"] += cost
            v["fuel_count"] += 1
        else:
            v["other_cost"] += cost
            v["other_count"] += 1
        if inv.station_name:
            v["stations"].add(inv.station_name)
        cat_totals[cat]["qty"] += qty
        cat_totals[cat]["cost"] += cost
        cat_totals[cat]["count"] += 1

    vehicle_summary = []
    for v in by_vehicle.values():
        avg_unit = round(v["fuel_cost"] / v["fuel_qty"]) if v["fuel_qty"] > 0 else 0
        vehicle_summary.append({
            "vehicle_no": v["vehicle_no"],
            "fuel_qty": round(v["fuel_qty"], 2),
            "fuel_cost": v["fuel_cost"],
            "fuel_count": v["fuel_count"],
            "avg_unit_price": avg_unit,
            "other_cost": v["other_cost"],
            "other_count": v["other_count"],
            "total_cost": v["fuel_cost"] + v["other_cost"],
            "stations": ", ".join(sorted(v["stations"])) if v["stations"] else "",
        })
    vehicle_summary.sort(key=lambda x: -x["total_cost"])

    grand_total = {
        "fuel_qty": round(sum(v["fuel_qty"] for v in vehicle_summary), 2),
        "fuel_cost": sum(v["fuel_cost"] for v in vehicle_summary),
        "other_cost": sum(v["other_cost"] for v in vehicle_summary),
        "total_cost": sum(v["total_cost"] for v in vehicle_summary),
        "row_count": len(invoices),
    }

    # カテゴリ別合計(チップ表示用)
    category_totals = []
    cat_label = {"diesel": "軽油", "gasoline": "ガソリン",
                 "additive": "添加剤", "oil": "オイル", "other": "その他"}
    for k, v in cat_totals.items():
        category_totals.append({
            "key": k, "label": cat_label.get(k, k),
            "count": v["count"], "qty": round(v["qty"], 2), "cost": v["cost"],
        })
    category_totals.sort(key=lambda x: -x["cost"])

    return {
        "invoices": invoices,
        "vehicle_summary": vehicle_summary,
        "grand_total": grand_total,
        "category_totals": category_totals,
    }


PAGE_SIZE_MONTHLY = 20
_SORT_KEYS = {
    "year_month": lambda d: (d["year_month"] or "", d["vehicle_code"] or ""),
    "vehicle_code": lambda d: (d["vehicle_code"] or "", d["year_month"] or ""),
    "fuel_l": lambda d: (d["fuel_l"] if d["fuel_l"] is not None else -1,),
    "fuel_yen": lambda d: (d["fuel_yen"] if d["fuel_yen"] is not None else -1,),
    "unit_price": lambda d: (d["unit_price"] if d["unit_price"] is not None else -1,),
    "distance_km": lambda d: (d["distance_km"] if d["distance_km"] is not None else -1,),
    "efficiency": lambda d: (d["efficiency"] if d["efficiency"] is not None else -1,),
}


@router.get("/estimated")
async def fuel_estimated(request: Request, office: str = Query("all"),
                        db: Session = Depends(get_db)):
    """推定残 車両一覧 — 基軸月に運行があるのに実給油が未入力の車両を列挙。

    これらの車両はダッシュボードで「推定燃費」として集計される。実給油を入力すると
    実績へ自動的に置き換わり、損失額の精度が上がる（後追い解消の運用支援）。
    """
    base = resolve_base_month(db, request.cookies.get("base_month"))
    ym = base.strftime("%Y-%m")
    last = month_last_day(base)
    fuel_price = get_fuel_price(db, ym)

    q = db.query(
        TripReport.vehicle_code,
        func.max(TripReport.vehicle_name),
        func.sum(TripReport.distance_m),
    ).filter(TripReport.operation_date >= base, TripReport.operation_date <= last)
    if office and office not in ("all", "ALL"):
        q = q.filter(TripReport.driver_office_code == office)
    trip_vehicles = q.group_by(TripReport.vehicle_code).all()

    actual = {
        m.vehicle_code for m in db.query(MonthlyFuelInput.vehicle_code).filter(
            MonthlyFuelInput.year_month == ym,
            MonthlyFuelInput.fuel_amount_l.isnot(None),
            MonthlyFuelInput.fuel_amount_l > 0,
        ).all()
    }
    eff_map = {v.code: (v.baseline_efficiency_kml or DEFAULT_BASELINE_EFFICIENCY)
               for v in db.query(Vehicle).all()}

    rows = []
    tot_l = 0.0
    tot_yen = 0
    for vc, vname, dist_m in trip_vehicles:
        if not vc or vc in actual:
            continue
        dist_km = (dist_m or 0) / 1000
        eff = eff_map.get(vc, DEFAULT_BASELINE_EFFICIENCY)
        est_l = dist_km / eff if eff else 0
        est_yen = int(est_l * fuel_price)
        tot_l += est_l
        tot_yen += est_yen
        rows.append({
            "vehicle_code": vc,
            "vehicle_name": vname or vc,
            "distance_km": round(dist_km, 1),
            "baseline_eff": round(eff, 1),
            "est_l": round(est_l, 1),
            "est_yen": est_yen,
        })
    rows.sort(key=lambda r: r["est_l"], reverse=True)

    offices = [{"code": o[0], "name": o[1] or o[0]} for o in
               db.query(TripReport.driver_office_code, func.max(TripReport.driver_office_name))
               .filter(TripReport.driver_office_code.isnot(None))
               .group_by(TripReport.driver_office_code).all()]

    return templates.TemplateResponse("fuel_estimated.html", {
        "request": request,
        "current_page": "fuel",
        "rows": rows,
        "total_l": round(tot_l, 1),
        "total_yen": tot_yen,
        "ym": ym,
        "base": base,
        "offices": offices,
        "selected_office": office,
        **month_context(db, request.cookies.get("base_month")),
    })


@router.get("")
async def fuel_list(
    request: Request, db: Session = Depends(get_db),
    tab: str = Query("manual"),
    start: str | None = Query(None),
    end: str | None = Query(None),
    category: str = Query("all"),
    upload_msg: str | None = Query(None),
    # 月次手入力テーブル用フィルタ/ソート/ページ
    filter_vehicle: str = Query(""),
    filter_month: str = Query(""),
    sort: str = Query("year_month"),
    order: str = Query("desc"),
    page: int = Query(1, ge=1),
    error: str | None = Query(None),
):
    """Show fuel data overview and input forms.

    tab='manual'  : 手入力タブ(既存)
    tab='invoice' : 請求明細タブ(新規)
    """
    vehicles = db.query(Vehicle).filter(Vehicle.is_active == 1).order_by(Vehicle.code).all()

    # Get monthly fuel data — filter at SQL level when possible
    q = db.query(MonthlyFuelInput)
    if filter_vehicle:
        q = q.filter(MonthlyFuelInput.vehicle_code == filter_vehicle)
    if filter_month:
        q = q.filter(MonthlyFuelInput.year_month == filter_month)
    monthly = q.order_by(
        MonthlyFuelInput.year_month.desc(), MonthlyFuelInput.vehicle_code
    ).all()

    # Get daily fuel data (last 50 entries)
    daily = db.query(DailyFuelInput).order_by(
        DailyFuelInput.fill_date.desc()
    ).limit(50).all()

    # Calculate fuel efficiency per vehicle per month
    efficiency_data = []
    for m in monthly:
        # Get total distance for this vehicle in this month
        year, month_num = m.year_month.split("-")
        month_start = date(int(year), int(month_num), 1)
        if int(month_num) == 12:
            month_end = date(int(year) + 1, 1, 1)
        else:
            month_end = date(int(year), int(month_num) + 1, 1)

        total_dist = db.query(func.sum(TripReport.distance_m)).filter(
            TripReport.vehicle_code == m.vehicle_code,
            TripReport.operation_date >= month_start,
            TripReport.operation_date < month_end,
        ).scalar() or 0

        dist_km = total_dist / 1000
        efficiency = (
            round(dist_km / m.fuel_amount_l, 2)
            if m.fuel_amount_l and m.fuel_amount_l > 0 else None
        )
        unit_price = (
            round(m.fuel_cost_yen / m.fuel_amount_l)
            if m.fuel_amount_l and m.fuel_cost_yen else None
        )

        efficiency_data.append({
            "id": m.id,
            "vehicle_code": m.vehicle_code,
            "vehicle_name": m.vehicle_name,
            "year_month": m.year_month,
            "fuel_l": m.fuel_amount_l,
            "fuel_yen": m.fuel_cost_yen,
            "unit_price": unit_price,
            "distance_km": round(dist_km, 1),
            "efficiency": efficiency,
            "source": m.source,
            "note": m.note,
        })

    # Sort (default: year_month desc → vehicle_code asc)
    sort_key = _SORT_KEYS.get(sort, _SORT_KEYS["year_month"])
    reverse = (order == "desc")
    efficiency_data.sort(key=sort_key, reverse=reverse)

    # Pagination
    total_rows = len(efficiency_data)
    total_pages = max(1, (total_rows + PAGE_SIZE_MONTHLY - 1) // PAGE_SIZE_MONTHLY)
    page = min(page, total_pages)
    start_idx = (page - 1) * PAGE_SIZE_MONTHLY
    efficiency_data_page = efficiency_data[start_idx:start_idx + PAGE_SIZE_MONTHLY]

    # Available months for form dropdown (strings like "2026-03")
    months_raw = db.query(
        func.distinct(func.strftime("%Y-%m", TripReport.operation_date))
    ).order_by(func.strftime("%Y-%m", TripReport.operation_date).desc()).all()
    month_options = [m[0] for m in months_raw if m[0]]
    # フィルタ用の対象月候補は、現に DB にある手入力月の集合
    months_with_input = sorted({d["year_month"] for d in efficiency_data}, reverse=True)

    # 請求明細タブ用データ(タブ非選択でもサマリーは渡す)
    period_start, period_end, custom_period = _resolve_period(db, request, start, end)
    invoice_view = _build_invoice_view(db, period_start, period_end, category)

    # マッピングタブ用データ
    mapping_rows, mapping_vehicle_choices = fis.list_invoice_vehicle_nos(db)
    fuel_priority = fis.get_priority(db)

    if tab == "invoice":
        active_tab = "invoice"
    elif tab == "mapping":
        active_tab = "mapping"
    else:
        active_tab = "manual"

    return templates.TemplateResponse("fuel.html", {
        "request": request,
        "current_page": "fuel",
        "vehicles": vehicles,
        "efficiency_data": efficiency_data_page,
        "daily_records": daily,
        "month_options": month_options,
        "months_with_input": months_with_input,
        "filter_vehicle": filter_vehicle,
        "filter_month": filter_month,
        "sort": sort,
        "order": order,
        "page": page,
        "total_pages": total_pages,
        "total_rows": total_rows,
        "page_size": PAGE_SIZE_MONTHLY,
        "error": error,
        # invoice tab
        "active_tab": active_tab,
        "period_start": period_start,
        "period_end": period_end,
        "custom_period": custom_period,
        "category_filter": category,
        "invoices": invoice_view["invoices"],
        "invoice_vehicle_summary": invoice_view["vehicle_summary"],
        "invoice_grand_total": invoice_view["grand_total"],
        "invoice_category_totals": invoice_view["category_totals"],
        "upload_msg": upload_msg,
        # mapping tab
        "mapping_rows": mapping_rows,
        "mapping_vehicle_choices": mapping_vehicle_choices,
        "fuel_priority": fuel_priority,
        # 推定の根拠表示(実データ)
        "default_efficiency": DEFAULT_BASELINE_EFFICIENCY,
        "fuel_price": get_fuel_price(
            db, resolve_base_month(db, request.cookies.get("base_month")).strftime("%Y-%m")),
        **month_context(db, request.cookies.get("base_month")),
    })


@router.post("/invoice/mapping/save")
async def save_invoice_mapping(
    request: Request,
    invoice_vehicle_no: str = Form(...),
    vehicle_code: str = Form(""),
    note: str = Form(""),
    db: Session = Depends(get_db),
):
    """1件のマッピングを保存。空文字 vehicle_code は対象外として保存。"""
    fis.upsert_mapping(db, invoice_vehicle_no, vehicle_code or None, note)
    return RedirectResponse(url="/fuel?tab=mapping", status_code=303)


@router.post("/invoice/priority")
async def set_fuel_priority(
    request: Request,
    priority: str = Form(...),
    db: Session = Depends(get_db),
):
    """同月にデータが重複した場合の優先(manual/invoice)を設定。"""
    try:
        fis.set_priority(db, priority)
    except ValueError:
        pass
    return RedirectResponse(url="/fuel?tab=mapping", status_code=303)


@router.post("/invoice/sync")
async def sync_invoice_now(request: Request, db: Session = Depends(get_db)):
    """請求明細 → 月次給油 への同期を即時実行。"""
    import urllib.parse
    summary = fis.sync_to_monthly(db)
    msg = (f"同期完了: 新規 {summary['created']} 件 / "
           f"更新 {summary['updated']} 件 / "
           f"手入力の欠けたフィールドを補完 {summary.get('merged_manual', 0)} 件 / "
           f"手入力優先で保留 {summary['skipped_manual_priority']} 件 / "
           f"未紐付け {summary['no_mapping']} 件 / "
           f"対象外 {summary['ignored']} 件")
    return RedirectResponse(
        url=f"/fuel?tab=mapping&upload_msg={urllib.parse.quote(msg)}",
        status_code=303,
    )


@router.post("/invoice/upload")
async def upload_invoice(
    request: Request,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """請求書 CSV を手動アップロードして取込。

    アップロード後 /fuel?tab=invoice にリダイレクト、
    取込結果メッセージを upload_msg クエリで渡す。
    """
    import tempfile
    import urllib.parse
    from pathlib import Path
    from app.importers import fuel_invoice as fip

    if not file.filename:
        msg = "ファイル名が空です。"
        return RedirectResponse(
            url=f"/fuel?tab=invoice&upload_msg={urllib.parse.quote(msg)}",
            status_code=303,
        )

    # 一時ディレクトリにオリジナル名で保存(アダプタ判定はファイル名依存)
    tmpdir = Path(tempfile.mkdtemp(prefix="fros_invoice_"))
    saved_path = tmpdir / file.filename
    try:
        content = await file.read()
        saved_path.write_bytes(content)
        result = fip.import_file(saved_path, db)
    finally:
        try:
            saved_path.unlink(missing_ok=True)
            tmpdir.rmdir()
        except Exception:
            pass

    if result.get("status") == "unknown_format":
        msg = f"{file.filename}: 対応するフォーマットがありません(ファイル名が「請求書_*.csv」形式か確認してください)"
    elif result.get("status") == "error":
        msg = f"{file.filename}: 取込エラー — {result.get('detail','')}"
    else:
        msg = (f"{file.filename} ({result.get('format','')}): "
               f"取込 {result.get('imported',0)} 件 / "
               f"重複スキップ {result.get('skipped_dup',0)} 件 / "
               f"エラー {result.get('errors',0)} 件")
        sync = result.get("sync") or {}
        if sync:
            msg += (f" / 月次給油同期: 新規 {sync.get('created',0)}, "
                    f"更新 {sync.get('updated',0)}, "
                    f"未紐付け {sync.get('no_mapping',0)}")
            if sync.get("no_mapping", 0) > 0:
                msg += " ※「車番マッピング」タブで紐付けしてください"
    return RedirectResponse(
        url=f"/fuel?tab=invoice&upload_msg={urllib.parse.quote(msg)}",
        status_code=303,
    )


@router.get("/invoice.csv")
async def invoice_csv(
    request: Request, db: Session = Depends(get_db),
    start: str | None = Query(None),
    end: str | None = Query(None),
    category: str = Query("all"),
):
    """請求明細を CSV ダウンロード(UTF-8 BOM)。"""
    period_start, period_end, _ = _resolve_period(db, request, start, end)
    iv = _build_invoice_view(db, period_start, period_end, category)

    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow([
        "請求年月日", "顧客名", "車番", "取引年月日", "伝票番号", "行番号",
        "商品コード", "商品名", "カテゴリ", "数量", "単価",
        "金額(税抜)", "消費税", "軽油税", "金額合計", "スタンド名",
        "ソース",
    ])
    cat_label = {"diesel": "軽油", "gasoline": "ガソリン",
                 "additive": "添加剤", "oil": "オイル", "other": "その他"}
    for inv in iv["invoices"]:
        w.writerow([
            inv.billing_date.strftime("%Y/%m/%d") if inv.billing_date else "",
            inv.customer_name or "",
            inv.vehicle_no or "",
            inv.transaction_date.strftime("%Y/%m/%d") if inv.transaction_date else "",
            inv.slip_number or "",
            inv.line_number or "",
            inv.product_code or "",
            inv.product_name or "",
            cat_label.get(inv.product_category, inv.product_category or ""),
            inv.quantity if inv.quantity is not None else "",
            inv.unit_price if inv.unit_price is not None else "",
            inv.amount_excl_tax or "",
            inv.consumption_tax or "",
            inv.diesel_tax or "",
            inv.amount_total or "",
            inv.station_name or "",
            inv.source_format or "",
        ])
    body = "\ufeff" + buf.getvalue()
    filename = f"fuel_invoice_{period_start:%Y%m%d}_{period_end:%Y%m%d}.csv"
    return StreamingResponse(
        iter([body.encode("utf-8")]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/monthly")
async def add_monthly_fuel(
    request: Request,
    vehicle_code: str = Form(...),
    year_month: str = Form(...),
    fuel_amount_l: str | None = Form(None),
    fuel_cost_yen: str | None = Form(None),
    note: str = Form(""),
    db: Session = Depends(get_db),
):
    """月次給油 - 手入力で新規 or upsert。

    必須:           vehicle_code, year_month
    いずれか必須:   fuel_amount_l, fuel_cost_yen  (片方だけでも保存可)
    任意:           note
    """
    import urllib.parse
    amount = _opt_float(fuel_amount_l)
    cost = _opt_int(fuel_cost_yen)
    if amount is None and cost is None:
        msg = "給油量と給油金額のどちらか一方は入力してください。"
        return RedirectResponse(
            url=f"/fuel?error={urllib.parse.quote(msg)}",
            status_code=303,
        )

    vehicle = db.query(Vehicle).filter(Vehicle.code == vehicle_code).first()
    vehicle_name = vehicle.name if vehicle else None
    unit_price = round(cost / amount) if cost and amount else None

    # Check if record exists for this vehicle+month
    existing = db.query(MonthlyFuelInput).filter(
        MonthlyFuelInput.vehicle_code == vehicle_code,
        MonthlyFuelInput.year_month == year_month,
    ).first()

    if existing:
        existing.fuel_amount_l = amount
        existing.fuel_cost_yen = cost
        existing.fuel_unit_price = unit_price
        existing.note = note
        existing.source = "manual"
        existing.updated_at = datetime.now()
    else:
        record = MonthlyFuelInput(
            vehicle_code=vehicle_code,
            vehicle_name=vehicle_name,
            year_month=year_month,
            fuel_amount_l=amount,
            fuel_cost_yen=cost,
            fuel_unit_price=unit_price,
            source="manual",
            note=note,
        )
        db.add(record)

    db.commit()
    return RedirectResponse(url="/fuel", status_code=303)


@router.get("/monthly/edit/{record_id}")
async def edit_monthly_fuel_form(
    request: Request, record_id: int, db: Session = Depends(get_db),
):
    """編集フォーム表示。手入力 (source=manual) のみ編集対象。

    invoice 由来 / CSV 取込由来は元データ保護のため編集不可。URL を直叩き
    された場合もここで弾く (UI 側のボタンも source=manual のみ表示)。
    """
    import urllib.parse
    rec = db.query(MonthlyFuelInput).filter(
        MonthlyFuelInput.id == record_id
    ).first()
    if rec is None:
        return RedirectResponse(url="/fuel?error=not_found", status_code=303)
    if (rec.source or "manual") != "manual":
        msg = "手入力以外のデータ (請求明細 / CSV取込) は編集できません。元データを変更してください。"
        return RedirectResponse(
            url=f"/fuel?error={urllib.parse.quote(msg)}", status_code=303,
        )
    vehicles = db.query(Vehicle).filter(Vehicle.is_active == 1).order_by(Vehicle.code).all()
    return templates.TemplateResponse("fuel_monthly_edit.html", {
        "request": request,
        "current_page": "fuel",
        "record": rec,
        "vehicles": vehicles,
        **month_context(db, request.cookies.get("base_month")),
    })


@router.post("/monthly/edit/{record_id}")
async def update_monthly_fuel(
    request: Request,
    record_id: int,
    vehicle_code: str = Form(...),
    year_month: str = Form(...),
    fuel_amount_l: str | None = Form(None),
    fuel_cost_yen: str | None = Form(None),
    note: str = Form(""),
    db: Session = Depends(get_db),
):
    """既存の月次給油エントリを編集保存。"""
    import urllib.parse
    rec = db.query(MonthlyFuelInput).filter(
        MonthlyFuelInput.id == record_id
    ).first()
    if rec is None:
        return RedirectResponse(url="/fuel?error=not_found", status_code=303)
    if (rec.source or "manual") != "manual":
        msg = "手入力以外のデータは編集できません。"
        return RedirectResponse(
            url=f"/fuel?error={urllib.parse.quote(msg)}", status_code=303,
        )

    amount = _opt_float(fuel_amount_l)
    cost = _opt_int(fuel_cost_yen)
    if amount is None and cost is None:
        msg = "給油量と給油金額のどちらか一方は入力してください。"
        return RedirectResponse(
            url=f"/fuel/monthly/edit/{record_id}?error={urllib.parse.quote(msg)}",
            status_code=303,
        )

    # (vehicle_code, year_month) を変更する場合は同キーの他行と衝突しないか確認。
    # MonthlyFuelInput に UNIQUE 制約は無いので、ここでアプリ側で守る。
    if vehicle_code != rec.vehicle_code or year_month != rec.year_month:
        conflict = db.query(MonthlyFuelInput).filter(
            MonthlyFuelInput.vehicle_code == vehicle_code,
            MonthlyFuelInput.year_month == year_month,
            MonthlyFuelInput.id != record_id,
        ).first()
        if conflict is not None:
            msg = (
                f"既に同じ車両 ({vehicle_code}) + 対象月 ({year_month}) のデータが"
                f"存在します。先にそちらを削除または編集してください。"
            )
            return RedirectResponse(
                url=f"/fuel/monthly/edit/{record_id}?error={urllib.parse.quote(msg)}",
                status_code=303,
            )

    vehicle = db.query(Vehicle).filter(Vehicle.code == vehicle_code).first()
    rec.vehicle_code = vehicle_code
    rec.vehicle_name = vehicle.name if vehicle else rec.vehicle_name
    rec.year_month = year_month
    rec.fuel_amount_l = amount
    rec.fuel_cost_yen = cost
    rec.fuel_unit_price = round(cost / amount) if cost and amount else None
    rec.note = note
    rec.source = "manual"
    rec.updated_at = datetime.now()
    db.commit()
    return RedirectResponse(url="/fuel", status_code=303)


@router.post("/daily")
async def add_daily_fuel(
    request: Request,
    vehicle_code: str = Form(...),
    fill_date: str = Form(...),
    fuel_amount_l: float = Form(...),
    fuel_cost_yen: str | None = Form(None),
    odometer_km: str | None = Form(None),
    station_name: str = Form(""),
    note: str = Form(""),
    db: Session = Depends(get_db),
):
    """Add single fuel record."""
    cost = _opt_int(fuel_cost_yen)
    odo = _opt_float(odometer_km)

    vehicle = db.query(Vehicle).filter(Vehicle.code == vehicle_code).first()
    unit_price = round(cost / fuel_amount_l) if cost and fuel_amount_l else None

    record = DailyFuelInput(
        vehicle_code=vehicle_code,
        vehicle_name=vehicle.name if vehicle else None,
        fill_date=date.fromisoformat(fill_date),
        fuel_amount_l=fuel_amount_l,
        fuel_cost_yen=cost,
        fuel_unit_price=unit_price,
        odometer_km=odo,
        station_name=station_name or None,
        source="manual",
        note=note or None,
    )
    db.add(record)
    db.commit()
    return RedirectResponse(url="/fuel", status_code=303)


@router.post("/csv-import")
async def import_fuel_csv(
    request: Request,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Import fuel data from CSV file.

    Expected columns (flexible matching):
    - vehicle_code or car number or vehicle
    - year_month or date or fill_date
    - fuel_amount or amount or liters
    - fuel_cost or cost or amount_yen
    """
    content = await file.read()
    # Try multiple encodings
    for enc in ["utf-8-sig", "utf-8", "cp932", "shift_jis"]:
        try:
            text = content.decode(enc)
            break
        except (UnicodeDecodeError, ValueError):
            continue
    else:
        # 不完全なコンテキストでのテンプレート描画は UndefinedError で 500 に
        # なるため、他のエラーと同様に upload_msg で返す (v10.7.4)
        import urllib.parse
        msg = ("CSVの文字コードを判定できません。"
               "UTF-8 または Shift_JIS で保存し直してください。")
        return RedirectResponse(
            url=f"/fuel?tab=manual&upload_msg={urllib.parse.quote(msg)}",
            status_code=303,
        )

    reader = csv.DictReader(io.StringIO(text))
    monthly_imported = 0
    daily_imported = 0
    skipped_dup = 0
    dup_updated = 0
    errors = []

    # Column name mapping (flexible)
    col_map = {}
    if reader.fieldnames:
        for col in reader.fieldnames:
            cl = col.strip().lower()
            if any(k in cl for k in ["vehicle", "car", "truck"]) or col.strip() in ["vehicle_code"]:
                col_map["vehicle_code"] = col
            elif any(k in cl for k in ["month", "year_month", "ym"]) or col.strip() in ["year_month"]:
                col_map["year_month"] = col
            elif any(k in cl for k in ["date", "fill_date"]) and "year" not in cl:
                col_map["fill_date"] = col
            elif any(k in cl for k in ["amount", "liter", "fuel_amount", "liters"]) and "cost" not in cl and "yen" not in cl:
                col_map["fuel_amount"] = col
            elif any(k in cl for k in ["cost", "yen", "price", "fuel_cost"]):
                col_map["fuel_cost"] = col
            elif any(k in cl for k in ["note", "memo"]):
                col_map["note"] = col

    # 必須列がヘッダーに無い場合は、全行が黙ってスキップされる前に
    # ファイル単位の理由を返す (v10.7.4)
    if "vehicle_code" not in col_map or (
            "year_month" not in col_map and "fill_date" not in col_map):
        import urllib.parse
        missing = ("車両列 (vehicle_code)" if "vehicle_code" not in col_map
                   else "年月列 (year_month) または給油日列 (fill_date)")
        msg = (f"{file.filename or 'CSV'}: 取込できません — "
               f"{missing} が見つかりません。ヘッダー行をご確認ください。")
        return RedirectResponse(
            url=f"/fuel?tab=manual&upload_msg={urllib.parse.quote(msg)}",
            status_code=303,
        )

    # 日次の重複判定用に既存行を事前ロード。SessionLocal は autoflush=False の
    # ため行ごとのDB照会では同一ファイル内の重複が見えず、N+1 にもなる (v10.7.4)
    existing_daily = {
        (r.vehicle_code, r.fill_date, r.fuel_amount_l): r
        for r in db.query(DailyFuelInput).all()
    }

    for i, row in enumerate(reader, 2):
        try:
            vc = row.get(col_map.get("vehicle_code", ""), "").strip()
            if not vc:
                continue

            amount_str = row.get(col_map.get("fuel_amount", ""), "").strip()
            cost_str = row.get(col_map.get("fuel_cost", ""), "").strip()
            amount = float(amount_str.replace(",", "")) if amount_str else None
            cost = int(float(cost_str.replace(",", ""))) if cost_str else None

            # 両方空ならスキップ (vehicle/month だけの空行に意味は無い)。
            if amount is None and cost is None:
                errors.append(f"{i}行目: 給油量・金額とも空欄のためスキップ")
                continue

            # どちらかが欠けている = 「部分取込」として識別可能なフラグを立てる。
            # 一覧で 'CSV取込(部分)' バッジで判別できるようにする。
            is_partial = (amount is None) or (cost is None)
            src = "csv_import_partial" if is_partial else "csv_import"

            note = row.get(col_map.get("note", ""), "").strip()

            # Determine if monthly or daily
            ym = row.get(col_map.get("year_month", ""), "").strip()
            fd = row.get(col_map.get("fill_date", ""), "").strip()

            vehicle = db.query(Vehicle).filter(Vehicle.code == vc).first()
            vname = vehicle.name if vehicle else None
            unit_price = round(cost / amount) if cost and amount else None

            if ym:
                # Monthly record — 年月の表記揺れは正規化し、不正値は保存前に
                # 弾く (不正な year_month は月次燃費実績の描画を 500 で落とす)
                ym_norm = normalize_year_month(ym)
                if ym_norm is None:
                    errors.append(f"{i}行目: 年月「{ym}」を解釈できません")
                    continue
                existing = db.query(MonthlyFuelInput).filter(
                    MonthlyFuelInput.vehicle_code == vc,
                    MonthlyFuelInput.year_month == ym_norm,
                ).first()
                if existing:
                    # 片方のみのCSVで既存のもう片方を None 上書きしない
                    # merge 更新 (v10.7.4)
                    if amount is not None:
                        existing.fuel_amount_l = amount
                    if cost is not None:
                        existing.fuel_cost_yen = cost
                    existing.fuel_unit_price = (
                        round(existing.fuel_cost_yen / existing.fuel_amount_l)
                        if existing.fuel_cost_yen and existing.fuel_amount_l
                        else None)
                    existing.source = (
                        "csv_import"
                        if existing.fuel_amount_l is not None
                        and existing.fuel_cost_yen is not None
                        else "csv_import_partial")
                    existing.updated_at = datetime.now()
                else:
                    db.add(MonthlyFuelInput(
                        vehicle_code=vc, vehicle_name=vname,
                        year_month=ym_norm,
                        fuel_amount_l=amount, fuel_cost_yen=cost,
                        fuel_unit_price=unit_price,
                        source=src, note=note or None,
                    ))
                monthly_imported += 1
            elif fd:
                # Daily record — daily 側は currently fuel_amount_l NOT NULL の
                # ままなので、ここで amount=None は弾く (CSV import の monthly
                # 経路のみ部分取込を許可)。
                if amount is None:
                    errors.append(f"{i}行目: 日次行は給油量が必須のためスキップ")
                    continue
                fill_dt = parse_flexible_date(fd)
                if fill_dt is None:
                    errors.append(f"{i}行目: 日付「{fd}」を解釈できません")
                    continue
                # 再取込での二重登録を防ぐ (v10.7.4)。日次には upsert キーが
                # 無いため、車両×日付×給油量の一致を重複とみなし、金額のみ
                # 異なる場合は訂正として金額を更新する。
                key = (vc, fill_dt, amount)
                dup = existing_daily.get(key)
                if dup is not None:
                    if cost is not None and dup.fuel_cost_yen != cost:
                        dup.fuel_cost_yen = cost
                        dup.fuel_unit_price = unit_price
                        dup_updated += 1
                    else:
                        skipped_dup += 1
                    continue
                rec = DailyFuelInput(
                    vehicle_code=vc, vehicle_name=vname,
                    fill_date=fill_dt,
                    fuel_amount_l=amount, fuel_cost_yen=cost,
                    fuel_unit_price=unit_price,
                    source=src, note=note or None,
                )
                db.add(rec)
                existing_daily[key] = rec
                daily_imported += 1
            else:
                errors.append(f"{i}行目: 年月・給油日が空欄のためスキップ")
        except Exception as e:
            errors.append(f"{i}行目: {str(e)}")

    db.commit()

    # 取込結果を必ず画面に返す (v10.7.4)。従来は件数・エラーを破棄して
    # 無言でリダイレクトしていたため、失敗に気づけなかった。
    # エラー詳細はURLクエリで運ぶため、1件60字×3件に丸めて長さを抑える。
    import urllib.parse
    fname = file.filename or "CSV"
    msg = (f"{fname}: 月次 {monthly_imported}件 / "
           f"日次 {daily_imported}件 を取り込みました")
    if dup_updated:
        msg += f" / 金額更新 {dup_updated}件"
    if skipped_dup:
        msg += f" / 重複スキップ {skipped_dup}件"
    if errors:
        head = "、".join(
            e if len(e) <= 60 else e[:60] + "…" for e in errors[:3])
        rest = f" ほか{len(errors) - 3}件" if len(errors) > 3 else ""
        msg += f" / エラー {len(errors)}件（{head}{rest}）"
    return RedirectResponse(
        url=f"/fuel?tab=manual&upload_msg={urllib.parse.quote(msg)}",
        status_code=303,
    )


@router.post("/delete/{record_id}")
async def delete_monthly_fuel(record_id: int, db: Session = Depends(get_db)):
    """Delete a monthly fuel record."""
    record = db.query(MonthlyFuelInput).filter(MonthlyFuelInput.id == record_id).first()
    if record:
        db.delete(record)
        db.commit()
    return RedirectResponse(url="/fuel", status_code=303)
