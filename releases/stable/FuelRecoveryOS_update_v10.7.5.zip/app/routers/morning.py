"""朝5分ビュー — 今朝、声をかける人だけを出す画面。

確定設計: docs/dev/改修設計_朝5分ビュー_確定_20260909.md §4

設計原則(§0):
  「まずはこれだけ見てください。深掘りしたければこちらへ」
  機能ではなく表示を絞る。深掘りは自然な導線で、戻る操作を発生させない。

判定は app/services/driver_alerts.py が正本。この画面は集計も判定も持たない。
"""
from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.system import SystemSetting
from app.routers.month_utils import month_context, resolve_base_month
from app.services import driver_alerts, rollup

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# カードに出す指標。視点(現場/経営)で入れ替わるのは指標だけで、
# 対象者と並び順は変わらない(確定設計 §5)。
# アイコンは判定値の正本(driver_alerts.CRITERIA_META)と揃え、設定画面と
# 同じ絵で同じ項目を指すようにする。
_ICON = {m["field"]: m["icon"] for m in driver_alerts.CRITERIA_META}

FIELD_METRICS = [
    {"key": "idle_rate", "label": "アイドリング率", "unit": "%", "field": "idle_rate",
     "icon": _ICON["idle_rate"]},
    {"key": "events_per_100km", "label": "急操作 /100km", "unit": "", "field": "events_per_100km",
     "icon": _ICON["events_per_100km"]},
    {"key": "speed_over_100km", "label": "速度超過 /100km", "unit": "", "field": "speed_over_100km",
     "icon": _ICON["speed_over_100km"]},
    {"key": "labor", "label": "月間拘束", "unit": "h", "field": None,
     "icon": driver_alerts.LABOR_ICON},
]
EXEC_METRICS = [
    {"key": "avg_economy", "label": "経済スコア", "unit": "点", "field": "avg_economy",
     "icon": _ICON["avg_economy"]},
    {"key": "loss_l", "label": "損失", "unit": "L/月", "field": None, "icon": "⛽"},
    {"key": "loss_yen", "label": "損失（円）", "unit": "円/月", "field": None, "icon": "💴"},
    {"key": "idle_excess_h", "label": "アイドリング超過", "unit": "h/月", "field": None,
     "icon": _ICON["idle_rate"]},
]

VIEW_MODES = ("field", "exec")
VIEW_COOKIE = "view_mode"
VIEW_DEFAULT_KEY = "view_mode_default"      # 会社の既定(SystemSetting)

# ホーム(/)にどちらを出すか。既存の dash_tiles と同じ「会社既定 + 個人上書き」の型。
HOME_VIEWS = ("dashboard", "morning")
HOME_COOKIE = "home_view"
HOME_DEFAULT_KEY = "home_view_default"


def _setting(db: Session, key: str) -> str | None:
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    return row.value if row and row.value else None


def resolve_view_mode(cookie_val, company_default: str | None = None) -> str:
    """個人の上書き(cookie) → 会社の既定 → 現場視点。"""
    if cookie_val in VIEW_MODES:
        return cookie_val
    if company_default in VIEW_MODES:
        return company_default
    return "field"


def resolve_home_view(cookie_val, company_default: str | None = None) -> str:
    """ホーム(/)に出す画面。個人の上書き → 会社の既定 → ダッシュボード。

    認証が無いため cookie＝ブラウザ単位。同じPCを共有する場合は分離されない
    (既存のタイル編集・基軸月と同じ制約。顧客へ明示する)。
    """
    if cookie_val in HOME_VIEWS:
        return cookie_val
    if company_default in HOME_VIEWS:
        return company_default
    return "dashboard"




def _metric_rows(row, mode: str) -> list[dict]:
    """カードに並べる指標行。判定に該当した項目には色を付ける。"""
    stats = row["stats"]
    hit_level = {h["field"]: h["level"] for h in row["hits"]}
    out = []
    for m in (EXEC_METRICS if mode == "exec" else FIELD_METRICS):
        if m["key"] == "labor":
            labor = row.get("labor")
            value = labor["total_h"] if labor else None
            field = driver_alerts.LABOR_FIELD
        elif m["field"]:
            value = stats.get(m["field"])
            field = m["field"]
        else:
            value = stats.get(m["key"])
            field = None
        out.append({
            "icon": m["icon"], "label": m["label"], "unit": m["unit"], "value": value,
            "level": hit_level.get(field),
        })
    return out


def _attach_economics(db: Session, base, office: str, rows: list[dict]) -> None:
    """乗務員別の損失(L/円)・アイドリング超過を stats に足す。

    rollup.loss_breakdown() / aggregate_by_driver() の既存集計をそのまま使うため、
    ダッシュボードの損失回収ファネルと数字が一致する(rollup.py の総額不変制約)。
    乗務員別の実燃費(km/L)は給油が車両単位のため出せない(確定設計 §5.1)。
    """
    from app.routers.settings_router import get_fuel_price

    trips = rollup.month_trips(db, base, None if office in ("all", "ALL", "") else office)
    by_driver: dict[str, list] = {}
    for t in trips:
        if t.driver_code:
            by_driver.setdefault(t.driver_code, []).append(t)
    agg = rollup.aggregate_by_driver(trips)
    price = get_fuel_price(db, base.strftime("%Y-%m"))

    for r in rows:
        ts = by_driver.get(r["code"], [])
        st = r["stats"]
        if not ts:
            st["loss_l"] = st["loss_yen"] = st["idle_excess_h"] = None
            continue
        loss_l = rollup.loss_total_l(rollup.loss_breakdown(ts))
        a = agg.get(r["code"]) or {}
        st["loss_l"] = round(loss_l, 1)
        st["loss_yen"] = int(round(loss_l * price))
        st["idle_excess_h"] = round(
            ((a.get("idle_excess_sec") or 0) + (a.get("wait_sec") or 0)) / 3600, 1)


@router.get("/morning")
async def morning(request: Request, office: str = "all", view: str = "",
                  db: Session = Depends(get_db)):
    base = resolve_base_month(db, request.cookies.get("base_month"))
    ym = base.strftime("%Y-%m")
    # ?view= はその表示だけの一時指定(リンクで共有できる)。既定は cookie → 会社既定。
    mode = resolve_view_mode(view or request.cookies.get(VIEW_COOKIE),
                             _setting(db, VIEW_DEFAULT_KEY))

    result = driver_alerts.build_alert_list(db, ym, office)
    warn_limit = driver_alerts.get_warn_limit(db)
    foresight = driver_alerts.build_foresight(db, ym, result)

    _attach_economics(db, base, office, result["alerts"] + result["warns"])

    def card(row):
        return {
            **row,
            "metrics": _metric_rows(row, mode),
            "hit_count": len(row["hits"]),
        }

    alerts = [card(r) for r in result["alerts"]]          # 赤は絞らず全員
    warns_all = [card(r) for r in result["warns"]]
    warns = warns_all[:warn_limit]
    warns_more = warns_all[warn_limit:]                   # その場で開く分

    return templates.TemplateResponse("morning.html", {
        "request": request,
        "current_page": "morning",
        "alerts": alerts,
        "warns": warns,
        "warns_more": warns_more,
        "warn_limit": warn_limit,
        "foresight": foresight,
        "home_view": resolve_home_view(request.cookies.get(HOME_COOKIE),
                                       _setting(db, HOME_DEFAULT_KEY)),
        "ok_count": result["ok_count"],
        "total": result["total"],
        "view_mode": mode,
        "offices": rollup.list_offices(db),
        "selected_office": office,
        **month_context(db, request.cookies.get("base_month")),
    })
