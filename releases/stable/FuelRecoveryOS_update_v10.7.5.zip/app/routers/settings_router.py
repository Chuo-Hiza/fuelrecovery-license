"""Settings router — 指導書自動判別条件などシステム設定管理。"""
from datetime import datetime

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db
from app.models.master import Vehicle
from app.models.system import SystemSetting
from app.routers import exception_zones, morning, speed_sheet
from app.services import driver_alerts
from app.services.labor_check import LABOR_LIMIT_META, get_labor_limits

DEFAULT_BASELINE_EFFICIENCY = 5.0  # km/L — 車両別基準燃費の未設定時デフォルト

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# 判別条件の定義は app/services/driver_alerts.py が正本(確定設計 D-2 統合範囲②)。
# 判定値をここに二重に持たない。
CRITERIA_META = driver_alerts.CRITERIA_META
SETTING_KEY = driver_alerts.SETTING_KEY

FUEL_PRICE_KEY = "fuel_price"
FUEL_PRICE_DEFAULT = 162  # yen/L


def get_fuel_price(db: Session, month: str | None = None) -> float:
    """軽油単価を取得(月別対応・2026-07-24 顧客FB①)。

    参照ルール: 対象月の月別単価 → それ以前で最新の月別単価 → 既定値(従来キー)
    → デフォルト。過去月は当時の単価が保持され、以後の月は最新設定が効く。
    """
    if month:
        rows = (db.query(SystemSetting)
                .filter(SystemSetting.key.like(f"{FUEL_PRICE_KEY}_____-__"))
                .all())
        candidates = []
        for r in rows:
            m = r.key[len(FUEL_PRICE_KEY) + 1:]
            if m <= month:
                try:
                    candidates.append((m, float(r.value)))
                except (ValueError, TypeError):
                    pass
        if candidates:
            return max(candidates)[1]   # 対象月以前で最新の月
    row = db.query(SystemSetting).filter(SystemSetting.key == FUEL_PRICE_KEY).first()
    if row:
        try:
            return float(row.value)
        except (ValueError, TypeError):
            pass
    return float(FUEL_PRICE_DEFAULT)


def list_monthly_fuel_prices(db: Session) -> list[dict]:
    """月別単価の履歴(新しい月順)。設定画面の一覧表示用。"""
    rows = (db.query(SystemSetting)
            .filter(SystemSetting.key.like(f"{FUEL_PRICE_KEY}_____-__"))
            .all())
    out = []
    for r in rows:
        try:
            out.append({"month": r.key[len(FUEL_PRICE_KEY) + 1:],
                        "price": float(r.value)})
        except (ValueError, TypeError):
            continue
    out.sort(key=lambda x: x["month"], reverse=True)
    return out


def get_criteria(db: Session) -> list:
    """DBから判別条件を取得。判定は driver_alerts が正本。

    threshold は「黄(warn)」の別名として残してある。従来 1段階を前提にしていた
    呼び出し側(coaching_list の自動判別 JS)を壊さないための後方互換で、
    サーバ判定へ寄せ切った段階で外す。
    """
    return [dict(c, threshold=c["warn"], is_default=driver_alerts.is_default(c))
            for c in driver_alerts.load_criteria(db)]


def get_vehicle_baseline(db: Session, vehicle_code: str) -> float:
    """車両の基準燃費を取得。未設定時はデフォルト値を返す。"""
    v = db.query(Vehicle).filter(Vehicle.code == vehicle_code).first()
    if v and v.baseline_efficiency_kml is not None:
        return v.baseline_efficiency_kml
    return DEFAULT_BASELINE_EFFICIENCY


@router.get("/settings")
async def settings_page(request: Request, db: Session = Depends(get_db)):
    criteria = get_criteria(db)
    saved = db.query(SystemSetting).filter(SystemSetting.key == SETTING_KEY).first()
    updated_at = saved.updated_at.strftime("%Y/%m/%d %H:%M") if saved and saved.updated_at else None
    fuel_price = get_fuel_price(db)

    # 車両プロファイル
    vehicles = db.query(Vehicle).filter(Vehicle.is_active == 1).order_by(Vehicle.code).all()

    return templates.TemplateResponse("settings.html", {
        "request": request,
        "current_page": "settings",
        "criteria": criteria,
        "criteria_meta": {m["field"]: m for m in CRITERIA_META},
        "warn_limit": driver_alerts.get_warn_limit(db),
        # 画面の既定(会社単位)。個人はブラウザ側で上書きできる(確定設計 D-5)
        "home_view_default": morning.resolve_home_view(None, _get(db, morning.HOME_DEFAULT_KEY)),
        "view_mode_default": morning.resolve_view_mode(None, _get(db, morning.VIEW_DEFAULT_KEY)),
        # 速度超過まわりの設定値を1画面に集約(確定設計 D-2 統合範囲②)
        "speed_limit_kmh": exception_zones.get_speed_limit(db),
        "speed_sheet_red": dict(zip(("count", "sec"), speed_sheet._thresholds(db))),
        "updated_at": updated_at,
        "fuel_price": fuel_price,
        "fuel_price_default": FUEL_PRICE_DEFAULT,
        "monthly_fuel_prices": list_monthly_fuel_prices(db),
        "current_month": datetime.now().strftime("%Y-%m"),
        "labor_limit_meta": LABOR_LIMIT_META,
        "labor_limits": get_labor_limits(db),
        "vehicles": vehicles,
        "default_efficiency": DEFAULT_BASELINE_EFFICIENCY,
        "profile_saved": request.query_params.get("profile_saved"),
    })


@router.get("/settings/criteria/preview")
async def criteria_preview(request: Request, db: Session = Depends(get_db)):
    """「この設定だと現在 赤N名 / 黄M名」。保存前の値でも数えられる。

    クエリで warn_x / alert_x / enabled_x を渡すとその条件で数える。
    渡さなければ保存済みの条件で数える。
    """
    from app.routers.month_utils import resolve_base_month
    base = resolve_base_month(db, request.cookies.get("base_month"))
    ym = base.strftime("%Y-%m")
    q = request.query_params
    criteria = _criteria_from(q) if any(k.startswith("warn_") for k in q) else None
    try:
        counts = driver_alerts.preview_counts(db, ym, criteria=criteria)
    except Exception:                       # データ未取込などで数えられない場合
        return JSONResponse({"month": ym, "available": False})
    return JSONResponse({"month": ym, "available": True, **counts})


def _criteria_from(form) -> list:
    """フォーム/クエリ値 → 判定条件。不正値は既定値へ落とす。"""
    out = []
    for m in CRITERIA_META:
        f = m["field"]
        out.append({
            "field": f, "label": m["label"], "op": m["op"], "unit": m["unit"],
            "warn": _f(form.get(f"warn_{f}"), m["default_warn"]),
            "alert": _f(form.get(f"alert_{f}"), m["default_alert"], allow_blank=True),
            "enabled": form.get(f"enabled_{f}") == "on",
        })
    return out


def _get(db: Session, key: str):
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    return row.value if row and row.value else None


def _put(db: Session, key: str, value: str, description: str) -> None:
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    if row:
        row.value = value
        row.updated_at = datetime.now()
    else:
        db.add(SystemSetting(key=key, value=value, description=description,
                             updated_at=datetime.now()))


def _f(raw, fallback, allow_blank: bool = False):
    if raw is None or (allow_blank and str(raw).strip() == ""):
        return None if allow_blank and raw is not None else fallback
    try:
        v = float(raw)
    except (TypeError, ValueError):
        return fallback
    return int(v) if v == int(v) else v


@router.post("/settings/criteria/reset")
async def reset_criteria(db: Session = Depends(get_db)):
    """判定条件をすべて初期値に戻す(確定設計 §3.5 の歯止め)。"""
    driver_alerts.save_criteria(db, driver_alerts.default_criteria())
    driver_alerts.set_warn_limit(db, driver_alerts.DEFAULT_WARN_LIMIT)
    db.commit()
    return RedirectResponse(url="/settings?reset=1", status_code=303)


@router.post("/settings")
async def save_settings(request: Request, db: Session = Depends(get_db)):
    form = await request.form()

    # 判別条件はフォームに欄がある場合のみ更新する。
    # 欄の無いフォームから POST されると全条件が無効化されて保存され、判定が
    # 黙って止まる(実データで発生済み: 2026-05-10 に6条件すべて enabled=false
    # で保存されていた。確定設計 §2 発見3)。軽油単価と同じ後方互換ガード。
    if "criteria_form" in form:
        driver_alerts.save_criteria(db, _criteria_from(form))
    if "warn_limit" in form:
        driver_alerts.set_warn_limit(db, form.get("warn_limit"))

    # 画面の既定(会社単位)。個人の上書き(cookie)より弱い(確定設計 D-5)
    if "home_view_default" in form:
        v = form.get("home_view_default")
        _put(db, morning.HOME_DEFAULT_KEY,
             v if v in morning.HOME_VIEWS else "dashboard", "ホームに出す画面(会社の既定)")
    if "view_mode_default" in form:
        v = form.get("view_mode_default")
        _put(db, morning.VIEW_DEFAULT_KEY,
             v if v in morning.VIEW_MODES else "field", "朝5分ビューの視点(会社の既定)")

    # 速度超過まわり(統合範囲②)。同じ画面から設定できるようにする。
    if "speed_limit_kmh" in form:
        exception_zones.set_speed_limit(db, form.get("speed_limit_kmh"))
    if "speed_sheet_red_count" in form:
        speed_sheet.set_thresholds(db, form.get("speed_sheet_red_count"),
                                   form.get("speed_sheet_red_sec"))

    # 軽油単価の保存(v10.7.2で専用カードへ移設。フォームに欄がある場合のみ更新
    # — 欄なしで既定値がリセットされる事故を防ぐ後方互換ガード)
    if "fuel_price" in form:
        raw_price = form.get("fuel_price", "")
        try:
            fuel_price_val = round(float(raw_price), 1)
            if fuel_price_val <= 0:
                raise ValueError
        except (ValueError, TypeError):
            fuel_price_val = float(FUEL_PRICE_DEFAULT)
        fp_row = db.query(SystemSetting).filter(SystemSetting.key == FUEL_PRICE_KEY).first()
        if fp_row:
            fp_row.value = str(fuel_price_val)
            fp_row.updated_at = datetime.now()
        else:
            db.add(SystemSetting(
                key=FUEL_PRICE_KEY,
                value=str(fuel_price_val),
                description="軽油単価（円/L）",
                updated_at=datetime.now(),
            ))

    # 労務上限設定値の保存(N2)。Free Nippo 側と同一値を運用ルールで共有(D-3)
    for m in LABOR_LIMIT_META:
        raw = form.get(m["key"], "")
        try:
            val = int(float(raw))
            if val <= 0:
                raise ValueError
        except (ValueError, TypeError):
            val = m["default"]
        lrow = db.query(SystemSetting).filter(SystemSetting.key == m["key"]).first()
        if lrow:
            lrow.value = str(val)
            lrow.updated_at = datetime.now()
        else:
            db.add(SystemSetting(
                key=m["key"],
                value=str(val),
                description=f"労務: {m['label']}",
                updated_at=datetime.now(),
            ))

    db.commit()
    return RedirectResponse(url="/settings?saved=1", status_code=303)


@router.post("/settings/fuel-price-default")
async def save_default_fuel_price(request: Request, db: Session = Depends(get_db)):
    """既定の軽油単価の保存(専用カードから。v10.7.2 UI整頓)。"""
    form = await request.form()
    try:
        price = round(float(form.get("fuel_price", "")), 1)
        if not (1 <= price <= 9999):
            raise ValueError
    except (ValueError, TypeError):
        return RedirectResponse(url="/settings?fuel_month_error=1", status_code=303)
    row = db.query(SystemSetting).filter(SystemSetting.key == FUEL_PRICE_KEY).first()
    if row:
        row.value = str(price)
        row.updated_at = datetime.now()
    else:
        db.add(SystemSetting(key=FUEL_PRICE_KEY, value=str(price),
                             description="軽油単価（円/L）",
                             updated_at=datetime.now()))
    db.commit()
    return RedirectResponse(url="/settings?fuel_month_saved=1", status_code=303)


@router.post("/settings/fuel-price-month")
async def save_monthly_fuel_price(request: Request, db: Session = Depends(get_db)):
    """月別軽油単価の追加/更新(顧客FB① 2026-07-24)。0.1円刻み。"""
    import re
    form = await request.form()
    month = str(form.get("month", "")).strip()
    if not re.fullmatch(r"\d{4}-\d{2}", month):
        return RedirectResponse(url="/settings?fuel_month_error=1", status_code=303)
    try:
        price = round(float(form.get("price", "")), 1)
        if not (1 <= price <= 9999):
            raise ValueError
    except (ValueError, TypeError):
        return RedirectResponse(url="/settings?fuel_month_error=1", status_code=303)

    key = f"{FUEL_PRICE_KEY}_{month}"
    row = db.query(SystemSetting).filter(SystemSetting.key == key).first()
    if row:
        row.value = str(price)
        row.updated_at = datetime.now()
    else:
        db.add(SystemSetting(key=key, value=str(price),
                             description=f"軽油単価 {month}(円/L)",
                             updated_at=datetime.now()))
    db.commit()
    return RedirectResponse(url="/settings?fuel_month_saved=1", status_code=303)


@router.post("/settings/fuel-price-month/delete")
async def delete_monthly_fuel_price(request: Request, db: Session = Depends(get_db)):
    form = await request.form()
    month = str(form.get("month", "")).strip()
    (db.query(SystemSetting)
     .filter(SystemSetting.key == f"{FUEL_PRICE_KEY}_{month}")
     .delete(synchronize_session=False))
    db.commit()
    return RedirectResponse(url="/settings?fuel_month_saved=1", status_code=303)


@router.post("/settings/vehicle-profile")
async def save_vehicle_profile(request: Request, db: Session = Depends(get_db)):
    """車両別基準燃費を一括保存。"""
    form = await request.form()
    vehicles = db.query(Vehicle).filter(Vehicle.is_active == 1).all()
    updated = 0
    for v in vehicles:
        raw = form.get(f"eff_{v.code}", "")
        if raw.strip():
            try:
                val = float(raw)
                if 0 < val < 100:
                    v.baseline_efficiency_kml = val
                    updated += 1
            except (ValueError, TypeError):
                pass
        else:
            # 空欄 → Noneに戻す（デフォルト値を使用）
            v.baseline_efficiency_kml = None
    db.commit()
    return RedirectResponse(url=f"/settings?profile_saved={updated}", status_code=303)
