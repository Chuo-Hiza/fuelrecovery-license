"""Fuel Recovery OS — FastAPI application."""
import logging
import os
import sys
import threading
from contextlib import asynccontextmanager

# Configure root logger so watcher thread output is visible
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr,
)

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database import Base, engine
from app.importers.watcher import run_watcher
from app.license_checker import run_license_checker
from app.middleware.license_guard import LicenseGuardMiddleware
from app.models import *  # noqa: F401,F403 — ensure all models are loaded
from app.routers import dashboard, cases, shipper, coaching, help, fuel, analysis, settings_router
from app.routers import ranking, loss_breakdown, speed_sheet, overrides, trip_detail, search
from app.routers import exception_zones
from app.routers import import_status, mode_review, loading_time, work_time, compliance
from app.routers import labor
from app.routers import aggregate
from app.routers import morning
from app.routers import license_router, update_router
from app.update_checker import run_update_checker

logger = logging.getLogger(__name__)

_watcher_stop = threading.Event()
_license_stop = threading.Event()
_update_stop = threading.Event()


def _migrate_db():
    """Add missing columns to existing tables (lightweight migration)."""
    from sqlalchemy import text, inspect
    with engine.connect() as conn:
        inspector = inspect(engine)
        # vehicles.baseline_efficiency_kml
        if "vehicles" in inspector.get_table_names():
            cols = [c["name"] for c in inspector.get_columns("vehicles")]
            if "baseline_efficiency_kml" not in cols:
                conn.execute(text("ALTER TABLE vehicles ADD COLUMN baseline_efficiency_kml FLOAT"))
                conn.commit()
                logger.info("Migrated: added vehicles.baseline_efficiency_kml")
        # toll_records.used_at (v10.7.2: ETC明細の日次閲覧=顧客FB②)
        if "toll_records" in inspector.get_table_names():
            cols = [c["name"] for c in inspector.get_columns("toll_records")]
            if "used_at" not in cols:
                conn.execute(text("ALTER TABLE toll_records ADD COLUMN used_at DATETIME"))
                conn.commit()
                logger.info("Migrated: added toll_records.used_at")
    _migrate_monthly_fuel_amount_nullable()


def _migrate_monthly_fuel_amount_nullable() -> None:
    """v10.6.13: monthly_fuel_inputs.fuel_amount_l の NOT NULL を外す。

    金額だけ先に入れて後から給油量を補完したいケース (請求ベース入力) に
    対応するため。SQLite は ALTER COLUMN を持たないので、新テーブル作成 →
    データコピー → 旧テーブル削除 → リネーム → インデックス再作成という
    旧来パターンで行う。is-nullable をイントロスペクトして、既に nullable
    なら何もしない (冪等)。
    """
    from sqlalchemy import inspect, text
    insp = inspect(engine)
    if "monthly_fuel_inputs" not in insp.get_table_names():
        return  # 初回起動 (create_all 待ち)
    for col in insp.get_columns("monthly_fuel_inputs"):
        if col["name"] == "fuel_amount_l":
            if col.get("nullable", True):
                return  # 既に nullable
            break
    else:
        return  # カラムが見つからない (想定外)
    logger.info("Migrating monthly_fuel_inputs.fuel_amount_l to NULL-able...")
    with engine.begin() as conn:
        conn.execute(text("ALTER TABLE monthly_fuel_inputs RENAME TO _mfi_old_v1063"))
        conn.execute(text(
            """
            CREATE TABLE monthly_fuel_inputs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vehicle_code VARCHAR(8) NOT NULL,
                vehicle_name VARCHAR(50),
                year_month VARCHAR(7) NOT NULL,
                fuel_amount_l FLOAT,
                fuel_cost_yen INTEGER,
                fuel_unit_price FLOAT,
                source VARCHAR(20),
                note TEXT,
                created_at DATETIME,
                updated_at DATETIME
            )
            """
        ))
        conn.execute(text(
            """
            INSERT INTO monthly_fuel_inputs
                (id, vehicle_code, vehicle_name, year_month, fuel_amount_l,
                 fuel_cost_yen, fuel_unit_price, source, note,
                 created_at, updated_at)
            SELECT id, vehicle_code, vehicle_name, year_month, fuel_amount_l,
                   fuel_cost_yen, fuel_unit_price, source, note,
                   created_at, updated_at
            FROM _mfi_old_v1063
            """
        ))
        conn.execute(text("DROP TABLE _mfi_old_v1063"))
        conn.execute(text(
            "CREATE INDEX ix_monthly_fuel_inputs_vehicle_code "
            "ON monthly_fuel_inputs (vehicle_code)"
        ))
        conn.execute(text(
            "CREATE INDEX ix_monthly_fuel_inputs_year_month "
            "ON monthly_fuel_inputs (year_month)"
        ))
    logger.info("Migration complete: fuel_amount_l is now nullable")


def _resume_update_after_restart():
    """apply_update.bat / rollback.bat 経由で起動された場合の後処理。

    apply_update.bat は /health 疎通で成否を判定するため、Python 側では
    成功時のクリーンアップとロールバック時のモード変更だけを行う。

    - `update_staging/rollback_force_notify` がある → 直前にロールバックされた
      → 適用モードを notify に強制し、再発防止
    - `update_staging/applied/applied_version` がある & 内容が現在の app_version
      と一致 → 直前 apply の成功 → DB に記録し ready/ を history/ に退避
    """
    from pathlib import Path
    import shutil

    staging = Path("update_staging")
    if not staging.exists():
        return

    # rollback 後のフラグ
    notify_marker = staging / "rollback_force_notify"
    if notify_marker.exists():
        try:
            from app.database import SessionLocal
            from app.update import set_mode, UpdateMode
            db = SessionLocal()
            try:
                set_mode(db, UpdateMode.NOTIFY.value)
            finally:
                db.close()
            logger.warning(
                "Previous update failed and was rolled back. "
                "Update mode forced to 'notify'. Manual intervention required."
            )
            notify_marker.unlink(missing_ok=True)
        except Exception as e:
            logger.warning(f"Could not apply post-rollback notify mode: {e}")

    # apply 成功後の DB 反映
    applied = staging / "applied"
    ver_file = applied / "applied_version"
    if not ver_file.exists():
        return
    try:
        applied_ver = ver_file.read_text(encoding="utf-8").strip()
    except Exception:
        return
    if applied_ver != settings.app_version:
        # 不一致 = apply バッチが書いた後 Python 側で別経路で何かが起こった
        # 安全側に倒し、何もせずに残す
        logger.warning(
            "applied_version (%s) does not match current app_version (%s); "
            "leaving artifacts in place.",
            applied_ver, settings.app_version,
        )
        return
    try:
        from app.database import SessionLocal
        from app.update import (
            _set_setting, clear_manifest_summary, set_stage, UpdateStage,
        )
        db = SessionLocal()
        try:
            _set_setting(db, "update_current_version", applied_ver)
            set_stage(db, UpdateStage.IDLE.value)
            clear_manifest_summary(db)
        finally:
            db.close()
        # ready/ を history/{version}/ に退避し、最新3世代まで保持
        ready = staging / "ready"
        if ready.exists():
            history = staging / "history"
            history.mkdir(exist_ok=True)
            hist_dir = history / applied_ver
            if hist_dir.exists():
                shutil.rmtree(hist_dir, ignore_errors=True)
            ready.rename(hist_dir)
            versions = sorted(
                [p for p in history.iterdir() if p.is_dir()],
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            for old in versions[3:]:
                shutil.rmtree(old, ignore_errors=True)
        # applied/ も history 側に移してクリーン化
        if applied.exists():
            shutil.rmtree(applied, ignore_errors=True)
        logger.info(f"Update applied successfully: now running v{applied_ver}")
    except Exception as e:
        logger.warning(f"Could not finalize update success state: {e}")


def _backfill_vehicles_from_trips():
    """日報CSV取込済みだが車両マスタが未登録の車両を一括登録。

    v10.5.4 以前は日報インポーターが車両マスタへ自動登録していなかったため、
    既に取込済みの環境では給油画面の車両ドロップダウンが空になる。
    起動時に trip_reports から不足分のみ補う。
    """
    from app.database import SessionLocal
    from app.models.csv_import import TripReport
    from app.models.master import Vehicle

    db = SessionLocal()
    try:
        existing = {c for (c,) in db.query(Vehicle.code).all()}
        rows = (
            db.query(
                TripReport.vehicle_code,
                TripReport.vehicle_name,
                TripReport.vehicle_office_code,
            )
            .filter(TripReport.vehicle_code.isnot(None))
            .distinct()
            .all()
        )
        added = 0
        for code, name, office in rows:
            if not code or code in existing:
                continue
            db.add(Vehicle(
                code=code,
                name=name or code,
                office_code=office,
                is_active=True,
            ))
            existing.add(code)
            added += 1
        if added:
            db.commit()
            logger.info(f"Backfilled {added} vehicles from existing trip reports")
    except Exception as e:
        db.rollback()
        logger.warning(f"Vehicle backfill skipped: {e}")
    finally:
        db.close()


def _migrate_update_mode_default_v1064() -> None:
    """v10.6.4 既定変更 migration: 既存 update_mode を 'auto' へ一回限り reset。

    既定値を notify → auto に変更した(commit 0fddb8c)が、既に DB に旧既定値
    が明示保存されている install では「ユーザー設定」と区別できないため、
    1 回だけ全て auto に上書きする。実行済みフラグで二度走らない。
    """
    from app.database import SessionLocal
    from app.update import _get_setting, _set_setting, UpdateMode
    MARKER = "migration_v1064_update_mode_reset"
    db = SessionLocal()
    try:
        if _get_setting(db, MARKER):
            return
        old = _get_setting(db, "update_mode")
        _set_setting(db, "update_mode", UpdateMode.AUTO.value)
        _set_setting(db, MARKER, "done")
        if old and old != UpdateMode.AUTO.value:
            logger.info(
                "Migrated update_mode %r -> 'auto' (v10.6.4 default change)",
                old,
            )
    except Exception as e:
        logger.warning(f"update_mode migration skipped: {e}")
    finally:
        db.close()


def _migrate_criteria_two_stage_v1075() -> None:
    """v10.7.5: 判定基準を2段階(注意=黄 / 要注意=赤)へ移行し、既定を有効にする。

    - 旧形式(閾値1段階)の保存値を warn/alert 形式へ書き換える
    - 旧既定値のままの条件は、実データで較正した新しい既定値へ載せ替える
      (顧客が実際に変えた値は尊重して黄に残す)
    - enabled を既定(全条件ON)へ揃える。従来は判別条件がすべて無効のまま
      保存されている install があり、判定が何も働いていなかった
    挙動変更にあたるため、リリースノートと操作ガイドに明記すること。
    """
    from app.database import SessionLocal
    from app.services import driver_alerts
    db = SessionLocal()
    try:
        if driver_alerts.migrate_criteria(db):
            logger.info("Migrated coaching criteria to two-stage defaults (v10.7.5)")
    except Exception as e:
        logger.warning(f"criteria migration skipped: {e}")
    finally:
        db.close()


def _reimport_etc_zero_yen_v1073() -> None:
    """v10.7.3: ETC取込の0円行対応に伴う、done/アーカイブからの自動再取込(1回のみ)。

    旧取込条件では金額0円/空欄の利用行(首都高 連結車両特例など)が捨てられていた。
    アーカイブ(保持7日)に残る *_etc.csv を洗い替えで取り直し、直近分を顧客操作なし
    で復元する。それ以前の分は「CSVを取込フォルダに入れ直す」で随時復元可能。
    """
    from app.database import SessionLocal
    from app.models.system import SystemSetting

    FLAG = "etc_zero_reimport_v1073"
    db = SessionLocal()
    try:
        if db.query(SystemSetting).filter_by(key=FLAG).first():
            return
        from pathlib import Path
        from app.importers.toll_record import import_toll_record

        done_dir = Path(settings.csv_done_dir)
        n = 0
        if done_dir.exists():
            for f in sorted(done_dir.glob("*/*_etc.csv")):
                try:
                    import_toll_record(f, db)
                    n += 1
                except Exception as e:
                    logger.warning(f"etc re-import skipped for {f.name}: {e}")
                    db.rollback()
        db.add(SystemSetting(key=FLAG, value=f"done:{n}",
                             description="v10.7.3 ETC 0円行対応の自動再取込済みマーク"))
        db.commit()
        logger.info(f"etc zero-yen re-import done: {n} files")
    except Exception as e:
        logger.warning(f"etc zero-yen re-import failed: {e}")
        db.rollback()
    finally:
        db.close()


def _auto_apply_check_at_startup() -> None:
    """update_mode=auto (もしくは mandatory_after 越え) かつ ready/ にステージング
    済みなら、uvicorn が serve する前に apply_update.bat を spawn して os._exit(0)。

    顧客 PC 起動時の流れ:
      [今回起動] start.bat → uvicorn 起動準備 → lifespan で本関数 →
                  staged かつ (auto or mandatory_after 越え) → bat spawn →
                  os._exit → bat が新 start.bat 起動
      [次回起動] 新 uvicorn が serve

    作業中の自動 apply は user の作業を中断するので NG。「起動時のみ」が安全。
    """
    from datetime import date
    from pathlib import Path
    ready_manifest = Path("update_staging/ready/MANIFEST.toml")
    if not ready_manifest.exists():
        return

    from app.database import SessionLocal
    from app.update import (
        UpdateMode, UpdateStage, _get_setting, get_mode, get_stage, set_stage,
    )
    db = SessionLocal()
    try:
        if get_stage(db) != UpdateStage.STAGED.value:
            return  # ready/ あるが DB は別状態 — 念のため skip
        mode = get_mode(db)
        # mandatory_after 越え判定 — 過ぎていれば mode に関わらず強制 apply
        is_mandatory = False
        ma = _get_setting(db, "update_mandatory_after")
        if ma:
            try:
                if date.fromisoformat(ma) <= date.today():
                    is_mandatory = True
            except ValueError:
                pass
        if mode != UpdateMode.AUTO.value and not is_mandatory:
            return  # notify / manual かつ強制でもない → customer 操作待ち
        if is_mandatory and mode != UpdateMode.AUTO.value:
            logger.info(
                "auto-apply: mandatory_after passed; overriding mode=%s", mode,
            )
        # apply 確定 → DB を APPLYING に
        set_stage(db, UpdateStage.APPLYING.value)
    finally:
        db.close()

    bat = Path("apply_update.bat").resolve()
    if not bat.exists():
        logger.error("auto-apply: apply_update.bat not found at %s", bat)
        return

    import subprocess
    import time
    logger.info("auto-apply: spawning apply_update.bat before serving")
    if sys.platform == "win32":
        CREATE_NEW_CONSOLE = 0x00000010
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        CREATE_BREAKAWAY_FROM_JOB = 0x01000000
        flags = (
            CREATE_NEW_CONSOLE | CREATE_NEW_PROCESS_GROUP | CREATE_BREAKAWAY_FROM_JOB
        )
        subprocess.Popen(
            ["cmd.exe", "/c", str(bat)],
            creationflags=flags, close_fds=True, cwd=str(bat.parent),
        )
    else:
        subprocess.Popen([str(bat)], cwd=str(bat.parent), close_fds=True)
    # bat が起動するのを少し待ってから自分は退場
    time.sleep(2)
    logger.info("auto-apply: exiting; apply_update.bat takes over")
    os._exit(0)


@asynccontextmanager
async def lifespan(app: FastAPI):
    _resume_update_after_restart()
    Base.metadata.create_all(bind=engine)
    _migrate_db()
    _migrate_update_mode_default_v1064()
    _migrate_criteria_two_stage_v1075()
    _backfill_vehicles_from_trips()
    _reimport_etc_zero_yen_v1073()
    # auto-apply: staged かつ (mode=auto or mandatory_after 越え) なら、
    # ここで apply_update.bat にバトンタッチして os._exit。
    # 本関数が return しないこともある。
    # (検証環境では UPDATE_CHECKER_ENABLED=0 で無効化 — fros_test.bat が設定)
    if settings.update_checker_enabled:
        _auto_apply_check_at_startup()
    else:
        logger.info("update checker disabled (UPDATE_CHECKER_ENABLED=0) — skip auto-apply")
    # 起動時にインストール日を記録 (なければ今日)
    from app.database import SessionLocal
    from app.license import get_install_date
    _db = SessionLocal()
    try:
        get_install_date(_db)
    finally:
        _db.close()
    # Start CSV watcher in background thread
    watcher_thread = threading.Thread(
        target=run_watcher,
        args=(_watcher_stop,),
        daemon=True,
        name="csv-watcher",
    )
    watcher_thread.start()
    logger.info("CSV watcher thread started")
    # Start license checker in background thread
    license_thread = threading.Thread(
        target=run_license_checker,
        args=(_license_stop,),
        daemon=True,
        name="license-checker",
    )
    license_thread.start()
    logger.info("License checker thread started")
    # Start update checker in background thread
    if settings.update_checker_enabled:
        update_thread = threading.Thread(
            target=run_update_checker,
            args=(_update_stop,),
            daemon=True,
            name="update-checker",
        )
        update_thread.start()
        logger.info("Update checker thread started")
    else:
        logger.info("Update checker thread NOT started (disabled by env)")
    yield
    _watcher_stop.set()
    _license_stop.set()
    _update_stop.set()
    logger.info("Background threads stopping")


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    lifespan=lifespan,
)

# ライセンス期限ミドルウェア (Locked期リダイレクト + Grace期書込ブロック)
app.add_middleware(LicenseGuardMiddleware)

from pathlib import Path as _Path
_static_dir = _Path("static")
if not _static_dir.exists():
    _static_dir.mkdir(parents=True)
app.mount("/static", StaticFiles(directory="static"), name="static")

# ブランディング(ロゴ・スプラッシュ)表示フラグ。
# config/.branding_on の存在で判定。インストーラの「ロゴ・スプラッシュを表示しますか?」で切替。
app.state.branding_enabled = _Path("config/.branding_on").exists()

app.include_router(dashboard.router)
app.include_router(morning.router)
app.include_router(cases.router)
app.include_router(shipper.router)
app.include_router(coaching.router)
app.include_router(help.router)
app.include_router(fuel.router)
app.include_router(analysis.router)
app.include_router(ranking.router)
app.include_router(loss_breakdown.router)
app.include_router(speed_sheet.router)
app.include_router(overrides.router)
app.include_router(trip_detail.router)
app.include_router(search.router)
app.include_router(exception_zones.router)
app.include_router(settings_router.router)
app.include_router(import_status.router)
app.include_router(mode_review.router)
app.include_router(loading_time.router)
app.include_router(work_time.router)
app.include_router(compliance.router)
app.include_router(labor.router)
app.include_router(aggregate.router)
app.include_router(license_router.router)
app.include_router(update_router.router)


@app.get("/health")
async def health():
    """軽量 health check: プロセス生存 + DB 接続 + 主要テーブル参照可。

    apply_update.bat はこのエンドポイントの 200 で「適用成功」と判定するため、
    プロセスは立ち上がっているが DB アクセスが破綻している状態を弾ける
    ようにする。
    """
    from fastapi.responses import JSONResponse
    from sqlalchemy import text
    from app.database import SessionLocal
    db = SessionLocal()
    try:
        # 軽量 SELECT — schema が壊れていれば例外
        db.execute(text("SELECT 1"))
        db.execute(text("SELECT 1 FROM system_settings LIMIT 1"))
        return {"status": "ok"}
    except Exception as e:
        logger.warning("health check failed: %s", e)
        return JSONResponse(
            {"status": "db_error", "detail": str(e)[:200]},
            status_code=503,
        )
    finally:
        db.close()


@app.get("/changelog")
async def changelog(request: Request):
    from fastapi.templating import Jinja2Templates
    from app.changelog import get_entries_for_display
    _templates = Jinja2Templates(directory="app/templates")
    return _templates.TemplateResponse("changelog.html", {
        "request": request,
        "entries": get_entries_for_display(),
        "current_page": "changelog",
        "current_version": settings.app_version,
    })
