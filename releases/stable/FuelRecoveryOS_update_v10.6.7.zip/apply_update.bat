@echo off
chcp 65001 >NUL
title Fuel Recovery OS - アップデート適用中
setlocal enabledelayedexpansion
set "INSTALL_DIR=%~dp0"
cd /d "%INSTALL_DIR%"
set PORT=8007
set "PY=%INSTALL_DIR%python\python.exe"
set "STAGING=%INSTALL_DIR%update_staging"
set "READY=%STAGING%\ready"
set "APPLIED=%STAGING%\applied"
set "ROLLBACK=%STAGING%\rollback\previous"

REM 1. Pre-checks
if not exist "%READY%\MANIFEST.toml" (
    echo [エラー] アップデート用ファイルが見つかりません (MANIFEST.toml が欠落)
    pause
    exit /b 1
)
if not exist "%READY%\app" (
    echo [エラー] アップデート用ファイルが見つかりません (app/ ディレクトリが欠落)
    pause
    exit /b 1
)

echo ============================================================
echo   Fuel Recovery OS  アップデートを適用しています
echo   (このウィンドウは自動で閉じます。閉じないでください)
echo ============================================================
echo.

REM 2. Wait for uvicorn to release port (90s timeout)
echo  サーバーの停止を待っています...
set /a WAIT=0
:wait_loop
netstat -ano | findstr ":%PORT% " | findstr "LISTENING" >NUL 2>&1
if errorlevel 1 goto port_free
set /a WAIT+=1
if !WAIT! GEQ 90 (
    echo [エラー] サーバーが 90 秒経っても停止しません。中止します。
    pause
    exit /b 2
)
timeout /t 1 /nobreak >NUL
goto wait_loop
:port_free
echo  サーバー停止 OK

REM 3. Snapshot current files for rollback
echo  現バージョンを退避しています...
if exist "%STAGING%\rollback" rmdir /s /q "%STAGING%\rollback" 2>NUL
mkdir "%ROLLBACK%" 2>NUL
robocopy "%INSTALL_DIR%app"    "%ROLLBACK%\app"    /E /R:2 /W:2 /NFL /NDL /NJH /NJS /NP /XD __pycache__ /XF *.pyc >NUL
robocopy "%INSTALL_DIR%static" "%ROLLBACK%\static" /E /R:2 /W:2 /NFL /NDL /NJH /NJS /NP >NUL
if exist "%INSTALL_DIR%start.bat" copy /Y "%INSTALL_DIR%start.bat" "%ROLLBACK%\start.bat" >NUL

REM 4. Read target version from MANIFEST.toml (format: version = "10.6.0")
set TARGET_VER=
for /f "tokens=2 delims==" %%V in ('findstr /b /c:"version" "%READY%\MANIFEST.toml" 2^>NUL') do (
    if not defined TARGET_VER set "TARGET_VER=%%V"
)
set "TARGET_VER=!TARGET_VER:"=!"
set "TARGET_VER=!TARGET_VER: =!"
if not defined TARGET_VER set "TARGET_VER=unknown"

REM 5. Record applied marker (no trailing whitespace; '>' immediately after var)
if exist "%APPLIED%" rmdir /s /q "%APPLIED%" 2>NUL
mkdir "%APPLIED%" 2>NUL
>"%APPLIED%\applied_version" echo !TARGET_VER!

REM 6. Apply files (robocopy)
echo  新しいファイルを配置しています  (v!TARGET_VER!)...
robocopy "%READY%\app"    "%INSTALL_DIR%app"    /E /R:3 /W:5 /NFL /NDL /NJH /NJS /NP /XD __pycache__ /XF *.pyc
set RC1=%errorlevel%
robocopy "%READY%\static" "%INSTALL_DIR%static" /E /R:3 /W:5 /NFL /NDL /NJH /NJS /NP
set RC2=%errorlevel%
if exist "%READY%\start.bat" copy /Y "%READY%\start.bat" "%INSTALL_DIR%start.bat" >NUL

if !RC1! GEQ 8 goto fail_robocopy
if !RC2! GEQ 8 goto fail_robocopy

REM 7. Spawn start.bat detached
echo  新バージョンを起動しています...
start "" /B cmd /c "%INSTALL_DIR%start.bat"

REM 8. Poll /health for up to 90 seconds
echo  起動完了を確認しています...
set /a HC=0
:health_loop
timeout /t 2 /nobreak >NUL
"%PY%" -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:%PORT%/health', timeout=2)" >NUL 2>&1
if not errorlevel 1 goto health_ok
set /a HC+=2
if !HC! GEQ 90 goto fail_health
goto health_loop

:health_ok
echo.
echo ============================================================
echo   v!TARGET_VER! へのアップデート完了
echo ============================================================
exit /b 0

:fail_robocopy
echo [エラー] ファイル配置に失敗しました (RC1=!RC1! RC2=!RC2!)。前バージョンに戻します...
goto do_rollback

:fail_health
echo [エラー] 新バージョンの起動確認ができませんでした (90秒タイムアウト)。前バージョンに戻します...
goto do_rollback

:do_rollback
start "" /B cmd /c "%INSTALL_DIR%rollback.bat"
exit /b 8
