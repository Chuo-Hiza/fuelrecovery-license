"""請求明細(FuelInvoice) → 月次給油(MonthlyFuelInput) 同期サービス。

請求明細から(車番→車両コード)マッピング経由で月次給油量・金額・単価を集計し、
既存の MonthlyFuelInput テーブルに upsert することで、ダッシュボードや燃費分析が
自動的に新データを反映できるようにする。

優先順位:
  - SystemSetting "fuel_data_priority" = "manual"(デフォルト)
    → 同月に source="manual" の MonthlyFuelInput がある場合は上書きしない
  - "invoice"
    → 上書き(invoice 側を真とする)
"""
from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.csv_import import TripReport
from app.models.fuel_input import MonthlyFuelInput
from app.models.fuel_invoice import FuelInvoice, FuelInvoiceVehicleMapping
from app.models.master import Vehicle
from app.models.system import SystemSetting

logger = logging.getLogger(__name__)

PRIORITY_KEY = "fuel_data_priority"  # "manual" or "invoice"
DEFAULT_PRIORITY = "manual"

# 給油として扱う商品カテゴリ
_FUEL_CATEGORIES = {"diesel", "gasoline"}


def get_priority(db: Session) -> str:
    row = db.query(SystemSetting).filter_by(key=PRIORITY_KEY).first()
    if row and row.value in ("manual", "invoice"):
        return row.value
    return DEFAULT_PRIORITY


def set_priority(db: Session, value: str) -> None:
    if value not in ("manual", "invoice"):
        raise ValueError(f"invalid priority: {value}")
    row = db.query(SystemSetting).filter_by(key=PRIORITY_KEY).first()
    if row:
        row.value = value
    else:
        db.add(SystemSetting(
            key=PRIORITY_KEY, value=value,
            description="請求明細と手入力で同月にデータがある場合の優先順位",
        ))
    db.commit()


def list_invoice_vehicle_nos(db: Session) -> list[dict[str, Any]]:
    """請求明細に存在する全 vehicle_no を集計し、マッピング状況とともに返す。"""
    # FuelInvoice 側の集計
    rows = (
        db.query(
            FuelInvoice.vehicle_no,
            func.count(FuelInvoice.id).label("rec_count"),
            func.min(FuelInvoice.transaction_date).label("first_date"),
            func.max(FuelInvoice.transaction_date).label("last_date"),
        )
        .filter(FuelInvoice.vehicle_no.isnot(None))
        .group_by(FuelInvoice.vehicle_no)
        .order_by(FuelInvoice.vehicle_no)
        .all()
    )
    # マッピング辞書
    mappings = {m.invoice_vehicle_no: m for m in db.query(FuelInvoiceVehicleMapping).all()}

    # 全車両(セレクトボックス用)
    # 優先順位:
    #   1. Vehicle マスタ(明示登録)
    #   2. TripReport の distinct (vehicle_code, vehicle_name) — Estra-WEB2 取込で得られた実車両
    seen: dict[str, str] = {}
    for v in (
        db.query(Vehicle)
        .filter(Vehicle.is_active == True)  # noqa: E712
        .order_by(Vehicle.code)
        .all()
    ):
        if v.code:
            seen[v.code] = v.name or v.code
    for code, name in (
        db.query(TripReport.vehicle_code, TripReport.vehicle_name)
        .filter(TripReport.vehicle_code.isnot(None))
        .distinct()
        .all()
    ):
        if code and code not in seen:
            seen[code] = name or code
    vehicle_choices = [{"code": c, "name": n} for c, n in sorted(seen.items())]

    out = []
    for r in rows:
        m = mappings.get(r.vehicle_no)
        out.append({
            "invoice_vehicle_no": r.vehicle_no,
            "rec_count": r.rec_count,
            "first_date": r.first_date,
            "last_date": r.last_date,
            "mapped_code": m.vehicle_code if m else None,
            "mapped_name": m.vehicle_name if m else None,
            "is_ignored": (m is not None and not m.vehicle_code),
            "note": m.note if m else "",
        })
    return out, vehicle_choices


def upsert_mapping(db: Session, invoice_vno: str, vehicle_code: str | None,
                   note: str | None = None) -> None:
    """マッピングを upsert。vehicle_code='' or None で対象外にできる。"""
    invoice_vno = (invoice_vno or "").strip()
    if not invoice_vno:
        return
    code = (vehicle_code or "").strip() or None
    name = None
    if code:
        # まず Vehicle マスタ
        v = db.query(Vehicle).filter_by(code=code).first()
        if v:
            name = v.name
        else:
            # 次に TripReport から実取込済みかを確認
            tr = (
                db.query(TripReport.vehicle_name)
                .filter(TripReport.vehicle_code == code)
                .order_by(TripReport.operation_date.desc())
                .first()
            )
            if tr:
                name = tr[0]
            else:
                code = None  # どこにも存在しない不正コードは対象外として保存
    row = db.query(FuelInvoiceVehicleMapping).filter_by(invoice_vehicle_no=invoice_vno).first()
    if row:
        row.vehicle_code = code
        row.vehicle_name = name
        if note is not None:
            row.note = note
    else:
        db.add(FuelInvoiceVehicleMapping(
            invoice_vehicle_no=invoice_vno,
            vehicle_code=code,
            vehicle_name=name,
            note=note or "",
        ))
    db.commit()


def sync_to_monthly(db: Session) -> dict[str, int]:
    """全期間の請求明細を月次集計し MonthlyFuelInput に upsert。

    マージ仕様 (v10.6.14〜):
      - 既存が無い → invoice として新規作成
      - 既存が source=manual かつ priority=manual かつ 給油量 & 金額 が両方埋まっている
        → 何もしない (skipped_full_manual)
      - 既存が source=manual かつ priority=manual かつ 給油量 or 金額 のどちらかが NULL
        → 欠けたフィールドだけ invoice 集計値で補完 (merged_manual)。source は manual を維持、
          note 末尾に「金額: 手入力(X円) / 給油量: 請求明細(Y L)」のような来歴を追記
      - それ以外 (既存が invoice / csv 由来、または priority=invoice)
        → 給油量・金額・unit_price・source=invoice で完全上書き (updated)

    Returns:
        {"created": N, "updated": N, "merged_manual": N,
         "skipped_manual_priority": N, "no_mapping": N, "ignored": N}
    """
    priority = get_priority(db)

    mappings = {m.invoice_vehicle_no: m for m in db.query(FuelInvoiceVehicleMapping).all()}

    # 集計: (vehicle_no, year_month) → (qty, cost)
    invoices = (
        db.query(FuelInvoice)
        .filter(
            FuelInvoice.product_category.in_(list(_FUEL_CATEGORIES)),
            FuelInvoice.transaction_date.isnot(None),
            FuelInvoice.vehicle_no.isnot(None),
        )
        .all()
    )
    bucket: dict[tuple, dict[str, float]] = defaultdict(lambda: {"qty": 0.0, "cost": 0})
    for inv in invoices:
        ym = inv.transaction_date.strftime("%Y-%m")
        key = (inv.vehicle_no, ym)
        bucket[key]["qty"] += inv.quantity or 0.0
        bucket[key]["cost"] += inv.amount_total or 0

    created = 0
    updated = 0
    merged_manual = 0
    skipped_manual = 0
    no_mapping = 0
    ignored = 0

    for (invoice_vno, ym), agg in bucket.items():
        m = mappings.get(invoice_vno)
        if not m:
            no_mapping += 1
            continue
        if not m.vehicle_code:
            ignored += 1
            continue

        qty = round(agg["qty"], 2)
        cost = int(agg["cost"])
        unit_price = round(cost / qty, 2) if qty > 0 else None

        existing = db.query(MonthlyFuelInput).filter_by(
            vehicle_code=m.vehicle_code, year_month=ym,
        ).first()

        if existing:
            existing_source = existing.source or "manual"
            if existing_source == "manual" and priority == "manual":
                # 手入力保護モード。「片方欠け」だけ補完、両方埋まってれば skip。
                amount_missing = existing.fuel_amount_l is None and qty > 0
                cost_missing = existing.fuel_cost_yen is None and cost > 0
                if not (amount_missing or cost_missing):
                    skipped_manual += 1
                    continue
                # 欠けた側のみ補完
                if amount_missing:
                    existing.fuel_amount_l = qty
                if cost_missing:
                    existing.fuel_cost_yen = cost
                # unit_price は最終値で再計算
                a = existing.fuel_amount_l
                c = existing.fuel_cost_yen
                existing.fuel_unit_price = (
                    round(c / a, 2) if a and c and a > 0 else None
                )
                # 来歴を note に追記 (どのフィールドがどこから来たかを残す)
                amount_src = "請求明細" if amount_missing else "手入力"
                cost_src = "請求明細" if cost_missing else "手入力"
                provenance = (
                    f"[merged: 金額={cost_src}({existing.fuel_cost_yen}円) "
                    f"/ 給油量={amount_src}({existing.fuel_amount_l}L)]"
                )
                existing.note = (
                    f"{existing.note} {provenance}" if existing.note else provenance
                )
                # source は manual を維持
                merged_manual += 1
                continue
            # それ以外 (priority=invoice or 既存が invoice/csv 由来) は完全上書き
            existing.fuel_amount_l = qty
            existing.fuel_cost_yen = cost
            existing.fuel_unit_price = unit_price
            existing.source = "invoice"
            updated += 1
        else:
            db.add(MonthlyFuelInput(
                vehicle_code=m.vehicle_code,
                vehicle_name=m.vehicle_name or "",
                year_month=ym,
                fuel_amount_l=qty,
                fuel_cost_yen=cost,
                fuel_unit_price=unit_price,
                source="invoice",
                note="請求明細から自動同期",
            ))
            created += 1

    db.commit()
    summary = {
        "created": created, "updated": updated,
        "merged_manual": merged_manual,
        "skipped_manual_priority": skipped_manual,
        "no_mapping": no_mapping, "ignored": ignored,
    }
    logger.info(f"fuel_invoice_sync: {summary}")
    return summary
