/* Fuel Recovery OS — 全画面共通スクリプト(v10.7.6 で base.html のインラインから外出し)
 *  - setBaseMonth(ym): 基軸月クッキーを設定して再読込(ヘッダーの月セレクタから呼ばれる。グローバル)
 *  - table[data-sortable]: 見出し th[data-col] クリックで列ソート */

window.setBaseMonth = function (ym) {
  var exp = new Date();
  exp.setDate(exp.getDate() + 30);
  document.cookie = 'base_month=' + ym + ';path=/;expires=' + exp.toUTCString();
  location.reload();
};

(function () {
  function parseVal(text) {
    var t = text.trim().replace(/\s+/g, ' ');
    if (!t || t === '—' || t === '－' || t === '-') return null;
    var n = parseFloat(t.replace(/[^0-9.]/g, ''));
    return isNaN(n) ? t : n;
  }
  function initSortable(tbl) {
    tbl.querySelectorAll('th[data-col]').forEach(function (th) {
      var ic = document.createElement('span');
      ic.className = 'sort-icon'; ic.textContent = '⇅';
      th.appendChild(ic);
      th.addEventListener('click', function () {
        var col = parseInt(th.getAttribute('data-col'));
        var dir = th.getAttribute('data-dir') === 'asc' ? 'desc' : 'asc';
        tbl.querySelectorAll('th[data-col]').forEach(function (t) {
          t.removeAttribute('data-dir');
          t.querySelector('.sort-icon').textContent = '⇅';
        });
        th.setAttribute('data-dir', dir);
        th.querySelector('.sort-icon').textContent = dir === 'asc' ? '▲' : '▼';
        var tbody = tbl.querySelector('tbody');
        var rows = Array.from(tbody.querySelectorAll('tr'));
        rows.sort(function (a, b) {
          var va = parseVal(a.cells[col].textContent);
          var vb = parseVal(b.cells[col].textContent);
          var inf = dir === 'asc' ? Infinity : -Infinity;
          if (va === null) va = inf; if (vb === null) vb = inf;
          if (typeof va === 'number' && typeof vb === 'number') return dir === 'asc' ? va - vb : vb - va;
          return dir === 'asc' ? String(va).localeCompare(String(vb), 'ja') : String(vb).localeCompare(String(va), 'ja');
        });
        rows.forEach(function (r) { tbody.appendChild(r); });
      });
    });
  }
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('table[data-sortable]').forEach(initSortable);
  });
})();
