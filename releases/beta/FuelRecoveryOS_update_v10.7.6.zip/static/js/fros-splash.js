/* Fuel Recovery OS — 起動時スプラッシュ(1 セッションに 1 回だけ表示)
 * base.html の #fros-splash の直後に同期読込される(v10.7.6 でインラインから外出し)。 */
(function () {
  var KEY = 'frosSplashShown_v10_2_1';
  try {
    if (sessionStorage.getItem(KEY)) return;
    sessionStorage.setItem(KEY, '1');
  } catch (e) { /* sessionStorage unavailable: show once anyway */ }
  var sp = document.getElementById('fros-splash');
  if (!sp) return;
  sp.style.display = 'flex';
  requestAnimationFrame(function () { sp.style.opacity = '1'; });
  var hide = function () {
    sp.style.opacity = '0';
    setTimeout(function () { sp.style.display = 'none'; }, 700);
  };
  sp.addEventListener('click', hide);
  setTimeout(hide, 2200);
})();
