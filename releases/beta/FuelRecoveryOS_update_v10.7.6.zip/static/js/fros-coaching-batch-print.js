/* Fuel Recovery OS — 指導書一括印刷: Leaflet で各乗務員の地図を描き、描画後に印刷ダイアログを開く
 * (v10.7.6 で coaching_batch_print.html のインラインから外出し)
 * 地図データは同ページの <script type="application/json" id="cbp-data"> から読む。 */
(function () {
  var dataEl = document.getElementById('cbp-data');
  if (!dataEl) return;
  var driversData;
  try {
    driversData = JSON.parse(dataEl.textContent);
  } catch (e) {
    driversData = [];
  }
  var colorMap = { idle_high: '#E03E3E', idle_mid: '#F5A623', long_stop: '#3B82F6', normal: '#10B981' };
  var mapsReady = 0;
  var totalMaps = driversData.length;

  var printed = false;
  function schedulePrint() {
    if (printed) return;
    printed = true;
    window.print();
  }

  driversData.forEach(function (d) {
    var mapEl = document.getElementById('map-' + d.driver_code);
    if (!mapEl || typeof L === 'undefined') return;

    var map = L.map(mapEl, { zoomControl: false })
      .setView([d.center_lat, d.center_lon], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors', maxZoom: 18,
    }).addTo(map);

    var layers = [];
    d.markers.forEach(function (m) {
      var color = colorMap[m.marker_type] || '#10B981';
      var circle = L.circleMarker([m.lat, m.lon], {
        radius: Math.max(7, Math.min(16, 7 + m.visit_count * 1.2)),
        fillColor: color, color: '#fff', weight: 2, opacity: 1, fillOpacity: 0.85,
      }).addTo(map);
      circle.bindPopup('<b>' + (m.address || '地点') + '</b><br>訪問: ' + m.visit_count + '回　アイドリング: <b>' + m.avg_idle_min + '分</b>');
      layers.push(circle);
    });
    d.routes.forEach(function (r) {
      if (r.points.length < 2) return;
      L.polyline(r.points.map(function (p) { return [p.lat, p.lon]; }), {
        color: r.events > 5 ? '#E03E3E' : r.events > 2 ? '#F5A623' : '#3B82F6',
        weight: r.events > 5 ? 3 : 2, opacity: r.events > 5 ? 0.7 : 0.3,
        dashArray: r.events > 5 ? null : '5,5',
      }).addTo(map);
    });
    if (layers.length > 0) {
      map.fitBounds(L.featureGroup(layers).getBounds().pad(0.15));
    }

    map.on('load', function () {
      mapsReady++;
      if (mapsReady >= totalMaps) schedulePrint();
    });
  });

  // タイムアウト保険: 全マップ読み込み完了を待たず最大 3 秒で印刷
  setTimeout(function () { schedulePrint(); }, 3000);
})();
