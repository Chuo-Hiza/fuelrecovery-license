"""ユーザー向け更新履歴。

リリース毎にエントリを追加。表示順は新→旧。type は patch / minor / major。
"""
from __future__ import annotations

# このバージョン未満のエントリは /changelog で notes を伏せる
# (バージョン番号・日付・タイトルは表示する)。
# 顧客に見せたくない初期開発期間のリリースを「履歴あり/詳細非公開」扱いにする。
MIN_VERBOSE_VERSION = "10.6.6"


def _ver_tuple(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.split("."))
    except (ValueError, AttributeError):
        return (0,)


def get_entries_for_display() -> list[dict]:
    """/changelog に渡す表示用エントリ。

    MIN_VERBOSE_VERSION 未満のエントリは notes を空にし notes_hidden=True を
    立てる (テンプレ側で「詳細省略」表示)。
    """
    cutoff = _ver_tuple(MIN_VERBOSE_VERSION)
    out: list[dict] = []
    for e in CHANGELOG:
        if _ver_tuple(e.get("version", "")) < cutoff:
            out.append({**e, "notes": [], "notes_hidden": True})
        else:
            out.append(e)
    return out


CHANGELOG: list[dict] = [
    {
        "version": "10.7.6",
        "date": "2026-10-27",
        "type": "patch",
        "title": "ライセンス管理画面に「会社名（画面表示用）」を追加",
        "notes": [
            "**設定 → ライセンス管理 に「会社名（画面表示用）」欄を追加しました。** 画面右上の「✓ ご契約中」の横と、ライセンス管理画面の「ご契約者」に表示する名前を、このPCで入力できます。入力した名前はこのPCにだけ保存され、外部には送られません",
            "ベンダー側のライセンス情報に会社名を含めない運用に変更したため、これまで表示されていた「✓ ご契約中」の横の会社名が、上記の欄に入力するまで表示されなくなることがあります。ご契約内容・期限・機能には影響ありません (通常はベンダーのリモート対応時に入力します)",
            "操作ガイドに 26.15「会社名（画面表示用）の入力」を追加し、24章の説明を更新しました",
            "画面の表示スクリプト (起動時の表示・基軸月の切替・表の並べ替え・面談カード一括印刷の地図) を外部ファイルに分離しました。画面の見え方や操作は変わりません",
        ],
        "internal_title": "ライセンス会社名のローカル表示 (設計 docs/dev/改修設計_ライセンス会社名ローカル表示_v1076_20261027.md)",
        "internal_notes": [
            "公開リポジトリ fuelrecovery-license の JSON・commit から会社名を除去 (2026-10-27、FreeNippo チーム是正依頼 09-29)。JSON の customer_name は空文字で署名、クライアントの検証式 id|name|issued|expiry は不変。履歴は作り直し済み",
            "system_settings に license_display_name を追加。表示は display_name → license_customer_name (旧 JSON 由来) → 未設定 の順 (resolve_customer_name)。fetch_and_apply_license は display_name を上書きしない",
            "POST /settings/license は customer_id を空で送れる (表示名だけの保存)。顧客ID の消去はこの画面では行わない",
            "migration 不要 (settings key 追加のみ)",
            "Windows Defender 定義 1.461.216.0 (2026-10-27) が v10.7.5 の app/templates/base.html と coaching_batch_print.html を Trojan:Script/Ulthar.A!ml として誤検知 (内容の完全一致判定)。回避として base.html のインライン JS を static/js/fros-splash.js・fros-base.js に、coaching_batch_print.html の地図 JS を static/js/fros-coaching-batch-print.js に外出し (データは <script type=application/json id=cbp-data>)。配信前に tools/defender_check.py で ZIP を検査する (設計 docs/dev/改修設計_Defender誤検知回避_v1076_20261027.md)",
        ],
    },
    {
        "version": "10.7.5",
        "date": "2026-09-16",
        "type": "minor",
        "title": "「今朝の確認」画面の追加と、判定基準の一本化",
        "notes": [
            "**「☕ 今朝の確認」画面を追加しました。** 基準を超えた乗務員の方だけを、重い順にカードで表示します。全員を並べるのではなく「まず声をかけた方がよい方」だけを出しますので、朝の確認が短時間で済みます。要注意 (赤) は人数を絞らず全員、注意 (黄) は既定で3名まで表示し、残りはボタンでその場に開けます",
            "起動時に開く画面を「経営ダッシュボード」と「今朝の確認」から選べるようにしました (設定 → 画面の既定、および各画面右上から)",
            "**判定基準 (注意・要注意の線) を1画面にまとめました。** これまで画面ごとに別々だった線を設定画面の1か所に集約し、ここでの設定がダッシュボードの色分け・指導書の自動判別・今朝の確認のすべてに反映されます。数値を変えると「この設定だと何名になるか」が保存前に表示されます",
            "**この版への更新時に、判定項目6つが自動的に有効になります。** これまでの版では判別条件がすべて無効のまま保存されている場合があり、色分けや自動判別が働いていませんでした。更新後に赤・黄の人数が増えて見えるのはこのためです。多い・少ないと感じられた場合は設定画面で線を調整してください (お客様が独自に変更された値はそのまま残ります)",
            "**面談カードに「声かけの一例」を表示するようにしました。** 基準を超えている方について、朝の声かけの文例 (一言目・今日から頼むこと・来月見る指標) と、本人には見せない管理者メモを表示します。例文ですので、そのまま読む必要はありません。最終的な言い方は運行管理者の方のご判断です",
            "声かけの一例は、アイドリング率・急操作/100km・速度超過/100km・月間拘束について表示します。総合評価点・安全評価・経済評価はデジタコ (ESTRA-Web2) が評価した点数で、当システムは合計点のみを受け取っているため、内訳のご確認先 (詳細分析 → レーダーチャート) をご案内します",
            "速度超過の基準が2つ (乗務員の要注意判定は月間の100kmあたり、速度超過シートの日別マスは1日あたり) あり数え方が違うことを、設定画面と操作ガイドに明記しました",
            "操作ガイドに 26.12「今朝の確認」/ 26.13「判定基準の一元化と画面の既定」/ 26.14「声かけの一例」を追加しました",
        ],
        "internal_title": "朝5分ビュー + 判定サービス一本化 + 声かけ文言 (ADR-003 確定設計 20260909 / 改修提案 20260916 案A)",
        "internal_notes": [
            "判定を app/services/driver_alerts.py に集約。色分け・自動判別・ヘルスマップ・/morning が同じ build_alert_list を使う。dashboard.py の独自判定を撤去",
            "判定基準を2段階(warn/alert)化。normalize_criteria が旧形式(threshold 1段階)を warn へ載せ替え、旧既定値のままなら較正後の新既定へ。speed_over(月間の生回数)は単位変更のため引き継がず破棄し speed_over_100km へ",
            "migrate_criteria: 起動時1回。**enabled を全ON に揃える**(挙動変更)。実データで6条件すべて false のまま保存されており判定が働いていなかった(2026-05-10保存)。原因は POST /settings に criteria_form が無い場合に全条件を空で上書きしていた潜在バグで、こちらも修正済み",
            "較正: 旧既定値では 19名中16名が赤。実データ(2026-01..03)で再較正し 赤3/黄8/OK8 に。speed_over は距離で正規化(確定設計 §2 発見2)",
            "attach_copy_context/field_context: state(first/streak2/streak3plus/improving)・streak・prev_value・trend・ok_fields を供給。連続月数の定義を field_context に一本化し habitual_streak を載せ替え(問い合わせが 乗務員数x月数 → 1回)",
            "app/data/coaching_copy.json + app/services/coaching_copy.py。文言は Gemini 3.1 Pro 執筆をブラウザ自動操作で取得し、tools/ux_copy の検証器(R01-R23)を通したもののみ同梱。実行時は選択と穴埋めのみで標準ライブラリだけを使う(依存追加・外部通信なし)",
            "avg_score/avg_safety/avg_economy は profile copy:false。ESTRA-Web2 が顧客選択の3〜12項目を重み付けした合計で、当システムは合計点しか受け取らない(マニュアル第14版 p.600-607)。助言を書くと当てずっぽうになるため導線のみ。正本は ESTRA 側(項目xランクのコメント・指導対象ランク・指導書)",
            "improving の文言が無い指標では代替に落とさない。streak2 の「先月に続き」は改善した人に言うと意味が逆になる",
            "検証手順: docs/dev/検証手順_朝5分ビューと判定基準一元化_20260915.md",
        ],
    },
    {
        "version": "10.7.4",
        "date": "2026-08-21",
        "type": "patch",
        "title": "給油CSV取込の結果表示と日付形式の改善 (お客様のご要望より)",
        "notes": [
            "給油データのCSVインポートで、取込結果 (月次・日次の件数 / エラー件数と行番号・理由) が画面に表示されるようになりました。これまでは結果が表示されず、取込に失敗しても気づけませんでした",
            "CSVの日付・年月は「2026/7/5」のような月日のゼロ埋めなし表記でも取り込めるようになりました (ExcelでCSVを保存し直した場合の形式に対応)",
            "日次CSVを再取込した場合、同じ内容の行 (車両・日付・給油量が一致) は重複登録せずスキップし、金額のみ修正された行は金額を更新するようになりました",
            "月次CSVで給油量・金額の片方だけを再取込した際に、登録済みのもう片方の値が消えてしまう問題を修正しました (空欄の項目は登録済みの値を保持します)",
            "操作ガイド (13章・22章ほか) と画面の説明を見直しました。月次燃費実績は給油データ管理画面で登録した月次データから計算されること、日次データは現在登録のみに対応していることを明記しています",
        ],
        "internal_title": "顧客FB④ 給油CSV取込UX 第1弾 (P1結果表示+P2日付寛容化+ガイド修正)",
        "internal_notes": [
            "fuel.py csv-import: 件数/エラーを upload_msg で /fuel?tab=manual へ返却 (従来は破棄して無言リダイレクト)。エラーは行番号+理由、60字×3件に丸め。必須列欠落・文字コード不明もファイル単位メッセージ化 (旧: 不完全contextのTemplateResponseでUndefinedError 500)",
            "base.py に parse_flexible_date / normalize_year_month を新設 (共通化)。年月は 1..12 範囲まで検証してから保存 (不正 year_month は /fuel 描画を500で落とすため)。tests/test_fuel_csv_import.py 追加",
            "日次重複判定は既存行の事前ロードdictで実施 (autoflush=False でDB照会は同一ファイル内重複が見えない + N+1回避)。キー=車両×日付×給油量、金額のみ差異は更新",
            "月次upsertをmerge化 (CSV空欄で既存値をNone上書きしない)。source は merge後の完全性で再判定",
            "help.html 22章1389行の誤記修正 (給油明細の用途=燃費計算→記録のみ)、13章に日次の現行制約・CSV仕様明記、fuel.html 誘導文言を月次限定に (ADR-004)",
            "背景: 明光運輸QA 2026-08-20〜21 (docs/dev/監査記録_顧客回答2通目_20260821.md)。第2弾 P5案X+P7 は別リリース",
        ],
    },
    {
        "version": "10.7.3",
        "date": "2026-07-28",
        "type": "patch",
        "title": "ETC明細の0円利用の表示・CSV再取込の簡単化 (お客様のご要望より)",
        "notes": [
            "ETC明細に、料金が0円の利用も表示されるようになりました。首都高の連結車両 (2軸トレーラーヘッド) などはゲートで料金が表示されず0円で記録されるため、これまで一覧から漏れていました。0円の行には「ⓘ」注記が付きます (実額はETC利用照会サービスでご確認ください)",
            "最近取り込んだ分のETCデータ (システム内に保管されている約1週間分) は、このアップデート後の起動時に自動で取り直されます (操作は不要です)。それ以前の分を表示したい場合は、該当CSVをいつもの取込フォルダに入れ直してください (手元にない場合のESTRA-Web2からの再取得手順は操作ガイド18章に記載しました)",
            "CSVの再取込が簡単になりました。一度取り込んだCSVでも、取込フォルダに入れ直すだけで再取込されます (同じ運行のデータは置き換えられ、二重にはなりません)",
            "操作ガイドを全体的に見直しました (アップデートの説明を現行のオンライン更新に合わせて刷新、新機能の説明を追加など)",
        ],
        "internal_title": "顧客FB③ ETC 0円行 (首都高連結車両特例) + 再取込UX + ガイド総点検",
        "internal_notes": [
            "toll importer: 採用判定を金額→IC欄に変更 (FreeNippo正本 parsers.py と同一判定)。金額0/空欄は0円で保存",
            "watcher.process_file: 再出現ファイルは常に再処理 (全importer洗い替え/upsertで冪等)。force引数は互換残置",
            "main._reimport_etc_zero_yen_v1073: done/アーカイブから _etc を1回だけ自動再取込 (SystemSetting flag)",
            "etc_detail に zero_cost/zero_count。help.html 総点検 (master 2fd4a4d) + ADR-004 制定を同梱",
        ],
    },
    {
        "version": "10.7.2",
        "date": "2026-07-24",
        "type": "minor",
        "title": "軽油単価の月別設定・ETC明細の日次閲覧 (お客様のご要望より)",
        "notes": [
            "軽油単価を月ごとに設定・保持できるようになりました (設定画面・0.1円単位)。各月の損失計算には「その月の単価 → それ以前で最新の月別単価 → 既定値」の順で適用され、過去月の単価はそのまま保持されます",
            "期間集計に「ETC明細」を追加しました。年月日で期間指定 (同じ日付を入れれば単日) して、ETC利用の明細 (利用日時・乗務員・車両・入口/出口IC・金額) を一覧・CSV出力できます。通行料の精査にご活用ください",
            "ETC明細の利用日時は今回のアップデート以降の取込分から表示されます。過去の取込分に表示したい場合は、CSV取込画面の「取込済みも再取込する (強制)」で _etc を取り込み直してください",
        ],
        "internal_title": "顧客FB① 月別fuel_price / ② TollRecord.used_at+ETC明細ビュー",
        "internal_notes": [
            "fuel_price_YYYY-MM キー方式+get_fuel_price(db, month) フォールバックチェーン。呼出7箇所を月渡し化",
            "toll_records.used_at 追加(_migrate_db ALTER TABLE)。importer で精算日付/精算時刻を取込。NULL は運行日フォールバック+時刻なし表記",
            "位置づけ: 請求証憑はETC利用照会サービス/カード明細が正、本一覧は精査補助(参考) — 画面・CSVメタに明記(ADR-003 法令区分の整理)",
        ],
    },
    {
        "version": "10.7.1",
        "date": "2026-07-22",
        "type": "patch",
        "title": "ダッシュボードの初期タイルに新機能を追加",
        "notes": [
            "要確認案件に「✓ 対応済み」を追加しました。見直し・面談を終えた案件を補正から対応済みにすると、毎日チェックの数字から外れ、処理済みとして一覧に残ります (数字＝未対応の実数になります)",
            "ダッシュボードの目的別タイルの初期セットに「労務 (拘束時間)」「期間集計」を追加しました (タイルを編集済みの場合は、お客様の設定がそのまま優先されます)",
        ],
        "internal_title": "DEFAULT_DASH_TILES に labor/period を追加",
        "internal_notes": [
            "cookie未設定時のみ既定が効く(保存済み選択は継承)。検証機の全OFFはfros_testとのcookie共有(ポート非区別)が原因で顧客には非該当",
        ],
    },
    {
        "version": "10.7.0",
        "date": "2026-07-22",
        "type": "minor",
        "title": "労務チェック・期間集計・ダッシュボード刷新ほか大型機能追加",
        "notes": [
            "【労務】拘束時間のチェック画面を新設しました (メニュー「法令・労務」)。乗務員ごとの月次一覧 (上限・残時間・色分け) と日次チェック (乗務員×日付) で、上限接近・超過が一目で分かります。上限値は設定画面で変更できます",
            "【労務】デジタコのCSVだけで拘束時間を自動算出します。日報システム (Free Nippo) をご利用の場合は「データ管理→労務データ取込」で確定値を取り込むと、日報と同じ数字が優先表示されます",
            "【集計】期間集計を新設しました (運転分析)。期間 (開始月〜終了月) ×乗務員/車両で運行数・運行日数・走行km・ETC回数/料金を一覧し、CSV出力・A4横印刷ができます (精算・提出用)",
            "【ダッシュボード】最上段に3カードを新設: 「最新運行日の状況」(前運行日比±と最終取込時刻)・「労務リスク」(超過/接近人数)・「モード設定の確認推奨」。損失回収ファネルと6ヶ月トレンドが一目で入るレイアウトになりました",
            "【ダッシュボード】目的別タイルを全OFFにできるようになりました (編集→すべてOFF)。ランキングタイルは1枚に統合しました",
            "【高速モード分析】運行軌跡を検証ツール化しました。画面の役割・確認手順 (平均速度→地図→ETC照合) を明示し、高速平均速度を最重要指標として色付き表示します。GPS座標の形式によって地図が表示されない問題も修正しました",
            "【速度超過】例外区間の登録が簡単になりました。確認ページの速度超過ポイントから「+例外区間に登録」を押すだけで矩形が自動生成されます (緯度経度の手入力・地図2点クリックも可)。例外区間内の超過は1クリックでスピード管理表の補正につなげられます",
            "【取込】CSV一括取込に「取込済みも再取込する (強制)」オプションを追加しました (訂正データの再反映用)",
            "【給油】推定の根拠表示を実際の設定値 (車両別基準燃費) の一覧に刷新し、設定画面への編集導線を付けました",
            "【修正】荷主交渉エビデンスの表示月が固定されていた問題を修正し、基軸月に連動するようにしました",
            "【ガイド】操作ガイドを大幅更新しました (労務・期間集計・高速モードの使い方、スピードメーターとデジタコの差異など FAQ 追加)",
        ],
        "internal_title": "N群(労務・期間集計/FreeNippo連携)+全体整理+R-2/R-3/R-5/R-8",
        "internal_notes": [
            "nippo_trips/nippo_import_logs 新テーブル(起動時create_all)。労務ソースはFreeNippo確定値>ESTRA算出の優先度制(ADR-002/D-6)",
            "期間集計は精算純化(給油/燃費/拘束列は各専門画面へ集約)。FreeNippo実データ273運行で数値突合検収合格",
            "_tc GPS整数スケール自動判別・日報番号full/short相互解決・タイムゾーン/丸め表示ズレ修正",
            "全体整理監査(AIチーム3観点)でshipper月固定バグ・旧文言残置を是正。詳細=docs/dev/再設計_全体整理_20260721.md",
        ],
    },
    {
        "version": "10.6.14",
        "date": "2026-05-18",
        "type": "patch",
        "title": "手入力と請求明細取込の連携を改善",
        "notes": [
            "金額だけ手入力した行に後で請求明細が届くと、給油量が自動で補完されるようになりました (逆も同様)",
            "編集で対象月や車両を変更した時に同じ車両+月の既存行と衝突しないよう保護されるようになりました",
            "CSVインポートで給油金額だけの行 (給油量空欄) も取り込めるようになりました。一覧では「CSV取込(部分)」と表示されます",
            "請求明細やCSV取込のデータは直接編集できない (元データを保護する) ように変更しました",
        ],
        "internal_title": "v10.6.13 整合性レビュー結果の修正 (#1-#4)",
        "internal_notes": [
            "#1 update_monthly_fuel に (vehicle_code, year_month) 重複 check を追加。MonthlyFuelInput は UNIQUE 制約無しなのでアプリ側ガード",
            "#2 CSV import で fuel_amount 空でも取込可に変更。完全行=csv_import / 片方欠け=csv_import_partial / 両方空=skip(エラーログ)",
            "#3 sync_to_monthly: priority=manual の時、両方埋まってれば skip、片方欠けなら欠けた側だけ補完。source は manual 維持、note に '[merged: 金額=... / 給油量=...]' で来歴追記。merged_manual カウンタ追加",
            "#4 /fuel/monthly/edit/{id} GET/POST 両方で source != 'manual' を弾く。URL 直叩きの穴塞ぎ",
            "テンプレ: 'CSV取込(部分)' バッジ (黄系 .badge-csv-partial) を追加。バッジ判定に 'invoice' 表記も明示",
            "スモークテスト: merge 順方向/逆方向/冪等、edit guards 全パス、CSV 6 シナリオ all green",
        ],
    },
    {
        "version": "10.6.13",
        "date": "2026-05-18",
        "type": "minor",
        "title": "月次給油の編集と一覧表示を強化",
        "notes": [
            "登録済みの月次給油データを編集できるようになりました (給油量や金額の後追い入力に対応)",
            "給油量と給油金額はどちらか片方だけでも保存可能になりました",
            "月次燃費実績の一覧を 車両 / 対象月 でフィルターできるようになりました",
            "列見出しをクリックして並び替え (昇順/降順) ができるようになりました",
            "件数が増えた時に画面が間延びしないよう 20 件ごとのページ表示に変更しました",
        ],
        "internal_title": "月次手入力 UX 改善 (編集 / フィルター / ソート / ページネーション)",
        "internal_notes": [
            "MonthlyFuelInput.fuel_amount_l を NOT NULL → nullable (SQLite table-rebuild migration を _migrate_db で冪等実行)",
            "/fuel/monthly POST と /fuel/monthly/edit/{id} POST で「いずれか一方は必須」検証 (両方空なら error=msg で /fuel に戻す)",
            "/fuel/monthly/edit/{id} GET + 専用テンプレ fuel_monthly_edit.html を新設",
            "/fuel に filter_vehicle / filter_month / sort / order / page を追加, 列ソートは _SORT_KEYS で 7 列対応",
            "ページ単位 20 件 (PAGE_SIZE_MONTHLY), 前後 + 数値リンク",
            "起動時マイグレーション: in-memory DB で BEFORE/AFTER/再実行/NULL挿入 まで実機検証",
        ],
    },
    {
        "version": "10.6.12",
        "date": "2026-05-18",
        "type": "patch",
        "title": "手入力フォームの空欄送信エラーを修正",
        "notes": [
            "給油金額やオドメーター数値を空欄のまま登録した時に発生していたエラー画面を修正",
            "空欄項目は未入力として正しく扱われるようになりました",
        ],
        "internal_title": "/fuel/monthly /fuel/daily の int = Form(None) 空文字 422 修正",
        "internal_notes": [
            "app/routers/fuel.py で _opt_int() / _opt_float() helper を追加",
            "fuel_cost_yen / odometer_km を str | None で受けて空文字 → None に正規化",
            "FastAPI の Form(None) は欠落キーしか拾わず、'' は int_parsing で 422 を返してしまうのが根本",
        ],
    },
    {
        "version": "10.6.11",
        "date": "2026-05-18",
        "type": "patch",
        "title": "",
        "notes": [

        ],
        "notes_hidden": True,
        "internal_title": "オンライン更新 helper bat の ASCII 化 + 自己更新機構",
        "internal_notes": [
            "apply_update.bat / rollback.bat を ASCII-only に書き直し (cmd.exe の UTF-8 multibyte 解析バグ対策)",
            "build/_write_bat_ascii_crlf() で ASCII バイト + CRLF + BOM なしを強制し Linux/WSL ビルドでも安全に",
            "build_update_pkg.py 側でも .encode('ascii') 経由でビルド時に違反検出",
            "新 apply_update.bat に self-refresh を追加: %TEMP% に refresher.bat を spawn して 5 秒後に staging\ready の bat を INSTALL_DIR へ delay-copy",
            "test PC で v10.6.9 → 10.6.10 のオンライン更新が正常完了することを実機検証",
        ],
    },
    {
        "version": "10.6.10",
        "date": "2026-05-15",
        "type": "patch",
        "title": "表示の調整",
        "notes": [],
        "notes_hidden": True,
        "internal_title": "License GUI ツール強化 + /changelog 表示マスク + リリース UI 構造改善",
        "internal_notes": [
            "license_gui.bat: ASCII-only + CRLF + port 待ちループ",
            "License GUI: /restart endpoint + ヘッダー再起動ボタン + nonce 判定の自動リロード",
            "License GUI release 画面: pending_version (CHANGELOG 追記済・未公開) を patch 候補化",
            "License GUI release 画面: 「ユーザー非表示」 (notes_hidden) チェックボックス追加",
            "License GUI release 画面: 顧客向け / 実装の真相 の 2 ブロック構造化 + internal_title / internal_notes 追加",
            "app/changelog.py: MIN_VERBOSE_VERSION で 10.6.5 以前の notes を伏せる",
            "app/templates/changelog.html: notes_hidden の時 notes セクション省略",
        ],
    },
    {
        "version": "10.6.9",
        "date": "2026-05-15",
        "type": "patch",
        "title": "UI改善・機能追加・セキュリティ強化・アップデート機能改善",
        "notes": [
            "新版を起動時に自動適用するように改善",
            "アップデート適用中の表示を日本語化",
            "アップデート後の起動確認をより堅牢に",
            "ヘッダーのバージョン番号クリックで更新履歴を表示",
            "アップデートチェックを高頻度化 (起動時 + 8 時間ごと)",
            "緊急時のセキュリティ配信を強制適用できるように",
        ],
    },
    {
        "version": "10.6.8",
        "date": "2026-05-15",
        "type": "patch",
        "title": "アップデート適用後の旧コンソールを自動で閉じる",
        "notes": [
            "アップデート適用後に前バージョンの黒い画面が残ったままになる "
            "不具合を修正 (適用処理が旧ウィンドウを検知して自動で閉じる)",
        ],
    },
    {
        "version": "10.6.7",
        "date": "2026-05-14",
        "type": "patch",
        "title": "UI改善・機能追加・セキュリティ強化・アップデート機能改善",
        "notes": [
            "新版を起動時に自動適用するように改善",
            "アップデート適用中の表示を日本語化",
            "アップデート後の起動確認をより堅牢に",
            "ヘッダーのバージョン番号クリックで更新履歴を表示",
            "アップデートチェックを高頻度化 (起動時 + 8 時間ごと)",
            "緊急時のセキュリティ配信を強制適用できるように",
        ],
    },
    {
        "version": "10.6.6",
        "date": "2026-05-13",
        "type": "patch",
        "title": "更新履歴リンクの表示修正",
        "notes": [
            "ヘッダーのバージョン番号をクリックすると更新履歴が開くように "
            "(v10.6.5 で一部の表示モードでリンクが効いていなかった不具合の修正)",
        ],
    },
    {
        "version": "10.6.5",
        "date": "2026-05-13",
        "type": "patch",
        "title": "更新履歴ページ + その他改善",
        "notes": [
            "ヘッダーのバージョン番号をクリックで更新履歴ページを表示",
            "適用モードを auto に既定化、既存 install も自動マイグレーション",
            "緊急配信用の強制適用日 (mandatory_after) 実装",
        ],
    },
    {
        "version": "10.6.4",
        "date": "2026-05-13",
        "type": "patch",
        "title": "自動アップデート機能の本格化 + セキュリティ強化",
        "notes": [
            "起動時にアップデートチェックを実行するようになりました",
            "アップデート確認の間隔を 24時間 → 8時間に短縮",
            "適用モード「auto」を既定化 — 顧客操作なしで起動時に自動適用",
            "緊急配信用に「強制適用日 (mandatory_after)」を実装",
            "アップデート パッケージの安全展開を強化 (path traversal / symlink 対策)",
            "アップデート適用と取得の競合(race)を解消",
        ],
    },
    {
        "version": "10.6.3",
        "date": "2026-05-12",
        "type": "patch",
        "title": "ヘッダーに現在バージョン表示",
        "notes": [
            "画面右上に Ver番号 を表示(クリックで本ページへ)",
        ],
    },
    {
        "version": "10.6.2",
        "date": "2026-05-12",
        "type": "patch",
        "title": "初回オンライン配信テスト",
        "notes": [
            "v10.6 系の動作確認用リリース",
        ],
    },
    {
        "version": "10.6.1",
        "date": "2026-05-12",
        "type": "minor",
        "title": "オンライン自動アップデート機能 追加",
        "notes": [
            "今後の軽微なバグ修正・機能改善は GitHub Pages 経由で自動配信",
            "受信側に Ed25519 署名検証 + ZIP sha256 検証を実装",
            "ロールバック機能 — 起動失敗時は前バージョンに自動復旧",
            "/settings/update から手動チェック / 適用モード切替が可能",
        ],
    },
    {
        "version": "10.5.5",
        "date": "2026-05-11",
        "type": "patch",
        "title": "車両マスタ自動登録 + ショートカット改善",
        "notes": [
            "日報CSV取込時に車両マスタへ自動登録するよう修正 "
            "(給油入力画面で車両ドロップダウンが空になる不具合の対処)",
            "デスクトップショートカットに極燃ロゴを設定",
            "デスクトップ上の旧 .bat ランチャー残骸を自動削除",
        ],
    },
    {
        "version": "10.5.4",
        "date": "2026-05-10",
        "type": "patch",
        "title": "操作ガイドにライセンス管理セクション",
        "notes": [
            "/help にライセンス管理の説明を追加",
        ],
    },
    {
        "version": "10.5.3",
        "date": "2026-05-09",
        "type": "patch",
        "title": "ライセンスIDのフォールバックバグ修正",
        "notes": [
            "customer_id が空文字のとき試用版モードへ正しくフォールバック",
        ],
    },
    {
        "version": "10.5.2",
        "date": "2026-05-08",
        "type": "patch",
        "title": "ライセンス状態チップ常時表示",
        "notes": [
            "ヘッダーに試用残日数 / ご契約状態を常時表示",
        ],
    },
    {
        "version": "10.5.1",
        "date": "2026-05-07",
        "type": "patch",
        "title": "ライセンス配信URL確定",
        "notes": [
            "Chuo-Hiza/fuelrecovery-license リポジトリ経由でライセンス配信",
        ],
    },
    {
        "version": "10.5.0",
        "date": "2026-05-06",
        "type": "minor",
        "title": "ライセンス期限機能",
        "notes": [
            "試用6ヶ月 + 本契約モード",
            "GitHub Pages からのオンライン期限取得",
            "期限切れ時の Grace期間(7日) → Locked への段階遷移",
        ],
    },
]
