@echo off
chcp 65001 >NUL
title Fuel Recovery OS Ver10.6.1
cd /d "%~dp0"
set PY=%~dp0python\python.exe
set PORT=8007
set URL=http://127.0.0.1:%PORT%/

:: --- Python check ---
if not exist "%PY%" (
    echo ERROR: python\python.exe not found.
    pause
    exit /b 1
)

:: --- Check if server is already running ---
"%PY%" -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:%PORT%/health', timeout=2)" >NUL 2>&1
if %errorlevel%==0 (
    echo  Server is already running. Opening browser...
    start "" "%URL%"
    exit /b 0
)

echo.
echo  ============================================
echo   Fuel Recovery OS Ver10.6.1
echo  ============================================
echo.

:: --- First-run setup ---
if not exist "data" mkdir "data"
if not exist "logs" mkdir "logs"
if not exist "config" mkdir "config"

if not exist "C:\estra-data\auto-export"  mkdir "C:\estra-data\auto-export"
if not exist "C:\estra-data\daily-batch"  mkdir "C:\estra-data\daily-batch"
if not exist "C:\estra-data\master"       mkdir "C:\estra-data\master"
if not exist "C:\estra-data\monthly"      mkdir "C:\estra-data\monthly"
if not exist "C:\estra-data\processing"   mkdir "C:\estra-data\processing"
if not exist "C:\estra-data\done"         mkdir "C:\estra-data\done"
if not exist "C:\estra-data\error"        mkdir "C:\estra-data\error"

if not exist "fuel_recovery.db" (
    echo  First-run setup...
    "%PY%" -c "from app.database import Base, engine; Base.metadata.create_all(bind=engine)"
    if errorlevel 1 (
        echo ERROR: Database creation failed.
        pause
        exit /b 1
    )
    echo  Database created.
)

:: --- Activation check ---
"%PY%" app\activation_check.py
if %errorlevel%==0 goto :activated
echo.
echo  ============================================
echo   Initial setup required.
echo   Please contact your system administrator.
echo  ============================================
echo.
set /p ACTPASS="  Setup password: "
"%PY%" app\activation_check.py "%ACTPASS%"
if %errorlevel% neq 0 (
    echo.
    echo  ERROR: Invalid password.
    pause
    exit /b 1
)
echo.
echo  Activation successful.
echo.
:activated

:: --- Windows Firewall rule (first run only, requires admin) ---
if not exist "config\.firewall_setup" (
    netsh advfirewall firewall show rule name=FuelRecoveryOS >NUL 2>&1
    if errorlevel 1 (
        echo.
        echo  ============================================
        echo   社内LANからのアクセスを有効にするため、
        echo   Windowsファイアウォールに受信規則を追加します。
        echo   管理者権限の確認が表示されます。「はい」を選択してください。
        echo   ※この設定は初回のみです
        echo  ============================================
        powershell -NoProfile -Command "Start-Process netsh -Verb RunAs -Wait -ArgumentList 'advfirewall','firewall','add','rule','name=FuelRecoveryOS','dir=in','action=allow','protocol=TCP','localport=%PORT%','profile=any'" >NUL 2>&1
    )
    echo done > "config\.firewall_setup"
)

:: --- Remove legacy desktop launcher .bat (v10.5.5+ uses .lnk shortcut from installer) ---
set DESKTOP=%USERPROFILE%\Desktop
if exist "%DESKTOP%\Fuel Recovery OS.bat" del /f /q "%DESKTOP%\Fuel Recovery OS.bat" >NUL 2>&1

:: --- Display LAN access banner ---
"%PY%" -m app.access_info %PORT%

:: --- Open browser after delay ---
start /b cmd /c "ping -n 5 127.0.0.1 >NUL && start "" "%URL%""

:: --- Start Uvicorn (bind to 0.0.0.0 for LAN access) ---
"%PY%" -m uvicorn app.main:app --host 0.0.0.0 --port %PORT%

if errorlevel 1 (
    echo.
    echo  Server stopped with an error.
    pause
)
