"""1分時系列データ CSV インポーター (_tc ファイル)。

列仕様 (ESTRA-Web2操作マニュアル第14版 p.237 準拠):
  ヘッダーレコード（1行目、位置固定）:
    col 0: 日報番号
    col 1: 運行日
    col 2: 乗務員コード
    col 3: 車両コード
    col 4: 乗務員営業所コード
    col 5: 運行開始日時
    col 6: 運行開始累積走行距離(m)
    col 7: 運行開始速度(km/h)
    col 8: 運行開始回転数(rpm)
    col 9: 運行開始緯度
    col10: 運行開始経度
    col11: 運行開始進行方向
    col12: 運行開始外部Ch状態
    col13-16: 運行開始アナログCh1-4
    col17: 運行終了日時 ... (以降、終了時情報)

  データレコード（2行目以降、位置固定）:
    col 0: 日付 (yyyy/MM/dd)
    col 1: 時刻 (hh:mm:ss)
    col 2: 最高速度 (km/h)
    col 3: 最低速度 (km/h)
    col 4: 最高回転数 (rpm)
    col 5: 最低回転数 (rpm)
    col 6: 距離 (m) - 1分間の距離
    col 7: 緯度 (小数点形式、世界測地系)
    col 8: 経度 (小数点形式、世界測地系)
    col 9: 進行方向 (0-360度)
    col10: 外部ch状態
    col11-14: アナログch1-4
"""
import csv
import io
import logging
from datetime import datetime
from pathlib import Path

from sqlalchemy import text
from sqlalchemy.orm import Session

from app.models.csv_import import TripTimeseries

logger = logging.getLogger(__name__)

# 位置インデックス定数（データレコード用）
_COL_DATE = 0
_COL_TIME = 1
_COL_MAX_SPEED = 2
_COL_MIN_SPEED = 3
_COL_MAX_RPM = 4
_COL_MIN_RPM = 5
_COL_DISTANCE_M = 6
_COL_LAT = 7
_COL_LON = 8
_COL_HEADING = 9
_COL_EXT_CH = 10


def _parse_int(val: str) -> int | None:
    if not val or not val.strip():
        return None
    try:
        return int(val.strip())
    except (ValueError, TypeError):
        return None


def _parse_float(val: str) -> float | None:
    if not val or not val.strip():
        return None
    try:
        return float(val.strip())
    except (ValueError, TypeError):
        return None


def _parse_gps(val: str) -> int | None:
    """GPS座標を内部形式(度×10^5 の整数)に正規化する。

    ESTRA-Web2 の _tc は機種・エクスポートにより GPS 表現が2通りある:
      (a) 10進数の度   例: "35.6812831"（|値| <= 180）
      (b) 整数スケール 例: "356826000"（度×10^7）や "3568128"（度×10^5）
    どちらでも正しく取り込めるよう、**度(|値| <= 180)になるまで 1/10** して
    から ×10^5 で保存する。緯度経度は ±180 を超えないため、超過分はスケール。
    (2026-04 実データで (b) 度×10^7 形式を確認 — 従来は範囲外として全除外していた)
    """
    f = _parse_float(val)
    if f is None:
        return None
    if f == 0:
        return 0
    a = abs(f)
    guard = 0
    while a > 180 and guard < 12:   # 度になるまでスケールを1/10ずつ落とす
        f /= 10.0
        a = abs(f)
        guard += 1
    if a > 180:
        return None                 # 度として解釈不能(異常値)
    return int(round(f * 100000))


def _resolve_report_number(db: Session, raw: str, filename: str) -> tuple[str, str | None]:
    """_tc ヘッダーの日報番号を trip_reports の実キーへ解決する。

    ESTRA の日報番号は「顧客コード8桁+出庫日時12桁+車両8桁=28桁」(full形)と
    顧客コード無しの20桁(short形)が経路によって混在する(ファイル名=full形、
    CSV内の日報番号列=short形 等)。形式が食い違うと時系列が日報に紐づかず、
    画面上「_tc 未取込」に見えるため、両形式を相互補完して照合する。
    """
    from app.importers.base import extract_report_number
    from app.models.csv_import import TripReport

    candidates = [raw]
    fname = extract_report_number(filename) or ""
    if fname and fname != raw:
        candidates.append(fname)
    for c in list(candidates):
        if len(c) == 28 and c[8:] not in candidates:
            candidates.append(c[8:])          # full形 → short形
    for c in candidates:
        if db.get(TripReport, c) is not None:
            note = None if c == raw else f"日報番号を {c} に解決(ヘッダ値: {raw})"
            return c, note
    # short形ヘッダ × full形キーのDB: 後方一致で唯一に決まる場合のみ採用
    like = db.query(TripReport.report_number).filter(
        TripReport.report_number.like(f"%{raw}")).limit(2).all()
    if len(like) == 1:
        return like[0][0], f"日報番号を {like[0][0]} に解決(後方一致。ヘッダ値: {raw})"
    return raw, None  # 日報未着(先に_tcが来た)等: ヘッダ値のまま取り込む


def import_trip_timeseries(filepath: Path, db: Session) -> dict:
    """1分時系列CSVを読み込み TripTimeseries テーブルに投入する。

    Returns:
        dict with keys: status, imported, updated, errors
    """
    try:
        raw = filepath.read_bytes()
        text_data = raw.decode("cp932", errors="replace")
    except Exception as e:
        return {"status": "error", "detail": str(e)}

    lines = text_data.splitlines()
    if not lines:
        return {"status": "error", "detail": "Empty file"}

    # ── ヘッダー行からメタ情報を取得 ──────────────────────────────────────
    header_cols = list(csv.reader([lines[0]]))[0]
    if not header_cols:
        return {"status": "error", "detail": "Invalid header row"}

    report_number = header_cols[0].strip() if header_cols[0].strip() else None
    if not report_number:
        return {"status": "error", "detail": "Missing report_number in header"}
    report_number, resolve_note = _resolve_report_number(
        db, report_number, filepath.name)
    if resolve_note:
        logger.info(f"timeseries: {resolve_note} ({filepath.name})")

    # ── 既存レコード削除（再インポートは洗い替え方式）────────────────────
    existing_count = db.query(TripTimeseries).filter_by(report_number=report_number).count()
    if existing_count > 0:
        db.query(TripTimeseries).filter_by(report_number=report_number).delete()
        db.flush()

    # ── データ行を解析 ────────────────────────────────────────────────────
    imported = 0
    errors = []
    batch: list[TripTimeseries] = []
    BATCH_SIZE = 500

    for line_no, line in enumerate(lines[1:], start=2):
        line = line.strip()
        if not line:
            continue

        cols = list(csv.reader([line]))[0]
        if len(cols) < 7:
            errors.append(f"Line {line_no}: too few columns ({len(cols)})")
            continue

        def col(idx: int) -> str:
            return cols[idx].strip() if idx < len(cols) else ""

        # 記録日時の組立
        date_str = col(_COL_DATE)
        time_str = col(_COL_TIME)
        if not date_str or not time_str:
            errors.append(f"Line {line_no}: missing date/time")
            continue

        try:
            recorded_at = datetime.strptime(f"{date_str} {time_str}", "%Y/%m/%d %H:%M:%S")
        except ValueError:
            try:
                recorded_at = datetime.strptime(f"{date_str} {time_str}", "%Y/%m/%d %H:%M")
            except ValueError:
                errors.append(f"Line {line_no}: invalid datetime '{date_str} {time_str}'")
                continue

        max_speed = _parse_int(col(_COL_MAX_SPEED))
        min_speed = _parse_int(col(_COL_MIN_SPEED))
        max_rpm = _parse_int(col(_COL_MAX_RPM))
        min_rpm = _parse_int(col(_COL_MIN_RPM))
        distance_m = _parse_int(col(_COL_DISTANCE_M))
        gps_lat = _parse_gps(col(_COL_LAT))
        gps_lon = _parse_gps(col(_COL_LON))
        heading = _parse_int(col(_COL_HEADING))

        # extra_fields: 最低速度・最低回転数・距離・進行方向・外部ch等
        extra: dict = {}
        if min_speed is not None:
            extra["min_speed_kmh"] = min_speed
        if min_rpm is not None:
            extra["min_rpm"] = min_rpm
        if distance_m is not None:
            extra["distance_m"] = distance_m
        if heading is not None:
            extra["heading_deg"] = heading
        ext_ch = col(_COL_EXT_CH)
        if ext_ch:
            extra["ext_ch"] = ext_ch

        record = TripTimeseries(
            report_number=report_number,
            recorded_at=recorded_at,
            speed_kmh=max_speed,
            engine_rpm=max_rpm,
            gps_lat=gps_lat,
            gps_lon=gps_lon,
            altitude_m=None,  # _tc CSV に標高情報なし（進行方向は extra_fields へ）
            extra_fields=extra if extra else None,
        )
        batch.append(record)
        imported += 1

        if len(batch) >= BATCH_SIZE:
            db.bulk_save_objects(batch)
            db.flush()
            batch.clear()

    if batch:
        db.bulk_save_objects(batch)

    db.commit()

    return {
        "status": "success",
        "imported": imported,
        "updated": existing_count,  # 洗い替え前の件数
        "errors": errors,
        "report_number": report_number,
        "detail": resolve_note,
    }
